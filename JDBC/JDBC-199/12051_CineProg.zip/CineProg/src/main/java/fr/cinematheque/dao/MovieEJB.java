package fr.cinematheque.dao;

import fr.cinematheque.model.Movie;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class MovieEJB extends AbstractFacade<Movie>
{
    @PersistenceContext private EntityManager em;

    @Override    
    protected EntityManager getEntityManager()
    {
        return em;
    }

    public MovieEJB()
    {
        super(Movie.class);
    }    
}