package fr.cinematheque.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "MOVIE")
@NamedQueries(
{
    @NamedQuery(name = "Movie.findAll", query = "SELECT m FROM Movie m")
})
public class Movie implements Serializable
{
    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "generatorMovieId", sequenceName = "GEN_MOVIE_ID", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generatorMovieId")    
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")  
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "TITLE")
    private String title;
    @Column(name = "DATE_RELEASE")
    private Integer dateRelease;
    @Column(name = "STATUS")
    private Integer status;

    public Movie()
    {
    }

    public Movie(Integer id)
    {
        this.id = id;
    }

    public Movie(Integer id, String title)
    {
        this.id = id;
        this.title = title;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public Integer getDateRelease()
    {
        return dateRelease;
    }

    public void setDateRelease(Integer dateRelease)
    {
        this.dateRelease = dateRelease;
    }

    public Integer getStatus()
    {
        return status;
    }

    public void setStatus(Integer status)
    {
        this.status = status;
    }

    @Override
    public int hashCode()
    {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object)
    {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Movie))
        {
            return false;
        }
        Movie other = (Movie) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)))
        {
            return false;
        }
        return true;
    }

    @Override
    public String toString()
    {
        return "fr.cinematheque.model.Movie[ id=" + id + " ]";
    }
    
}
