package br.com.company.commerce.utils;

import br.com.company.commerce.classes.Filial;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import javax.faces.context.FacesContext;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class Banco {

    private static String JNDIDataSource;

    public Connection getConexao() throws NamingException, SQLException {
        InitialContext ctx = new InitialContext();
        DataSource ds = (DataSource) ctx.lookup("java:comp/env/" + getJNDIDataSource());
        return ds.getConnection();
    }

    public Connection getConexao(Filial filial) throws NamingException, SQLException {

        if (filial == null) {
            return getConexao();
        }

        InitialContext ctx = new InitialContext();
        DataSource ds = (DataSource) ctx.lookup("java:comp/env/" + getJNDIDataSource());
        return ds.getConnection();
    }

    public static void fechaConexao(Connection conn, Statement stmt, ResultSet rs) {
        fechar(conn, stmt, rs);
    }

    public static void fechaConexao(Connection conn, Statement stmt) {
        fechar(conn, stmt, null);
    }

    public static void fechaConexao(Connection conn, ResultSet rs) {
        fechar(conn, null, rs);
    }

    public static void fechaConexao(Connection conn) {
        fechar(conn, null, null);
    }

    private static void fechar(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null && !rs.isClosed()) {
                rs.close();
            }
            if (stmt != null && !stmt.isClosed()) {
                stmt.close();
            }
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (Exception e) { //tratar esta exception depois ...
            e.printStackTrace();
            //System.err.println("tratar esta exception depois ...");
        }
    }

    public static String getJNDIDataSource() {

        if (JNDIDataSource == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            Map contextParams = facesContext.getExternalContext().getInitParameterMap();
            JNDIDataSource = (String)contextParams.get("br.com.company.commerce.JNDIDATASOURCE");
        }

        return JNDIDataSource;
    }
}
