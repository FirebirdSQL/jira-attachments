import java.io.Serializable;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.faces.context.FacesContext;
import javax.naming.NamingException;
import org.apache.commons.lang3.text.WordUtils;
    
	
	public List<ProdutosFiliais> getProdutosDAO(Filial filial, String myTipo, String myFabricante, String myTipoProduto, String myPalavraChave, int myQuantidade, boolean myIndex, boolean myDisponiveis, int myFaturar, int myEmpresa) {

        PreparedStatement ps = null;
        Connection conexao = null;
        ResultSet rs = null;
        List<ProdutosFiliais> myListaDeProdutos = new ArrayList<>();
        String mySQL = "";

        if (filial == null) {
            filial = new Filial();
            filial.setSigla(Configuracoes.getMyFilial());
        }

        myFabricante = myFabricante == null || myFabricante.equals("0") ? "@" : myFabricante;
        myTipoProduto = myTipoProduto == null || myTipoProduto.equals("") ? "@" : myTipoProduto;
        myPalavraChave = myPalavraChave == null ? "" : myPalavraChave.toUpperCase(); // Precisamos colocar em maiuscula senão a procedure não encontra no banco

        try {
            conexao = banco.getConexao(filial);

            if (myIndex) {

                mySQL = "select first " + myQuantidade + " * from lista_tabsite(?, ?, ?, null, null, null, ?) "
                        + "where qtd > 0 order by ordem";

                ps = conexao.prepareStatement(mySQL);

                //ps.setInt   (1,  myQuantidade );
                ps.setString(1, filial.getSigla());
                ps.setString(2, getStringTabelaPadrao());
                ps.setString(3, myTipo);
                ps.setInt(4, myFaturar);
            } else if (myTipo.equals("C")) {
                mySQL = "select first " + myQuantidade + " l.* from lista_tabsite(?, ?, 'C', null, ?, null, ?) l "
                        + "inner join categoria_x_tipo ct on ct.tipo = l.tipo and ct.id_cat = ? "
                        + "where l.qtd > 0 order by l.ordem";

                ps = conexao.prepareStatement(mySQL);

                //ps.setInt   (1,  myQuantidade );
                ps.setString(1, filial.getSigla());
                ps.setString(2, getStringTabelaPadrao());
                ps.setString(3, myPalavraChave);
                ps.setInt(4, myFaturar);
                ps.setInt(5, Integer.parseInt(myPalavraChave));
            } else if (myTipo.equals("P")
                    || myTipo.equals("L")) {
                mySQL = "select * from lista_tabsite(?, ?, ?, null, null, null, ?) "
                        + "order by ordem";

                ps = conexao.prepareStatement(mySQL);

                ps.setString(1, filial.getSigla());
                ps.setString(2, getStringTabelaPadrao());
                ps.setString(3, myTipo);
                ps.setInt(4, myFaturar);

            } else if (myTipo.equals("G")) {
                mySQL = "select * from lista_tabsite(?, ?,'X', null, ?, null, ?) "
                        + "order by qtd desc";

                ps = conexao.prepareStatement(mySQL);
                ps.setString(1, filial.getSigla());
                ps.setString(2, getStringTabelaPadrao());
                ps.setString(3, myTipoProduto);
                ps.setInt(4, myFaturar);

            } else if (myTipo.equals("SCP")) {
                mySQL = "select * from lista_tabsite(?, ?,'X', null, null, null, ?) "
                        + "where qtd > 0 and site_comparacao_preco = 'S' and fornecedor is null order by qtd desc";

                ps = conexao.prepareStatement(mySQL);
                ps.setString(1, filial.getSigla());
                ps.setString(2, getStringTabelaPadrao());
                ps.setInt(3, myFaturar);
            } else /*if (myTipo.equals("E"))*/ {

                if (myFabricante.equals("@")) {
                    myFabricante = null;
                }
                if (myTipoProduto.equals("@") || myTipoProduto.equals("")) {
                    myTipoProduto = null;
                }
                if (myPalavraChave.equals("")) {
                    myPalavraChave = null;
                }

                if (myDisponiveis) {
                    mySQL = "select * from lista_tabsite(?, ?,'X', ?, ?, ?, ?) "
                            + "where qtd > 0 order by qtd desc";
                } else {
                    mySQL = "select * from lista_tabsite(?, ?,'X', ?, ?, ?, ?) "
                            + "order by qtd desc";
                }

                ps = conexao.prepareStatement(mySQL);
                ps.setString(1, filial.getSigla());
                ps.setString(2, getStringTabelaPadrao());
                ps.setString(3, myFabricante);
                ps.setString(4, myTipoProduto);
                ps.setString(5, myPalavraChave);
                ps.setInt(6, myFaturar);
            }

            rs = ps.executeQuery();

            while (rs.next()) {

                ProdutosFiliais myProdutos = new ProdutosFiliais();

                myProdutos.setMyFilial(filial.getSigla());
                myProdutos.setMyFilialNome(filial.getNome());
                myProdutos.setMyGrupo(rs.getString(1));
                myProdutos.setMyCodigo(rs.getString(2));
                myProdutos.setMyDescricao(rs.getString(3));
                myProdutos.setMyTipoProduto(rs.getString(4).trim());
                myProdutos.setMyTipo(rs.getString(5));
                myProdutos.setMyValorMesmoUF(rs.getBigDecimal(6) == null ? 0f : rs.getBigDecimal(6).setScale(2, RoundingMode.HALF_EVEN).floatValue());
                myProdutos.setMyValorDoze(rs.getBigDecimal(7) == null ? 0f : rs.getBigDecimal(7).setScale(2, RoundingMode.HALF_EVEN).floatValue());
                myProdutos.setMyValorSete(rs.getBigDecimal(8) == null ? 0f : rs.getBigDecimal(8).setScale(2, RoundingMode.HALF_EVEN).floatValue());
                /*
                 myProdutos.setMyValorMesmoUF(rs.getFloat(6));
                 myProdutos.setMyValorDoze(rs.getFloat(7));
                 myProdutos.setMyValorSete(rs.getFloat(8));
                 */
                myProdutos.setMyPartNumber(rs.getString(9));
                myProdutos.setMyFabricante(new Fabricantes());
                myProdutos.getMyFabricante().setMyCodigo(rs.getInt(10));
                myProdutos.getMyFabricante().setMyNome(rs.getString("nomefabr"));
                myProdutos.getMyFabricante().setMyGarantiaDireta(rs.getString("garantia_direta"));
                myProdutos.setMyDesconto(rs.getBigDecimal(11) == null ? 0f : rs.getBigDecimal(11).setScale(3, RoundingMode.HALF_EVEN).floatValue());
                myProdutos.setMyDescontoOriginal(rs.getFloat(11));
                myProdutos.setMyOrdem(rs.getString(12));
                myProdutos.setMyPeso(rs.getFloat(14));
                myProdutos.setValorSugestao(rs.getBigDecimal("valor_sugestao") == null ? 0f : rs.getBigDecimal("valor_sugestao").setScale(2, RoundingMode.HALF_EVEN).floatValue());

                if (Configuracoes.getUsarValorSugestao()) {
                    myProdutos.setMyValorPadrao(myProdutos.getValorSugestao());
                } else {
                    myProdutos.setMyValorPadrao(rs.getBigDecimal(22) == null ? 0f : rs.getBigDecimal(22).setScale(2, RoundingMode.HALF_EVEN).floatValue());
                }

                //myProdutos.setMyValorMinimo(rs.getFloat(15));
                //myProdutos.setMyCusto(rs.getFloat(16));
                if (myEmpresa == 0) {
                    myProdutos.setMyQuantidade(rs.getInt(23));
                } else {
                    myProdutos.setMyQuantidade(rs.getInt(13));
                }

                myProdutos.setMyMedidas(new Medidas());
                myProdutos.getMyMedidas().setAltura(rs.getFloat("altura"));
                myProdutos.getMyMedidas().setLargura(rs.getFloat("largura"));
                myProdutos.getMyMedidas().setComprimento(rs.getFloat("comprimento"));

                myProdutos.setMyValorSubTrib(rs.getBigDecimal("valst") == null ? 0f : rs.getBigDecimal("valst").setScale(2, RoundingMode.HALF_EVEN).floatValue());
                myProdutos.setMyValorStRef(rs.getBigDecimal("valstref") == null ? 0f : rs.getBigDecimal("valstref").setScale(2, RoundingMode.HALF_EVEN).floatValue());
                myProdutos.setMyDescricaoTipoProduto(rs.getString("descrtipo"));
                myProdutos.setMyGarantia(rs.getInt("garantia"));
                myProdutos.setMyQtdMinimaVenda(rs.getInt("qtd_minima_venda"));
                myProdutos.setNota(rs.getInt("nota"));
                myProdutos.setImagemPadrao(rs.getString("foto_padrao"));
                myProdutos.setUltimaAlteracao(rs.getDate("ultalteracao"));
                myProdutos.setCaixaAgrupadaMedidas(new Medidas());
                myProdutos.getCaixaAgrupadaMedidas().setAltura(rs.getFloat("cx_agrup_alt"));
                myProdutos.getCaixaAgrupadaMedidas().setLargura(rs.getFloat("cx_agrup_larg"));
                myProdutos.getCaixaAgrupadaMedidas().setComprimento(rs.getFloat("cx_agrup_compr"));
                myProdutos.setCaixaAgrupadaPeso(rs.getFloat("cx_agrup_peso"));
                myProdutos.setCaixaAgrupadaQuantidade(rs.getInt("cx_agrup_qtd"));
                myProdutos.setEan13(rs.getString("ean13"));
                myProdutos.setUpc(rs.getString("upc"));
                myProdutos.setFreteGratis("S".equalsIgnoreCase(rs.getString("frete_gratis")));
                myProdutos.setFreteGratisOriginal(myProdutos.getFreteGratis());
                myProdutos.setFornecedor(rs.getInt("fornecedor"));
                myProdutos.setPrazoEntregaFornecedor(rs.getInt("prazo_entrega_fornec"));

                myListaDeProdutos.add(myProdutos);
            }
        } catch (SQLException | NamingException e) {
            throw new RuntimeException(e);
        } finally {
            Banco.fechaConexao(conexao, ps, rs);
        }

        return myListaDeProdutos;
    }
	
	private String getStringTabelaPadrao() {

        FacesContext fc = FacesContext.getCurrentInstance();

        if (fc == null) {
            if (Configuracoes.getMyTabelaSite() == null) {
                throw new RuntimeException("Atencao: nao foi preenchido campo tabela padrao na tabela 'PARAMETROS'. Por favor corrija urgente.");
            } else {
                return Configuracoes.getMyTabelaSite();
            }
        } else {
            SessionBean sessionBean = (SessionBean) fc.getExternalContext().getSessionMap().get("sessionBean");

            if (sessionBean == null
                    || sessionBean.getTabela() == null
                    || sessionBean.getTabela().getTabelaPK() == null
                    || sessionBean.getTabela().getTabelaPK().getTabela() == null) {
                return null;
            } else {
                return sessionBean.getTabela().getTabelaPK().getTabela();
            }
        }
    }