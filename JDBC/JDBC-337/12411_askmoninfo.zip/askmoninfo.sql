set autoddl off;
set list off;
set blob on;
set width mon_user 20;
set width remote_process 30;
set width sql_txt 50;
set width remote_ip 15;
set width rn 3;

select
cast(row_number()over(order by a.mon$attachment_id) as char(3)) rn
,a.mon$remote_address remote_IP
,a.mon$attachment_id attach_id
,a.mon$user mon_user
,a.mon$stat_id       stat_id
,a.mon$server_pid    server_PID
,a.mon$remote_pid    remote_PID
,u.mon$memory_used used_memory
,u.mon$memory_allocated alloc_by_OS
,i.mon$page_reads reads
,i.mon$page_writes writes
,i.mon$page_fetches fetches
,i.mon$page_marks marks
,r.mon$record_seq_reads seq_reads
,r.mon$record_idx_reads idx_reads
,r.mon$record_inserts ins_cnt
,r.mon$record_updates upd_cnt
,r.mon$record_deletes del_cnt
,r.mon$record_backouts bk_outs
,r.mon$record_purges purges
,r.mon$record_expunges expunges
,right(a.mon$remote_process,30) remote_process
from mon$attachments a
left join mon$statements s on a.mon$attachment_id = s.mon$attachment_id
left join mon$memory_usage u on a.mon$stat_id=u.mon$stat_id
left join mon$io_stats i on a.mon$stat_id=i.mon$stat_id
left join mon$record_stats r on a.mon$stat_id=r.mon$stat_id
;