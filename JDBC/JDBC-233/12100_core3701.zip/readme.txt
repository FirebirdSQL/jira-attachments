The run.bat assumes you are running a 32 bit Java, if you have both a 64 bit and 32 bit Java,
make sure run.bat is pointing to the 32 bit JVM.

Examples of running:

	ISO8859_1 database
Connection characterset NONE  (works):
run jdbc:firebirdsql:native:localhost:<path-to>\CORE3701_ISO.fdb

Connection characterset ISO8859_1 (works):
run jdbc:firebirdsql:native:localhost:<path-to>\CORE3701_ISO.fdb?encoding=ISO8859_1

Connection characterset UTF8 (does not work):
run jdbc:firebirdsql:native:localhost:<path-to>\CORE3701_ISO.fdb?encoding=UTF8

	UTF8 database
Connection characterset NONE  (does not work):
run jdbc:firebirdsql:native:localhost:<path-to>\CORE3701_UTF8.fdb

Connection characterset ISO8859_1 (works):
run jdbc:firebirdsql:native:localhost:<path-to>\CORE3701_UTF8.fdb?encoding=ISO8859_1

Connection characterset UTF8 (does not work):
run jdbc:firebirdsql:native:localhost:<path-to>\CORE3701_UTF8.fdb?encoding=UTF8