package core3701;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BasicReproduction {
	
	private static final String TEST_URL = "jdbc:firebirdsql:native:localhost:D:\\data\\db\\base_test.fdb?encoding=UTF8";
	private static final String TEST_SQL = "INSERT INTO TEST (TEST_FIELD) VALUES(?)";

	public static void main(String[] args) throws Exception {
		String url = TEST_URL;
		if (args.length > 0) {
			url = args[0];
		}
		Connection con = getConnection(url);
		try {
			PreparedStatement ps = con.prepareStatement(TEST_SQL);
			ps.setString(1, "W");
			ps.executeUpdate();
		} finally {
			try {
				con.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	private static Connection getConnection(String url) throws SQLException {
		return DriverManager.getConnection(url, "SYSDBA", "masterkey");
	}
}
