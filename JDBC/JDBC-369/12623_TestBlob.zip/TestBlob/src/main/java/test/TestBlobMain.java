package test;

import java.sql.*;

/**
 * Simple test app to get timings for reading blob data from Firebird.
 *
 * A table called test_lob is created and 100K records inserted. The table is then read twice, the first time
 * reading only varchar column, and the second time reading only the blob column.
 *
 * The timings are captured to std out.
 */
public class TestBlobMain {

    private static final String USER = "sysdba";

    private static final String PASSWORD = "password";

    private static final String URL = "jdbc:firebirdsql://localhost/test";

    private static final String INSERT_SQL = "insert into test_lob (id, lobData, varCharText ) values (?,?,?)";

    private static final String SELECT_SQL = "select * from test_lob";


    public static void main(String[] args) {
        try {
            new TestBlobMain().runTest();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * Runs the test and writes the results to std out.
     *
     * @throws SQLException
     */
    public void runTest()throws SQLException{
        System.out.println("Times getting Varchar data...");
        runTest("varCharText");
        System.out.println("-----------------------------");

        System.out.println("Times getting LOB data...");
        runTest("lobData");

    }

    public void runTest(String column) throws SQLException {
        dataprep();

        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        long start = System.currentTimeMillis();
        long totalGetObjectTime = 0;
        int count = 0;
        try{
            connection = getConnection();
            ps = connection.prepareStatement(SELECT_SQL);

            rs = ps.executeQuery();
            while(rs.next()) {

                long startGetObj = System.currentTimeMillis();
                rs.getObject(column);
                long getObjectTime = (System.currentTimeMillis() - startGetObj);
                totalGetObjectTime = totalGetObjectTime + getObjectTime;
                count++;
            }
        }
        finally{
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        long end = System.currentTimeMillis();

        System.out.println("  Records read: " + count);
        System.out.println("  Total time (millis): " + (end - start));
        System.out.println("  Total get "+column+" time (millis): " + totalGetObjectTime);


    }






    /**
     * Setup for the test.
     * Populate 100K records
     */
    private void dataprep() throws SQLException {
        if(createTestTableIfRequired()){
            System.out.println("Starting dataprep");

            Connection connection = null;
            PreparedStatement ps = null;
            try{
                connection = getConnection();
                connection.setAutoCommit(true);
                ps = connection.prepareStatement(INSERT_SQL);

                for(int i = 0; i < 100000; i++){
                    ps.setInt(1, i);
                    ps.setString(2, "Some text");
                    ps.setString(3, "Some text");
                    ps.execute();
                }

            }
            finally{
                if (ps != null) {
                    ps.close();
                }
                if (connection != null) {
                    connection.close();
                }
                System.out.println("Completed dataprep");
            }
        }

    }


    /**
     * Creates the test table "test_lob" if not already created.
     * @return true if created, otherwise false
     * @throws SQLException
     */
    private boolean createTestTableIfRequired() throws SQLException {
        if(tableExists("test_lob")){
            return false;
        }

        Connection connection = null;
        Statement stmt = null;
        try{
            connection = getConnection();
            String sql = "create table test_lob (" +
                    "id int not null primary key, " +
                    "lobData blob sub_type 1," +
                    "varCharText varchar(20))";

            stmt = connection.createStatement();
            stmt.executeUpdate(sql);

        }
        finally{
            if (stmt != null) {
                stmt.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return true;
    }

    /**
     * Indicates if a table already exists
     * @param tableName Table to check
     * @return true if exists, otherwise false
     * @throws SQLException
     */
    private boolean tableExists(String tableName) throws SQLException {
        Connection connection = null;
        ResultSet rs = null;
        try{
            connection = getConnection();
            DatabaseMetaData metaData = connection.getMetaData();

            rs = metaData.getTables(null, null, tableName.toUpperCase(), null);
            return rs.next();
        }
        finally{
            if (rs != null){
                rs.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }

    private Connection getConnection() throws SQLException {
        try {
            Class.forName ("org.firebirdsql.jdbc.FBDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

}
