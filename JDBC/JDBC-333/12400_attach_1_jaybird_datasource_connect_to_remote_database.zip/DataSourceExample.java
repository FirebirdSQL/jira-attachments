// cmp: javac -cp .;jaybird-full-2.2.4.jar DataSourceExample.java
// run: java -cp .;jaybird-full-2.2.4.jar DataSourceExample
public final class DataSourceExample
{

  private final static String DB_URL = "192.168.0.201/3252:employee";
  private final static String SQL_QUERY1 = "select uuid_to_char(gen_uuid()) as col_title1 from employee rows 3";
  private final static String SQL_QUERY2 = "select uuid_to_char(gen_uuid())||'' from employee rows 3";
  private final static String SQL_QUERY3 = "select full_name col_title2 from employee rows 3";

  private final static String DEFAULT_USER = "sysdba";
  private final static String DEFAULT_PASS = "masterkey";
  
  static public void main (String args[]) throws Exception
  {
    
    // Create an Firebird data source manually;
    org.firebirdsql.pool.FBWrappingDataSource dataSource = 
        new org.firebirdsql.pool.FBWrappingDataSource();

    dataSource.setDatabase (DB_URL);
    dataSource.setType("TYPE4");

    java.sql.ResultSet rs = null;
    java.sql.ResultSetMetaData rsMetaData = null;

    // Connect to the Firebird DataSource
    try {
      dataSource.setLoginTimeout (5);
      java.sql.Connection c = dataSource.getConnection (DEFAULT_USER, DEFAULT_PASS);
      // At this point, there is no implicit driver instance
      // registered with the driver manager!
      System.out.println ("got connection\n");
      
      java.sql.Statement stmt = c.createStatement();
      rs = stmt.executeQuery(SQL_QUERY1);

      rsMetaData = rs.getMetaData();
      System.out.println("SQL_QUERY1="+SQL_QUERY1+"\nhas " + rsMetaData.getColumnCount() + " result columns.");
      System.out.println("Here are the columns: ");
      for (int i = 1; i <= rsMetaData.getColumnCount(); i++) {
         System.out.println("via getColumnName():  >" + rsMetaData.getColumnName(i) + "< of type " + rsMetaData.getColumnTypeName(i));
         System.out.println("via getColumnLabel(): >" + rsMetaData.getColumnLabel(i) + "< of type " + rsMetaData.getColumnTypeName(i));
      }
      
      System.out.println("\nbegin output result of SQL_QUERY1:");
      while(rs.next()) {
          System.out.println( rs.getString(1) );
      }
      System.out.println("finish output query result SQL_QUERY1");

      rs = stmt.executeQuery(SQL_QUERY2);
      rsMetaData = rs.getMetaData();

      System.out.println("\n\nSQL_QUERY2="+SQL_QUERY2+"\nhas " + rsMetaData.getColumnCount() + " result columns.");
      System.out.println("Here are the columns: ");
      for (int i = 1; i <= rsMetaData.getColumnCount(); i++) {
         System.out.println("via getColumnName():  >" + rsMetaData.getColumnName(i) + "< of type " + rsMetaData.getColumnTypeName(i));
         System.out.println("via getColumnLabel(): >" + rsMetaData.getColumnLabel(i) + "< of type " + rsMetaData.getColumnTypeName(i));
      }
      System.out.println("\nbegin output result of SQL_QUERY2:");
      while(rs.next()) {
          System.out.println( rs.getString(1) );
      }
      System.out.println("finish output query result of SQL_QUERY2");


      rs = stmt.executeQuery(SQL_QUERY3);
      rsMetaData = rs.getMetaData();

      System.out.println("\n\nSQL_QUERY3="+SQL_QUERY3+"\nhas " + rsMetaData.getColumnCount() + " result columns.");
      System.out.println("Here are the columns: ");
      for (int i = 1; i <= rsMetaData.getColumnCount(); i++) {
         System.out.println("via getColumnName():  >" + rsMetaData.getColumnName(i) + "< of type " + rsMetaData.getColumnTypeName(i));
         System.out.println("via getColumnLabel(): >" + rsMetaData.getColumnLabel(i) + "< of type " + rsMetaData.getColumnTypeName(i));
      }
      System.out.println("\nbegin output result of SQL_QUERY3:");
      while(rs.next()) {
          System.out.println( rs.getString(1) );
      }
      System.out.println("finish output query result of SQL_QUERY3");
      
      stmt.close();
      c.close ();
    }
    catch (java.sql.SQLException e) {
		e.printStackTrace();
      System.out.println ("sql exception: " + e.getMessage ());
    }
  }
}
