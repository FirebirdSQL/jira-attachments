package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Main2 {

	public static void main(String[] args) throws Exception {
		Class.forName("org.firebirdsql.jdbc.FBDriver");

		Connection cn = DriverManager.getConnection(
				"jdbc:firebirdsql:embedded:WARRULES.FDB",
				"SYSDBA", "masterkey");
		PreparedStatement stmt = cn.prepareStatement(
	    	"EXECUTE PROCEDURE factorial(?)");
		stmt.setInt(1, 2);
		ResultSet rs = stmt.executeQuery();
		rs.next(); // move cursor to the first row
		int result = rs.getInt(1);
		System.out.println(result);
	}
}
