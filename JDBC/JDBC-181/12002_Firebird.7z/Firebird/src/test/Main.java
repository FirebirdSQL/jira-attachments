﻿package test;

import java.sql.*;

public class Main {

	public static void main(String[] args) throws Exception {
		Class.forName("org.firebirdsql.jdbc.FBDriver");

		CallableStatement cst = null;
		Connection cn = DriverManager.getConnection(
				"jdbc:firebirdsql:embedded:WARRULES.FDB",
				"SYSDBA", "masterkey");
		cst = cn.prepareCall("EXECUTE PROCEDURE addOrChangeRecord"+
        		"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
		cst.setLong(1, 25790L);
		cst.setLong(2, 1L);
		cst.setInt(3, 1);
		cst.setString(4, "One");
		cst.setString(5, "Два");
		cst.setString(6, "Three");
		cst.setString(7, "2011-02-16 12:02:09");
		cst.setInt(8, 51);
		cst.setString(9, "Четыре");
		cst.setInt(10, 1);
		cst.setInt(11, 6);
		cst.setDouble(12, 10.4D);
		cst.setNull(13, java.sql.Types.BIGINT);
		cst.setLong(14, 1050L);
		cst.registerOutParameter(15, java.sql.Types.VARCHAR);
		cst.execute();
		System.out.println(cst.getString(15));
		
//		PreparedStatement prstmt = null;
//		prstmt = cn.prepareStatement("EXECUTE PROCEDURE addOrChangeRecord"+
//        		"(?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
//		prstmt.setLong(1, 25790L);
//		prstmt.setLong(2, 1L);
//		prstmt.setInt(3, 1);
//		prstmt.setString(4, "One");
//		prstmt.setString(5, "Два");
//		prstmt.setString(6, "Three");
//		prstmt.setString(7, "2011-02-16 12:02:09");
//		prstmt.setInt(8, 51);
//		prstmt.setString(9, "Четыре");
//		prstmt.setInt(10, 1);
//		prstmt.setInt(11, 6);
//		prstmt.setDouble(12, 10.4D);
//		prstmt.setNull(13, java.sql.Types.BIGINT);
//		prstmt.setLong(14, 1050L);
//		prstmt.execute();
//		ResultSet rs = prstmt.getResultSet();
//		while(rs.next()){
//			System.out.println(rs.getString(1));
//		}
	}
}