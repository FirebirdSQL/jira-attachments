import java.sql.*;

public class MemoryTest
{

  public static void testSQL() {
    try {
      long memoryBeforeSelects;
      long memoryAfterSelects;
      long memoryAfterConnectionClose;
      Class.forName("org.firebirdsql.jdbc.FBDriver");
      Connection conn = DriverManager.getConnection("jdbc:firebirdsql:localhost/3050:D:\\project\\fbtest\\data\\memorytest.fdb", "sysdba", "masterkey");
      System.out.println("Autocommit: " + conn.getAutoCommit());
      try {
        Statement stmt = conn.createStatement();
        stmt.setFetchSize(10);

        try {
          System.gc();
          memoryBeforeSelects = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
          ResultSet rs = stmt.executeQuery("SELECT * FROM TEST_TABLE");
          rs.close();
          System.gc();
          memoryAfterSelects = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        }
        finally {
          stmt.close();
        }
      }
      finally {
        conn.close();
        System.gc();
        memoryAfterConnectionClose = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
      }
      System.out.println("Memory before selects " + memoryBeforeSelects / 1024 + " kB");
      System.out.println("Memory after selects " + memoryAfterSelects / 1024 + " kB");
      System.out.println("Memory after close connection " + memoryAfterConnectionClose / 1024 + " kB");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public static void main(String[] args) {
    testSQL();
  }

}
