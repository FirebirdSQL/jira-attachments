// compile: javac -cp .;jaybird-full-2.2.4.jar FbConnExploring.java
// run:     java -cp .;jaybird-full-2.2.4.jar FbConnExploring 1>FbConnExploring.log 2>FbConnExploring.err

/*
README.monitoring_tables 
    2) For table MON$ATTACHMENTS:
      - columns MON$REMOTE_PID and MON$REMOTE_PROCESS contains non-NULL values
        only if the client library has version 2.1 or higher
      - column MON$REMOTE_PROCESS can contain a non-pathname value
        if an application has specified a custom process name via DPB
*/
import java.text.*;
public class FbConnExploring {
    private static final String FB_HOST = "localhost";
    private static final int FB_PORT = 3253;
    private static final String DB_NAME = "employee";
    private static final String URL_DEFAULT = "jdbc:firebirdsql://"+FB_HOST+":"+FB_PORT+"/" + DB_NAME;
    //private static final String URL_DEFAULT = "jdbc:firebirdsql://localhost:3050/c:/database/employee.fdb";
    private static final String USER_DEFAULT = "sysdba";
    private static final String PASSWORD_DEFAULT = "masterkey";

    private static final int REGISTER_CLASS_FOR_NAME = 1;
    private static final int REGISTER_PROPERTIES = 2;
    private static final int REGISTER_JDBC4 = 3;

    private static final int CONNECT_DRIVERMANAGER = 1;
    private static final int CONNECT_DRIVER = 2;
    private static DateFormat df = new SimpleDateFormat("HH:mm:ss.SSS");

    public static void main(String args[]) throws Exception {

        String databaseURL = args.length == 0 ? URL_DEFAULT : args[0];
        String user = args.length < 2 ? USER_DEFAULT : args[1];
        String password = args.length < 3 ? PASSWORD_DEFAULT : args[2];

        java.sql.Driver driver = null;
        java.sql.Connection con = null;
        java.sql.Statement stmt = null;
        java.sql.ResultSet rs = null;

        try {

            Class.forName("org.firebirdsql.jdbc.FBDriver");
            driver = java.sql.DriverManager.getDriver(databaseURL);
            System.out.println("Firebird JCA-JDBC driver version " + driver.getMajorVersion() + "."
                        + driver.getMinorVersion() + " registered with driver manager.");
 
            con = java.sql.DriverManager.getConnection(databaseURL, user, password);
            System.out.println("Connection established.\n\nPress ENTER to start the query. . .");

            System.in.read();

            con.setAutoCommit(false);
            System.out.println("Auto-commit is disabled.");

            stmt = con.createStatement();
            rs = stmt.executeQuery("select count(*) from rdb$types,rdb$types,rdb$types");
            java.sql.ResultSetMetaData rsMetaData = rs.getMetaData();
            System.out.println("The query executed has " + rsMetaData.getColumnCount() + " result columns.");
            System.out.println("Here are the columns: ");
            for (int i = 1; i <= rsMetaData.getColumnCount(); i++) {
              System.out.println(rsMetaData.getColumnName(i) + " of type " + rsMetaData.getColumnTypeName(i));
            }
            System.out.println("query result:");
            while (rs.next()) {
                System.out.println(rs.getString(1));
            } // ==> trace: EXECUTE_STATEMENT_FINISH appears at this point
        } catch(Exception x) {
          x.printStackTrace();
        } finally {
            System.out.println("Closing database resources and rolling back any changes we made to the database.");
            // Now that we're all finished, let's release database resources.
            try {
                if (rs != null) {
                    System.out.println(df.format( System.currentTimeMillis() )+ " BEFORE closing rs, press ENTER. . .");
                    System.in.read();

                    rs.close(); // ==> trace: CLOSE_CURSOR appears at this point

                    System.out.println(df.format( System.currentTimeMillis() )+ " resultSet CLOSED, press ENTER. . .");
                    System.in.read();
                }
                if (stmt != null) {
                    System.out.println(df.format( System.currentTimeMillis() )+ " closing statement. . .");

                    stmt.close(); // ==> trace: FREE_STATEMENT appears ath this point

                    System.out.println(df.format( System.currentTimeMillis() )+ " statement CLOSED, press ENTER. . .");
                    System.in.read();
                }
                if (con != null) {
                    System.out.println(df.format( System.currentTimeMillis() )+ " rolling back. . .");

                    con.rollback(); // trace: ROLLBACK_TRANSACTION

                    System.out.println(df.format( System.currentTimeMillis() )+ " rollback FINISHED, press ENTER. . .");
                    System.in.read();

                    System.out.println(df.format( System.currentTimeMillis() )+ " close connection. . .");

                    con.close(); // trace: DETACH_DATABASE

                    System.out.println(df.format( System.currentTimeMillis() )+ " connection CLOSED, press ENTER. . .");
                    System.in.read();

                }
            } catch (java.sql.SQLException e) {
                showSQLException(e);
            }
        }
    }

    private static void showSQLException(java.sql.SQLException e) {
        java.sql.SQLException next = e;
        while (next != null) {
            System.out.println(next.getMessage());
            System.out.println("Error Code: " + next.getErrorCode());
            System.out.println("SQL State: " + next.getSQLState());
            next = next.getNextException();
        }
    }
}
