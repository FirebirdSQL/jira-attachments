package br;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.rowset.CachedRowSet;

import com.sun.rowset.CachedRowSetImpl;

public class Teste {

	public static void main(String[] args) throws Exception {
		Class.forName("org.firebirdsql.jdbc.FBDriver");

		Connection c = DriverManager.getConnection("jdbc:firebirdsql://127.0.0.1/teste", "sysdba",
				"masterkey");
		PreparedStatement s = c.prepareStatement("select f1 as ff1, f2 as ff2, f3 as ff3 from t1");
		ResultSet rs = s.executeQuery();
		CachedRowSet crs = new CachedRowSetImpl();
		crs.populate(rs);
		rs.close();
		s.close();
		c.close();
		while (crs.next()) {
			System.out.println(crs.getInt("ff1"));
			System.out.println(crs.getString("ff2"));
			System.out.println(crs.getDate("ff3"));
		}
	}

}
