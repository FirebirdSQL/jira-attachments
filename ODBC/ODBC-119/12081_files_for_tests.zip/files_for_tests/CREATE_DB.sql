/******************************************************************************/
/****                            UNIMED ON-LINE                            ****/
/******************************************************************************/

SET SQL DIALECT 3;

SET NAMES WIN1252;

SET CLIENTLIB 'fbclient.dll';

CREATE DATABASE 'localhost:C:\temp\DB.FDB'
  USER 'SYSDBA' PASSWORD 'masterkey'
  PAGE_SIZE 16384
  DEFAULT CHARACTER SET WIN1252 COLLATION WIN_PTBR; /* Firebird 2.5.1*/

/*Produto*/
INPUT TBL_PRODUTOS.SQL;

INPUT TBL_BENEFICIARIOS.SQL;

COMMIT WORK;

