
/******************************************************************************/
/****                              Generators                              ****/
/******************************************************************************/

CREATE GENERATOR GEN_PROD_PK;
/* SET GENERATOR GEN_PROD_PK  TO  0;  */

/******************************************************************************/
/****                              Stored Procedures                       ****/
/******************************************************************************/

SET TERM ^ ;

CREATE PROCEDURE SP_GEN_PROD_PK
RETURNS (
    ID INTEGER)
AS
BEGIN
  EXIT;
END^

SET TERM ; ^

/******************************************************************************/
/****                              Tabelas                                 ****/
/******************************************************************************/

CREATE TABLE TBL_PRODUTOS (
    PROD_PK             INTEGER      NOT NULL,                    /*Chave prim�ria de Produtos*/
    PROD_CODI_PRIN      VARCHAR(14)  NOT NULL COLLATE WIN_PTBR,   /*C�digo Principal do Produto*/
    PROD_CODI_INTE      VARCHAR(14)  NOT NULL COLLATE WIN_PTBR,   /*C�digo interno do Produto*/
    PROD_NOME_PRIN      VARCHAR(100) NOT NULL COLLATE WIN_PTBR,   /*Nome Principal do Produto*/
    PROD_NOME_REDU      VARCHAR(100) NOT NULL COLLATE WIN_PTBR,   /*Nome Interno do Produto*/
    ACOM_FK             INTEGER      NOT NULL,
    SEGE_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Segmenta��o Assistencial*/
    PROD_REFERENCIA     CHAR(1)      NOT NULL COLLATE WIN_PTBR,   /*Refer�ncia (S)im (N)�o*/
    ABRA_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Abrangencia Geogr�fica*/
    ARAB_FK             INTEGER,
    RATE_FK             INTEGER,                                  /*Chave estrangeira - Rede de Atendimento*/
    TICN_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Tipo de Contrata��o*/
    PROD_INIC_COME      DATE         NOT NULL,                    /*Data do In�cio da Comercializa��o*/
    PROD_TERM_COME      DATE,                                     /*Data do Termino da Comercializa��o*/
    TICR_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Tipo da Clausula de Reajuste*/
    PROD_CLAU_REAJ      BLOB SUB_TYPE 1 SEGMENT SIZE 80 NOT NULL COLLATE WIN_PTBR, /*Transcri��o da Cl�usula de reajuste*/
    OCIF_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Outras Clausula de Impacto Financeiro*/
    PROD_CLAU_IMPA      BLOB SUB_TYPE 1 SEGMENT SIZE 80 NOT NULL COLLATE WIN_PTBR, /*Transcri��o da Outra Clausula de Impacto Financeiro*/
    TIRE_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Tipo de Clausula de Recis�o*/
    PROD_CLAU_RECI      BLOB SUB_TYPE 1 SEGMENT SIZE 80 NOT NULL COLLATE WIN_PTBR, /*Transcri��o da Clausula de Recis�o*/
    TIFE_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Tipo de Clausula de Faixa Et�ria*/
    PROD_CLAU_FAIX      BLOB SUB_TYPE 1 SEGMENT SIZE 80 NOT NULL COLLATE WIN_PTBR, /*Transcri��o da Clausula de Faixa Et�ria*/
    ESGE_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Estrutura Gerencial*/
    TIPA_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Tio de Pagamento*/
    FAMO_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - Participa��o nos Eventos*/
    INFI_FK             INTEGER      NOT NULL,                    /*Chave estrangeira - �ndice de Reajuste*/
    PROD_TIPO_REAJ      INTEGER      NOT NULL,                    /*Tipo de Reajuste (1)Ano Civil (2)Ano Contratual*/
    PROD_PUBL_ALVO      BLOB SUB_TYPE 1 SEGMENT SIZE 80 COLLATE WIN_PTBR, /*P�blico Alvo*/
    /* Regras de Subscri��o - Proponente/Contratante */
    PROD_PERS_JURI      CHAR(1)      NOT NULL COLLATE WIN_PTBR,   /*Personalidade Jur�dica (F)�sica;(J)ur�dica*/
    PROD_CONT_MINI_ADES INTEGER      NOT NULL,                    /*Contigente M�nimo para ades�o (em quantidades de vidas)*/
    MOED_FK_FATU_MINI   INTEGER      NOT NULL,                    /*Chave Estrangeira - Moedas (faturamento m�nimo)*/
    PROD_FATU_MINI      NUMERIC(9,2) DEFAULT 0 NOT NULL,          /*Faturamento M�nimo (em quantidades de Moedas)*/
    PROD_CONT_MINI_ENTR INTEGER      NOT NULL,                    /*Contigente M�nimo (em quantidades de vidas)*/
    PROD_ANAL_CRED_PRCO CHAR(1)      NOT NULL COLLATE WIN_PTBR,   /*Processo de an�lise de cr�dito (S)im, (N)�o para o proponente/contratante*/
    /* Regras de Subscri��o - Benefici�rio */
    VICO_FK             INTEGER      NOT NULL,                    /*Chave Estrangeira - V�nculo com o contratante*/
    PROD_SEXO           INTEGER      NOT NULL,                    /*(1)-Masculino (2)-Feminino, (3)-Ambos*/
    PROD_LIMI_FAIX_ETAR INTEGER      NOT NULL,                    /*Limite de faixa et�ria (idade)*/
    PROD_ANAL_CRED_BENE CHAR(1)      NOT NULL COLLATE WIN_PTBR,   /*Processo de an�lise de cr�dito (S)im, (N)�o para o benefici�rio*/
    PROD_IDAD_PERM_DENA INTEGER      NOT NULL,                    /*Idade de perman�ncia de dependentes naturais*/
    PROD_IDAD_PERM_DELE INTEGER      NOT NULL,                    /*Idade de perman�ncia de dependentes Legais*/
    PROD_PRAZ_INSC_RENA INTEGER      NOT NULL,                    /*Prazo em dias para permiss�o para inscri��o de rec�m nato do titular*/
    POCO_FK             INTEGER      NOT NULL,                    /*Chave Estrangeira - Portif�lio Comercial*/
    PLIN_FK             INTEGER      NOT NULL,                    /*Chave Estrangeira - Planos Interc�mbio*/
    PROD_IDEN_REGU      CHAR(1)      NOT NULL COLLATE WIN_PTBR,   /*Identifica se o produto(plano) � regulamentado (S)im, (N)�o*/

    PROD_LIMI_LIBE_CHS  INTEGER,                                  /*Limite de CHS para libera��o autom�tica de procedimentos*/
    PROD_LIMI_LIBE_REA  NUMERIC(9,2) DEFAULT 0 NOT NULL,          /*Limite de Reais para libera��o autom�tica de procedimentos*/

    SENU_FK             INTEGER,                                  /*Chave Estrangeira - Seq��ncia Num�rica*/
    PROD_AREA_ABRA      INTEGER,                                  /*�rea de Abrang�ncia - (1)Local (2)Regional (3)Nacional*/
    PROD_CONT_MINI_CARE INTEGER,                                   
    PROD_CODIGO_CARTAO  CHAR(3) COLLATE WIN_PTBR,
    PROD_DADOS_CARTAO   BLOB SUB_TYPE 1 SEGMENT SIZE 80 COLLATE WIN_PTBR,
    
    PROD_RESUMO_GERAL   BLOB SUB_TYPE 1 SEGMENT SIZE 80 COLLATE WIN_PTBR, /*Resumo do Plano - Informa��es Gerais*/
    PROD_RESUMO_ABRAN   BLOB SUB_TYPE 1 SEGMENT SIZE 80 COLLATE WIN_PTBR, /*Resumo do Plano - Abrang�ncia*/
    PROD_RESUMO_COBER   BLOB SUB_TYPE 1 SEGMENT SIZE 80 COLLATE WIN_PTBR, /*Resumo do Plano - Coberturas*/
    PROD_RESUMO_CAREN   BLOB SUB_TYPE 1 SEGMENT SIZE 80 COLLATE WIN_PTBR, /*Resumo do Plano - Car�ncias*/
    PROD_CODIGO_PEA_PTU VARCHAR(10) COLLATE WIN_PTBR,
    CASP_FK             INTEGER,
    PROD_DIAS_NEGA_INAD INTEGER                                            /*Quantidade de dias considerados para inadimpl�ncia*/
);

/******************************************************************************/
/****                             Primary Keys                             ****/
/******************************************************************************/

ALTER TABLE TBL_PRODUTOS ADD CONSTRAINT PRI_PROD_PK PRIMARY KEY (PROD_PK);

/******************************************************************************/
/****                               Indices                                ****/
/******************************************************************************/

CREATE UNIQUE INDEX IDX_PROD_CODI_PRIN ON TBL_PRODUTOS (PROD_CODI_PRIN);
CREATE UNIQUE INDEX IDX_PROD_CODI_INTE ON TBL_PRODUTOS (PROD_CODI_INTE);
CREATE        INDEX IDX_PROD_NOME_PRIN ON TBL_PRODUTOS (PROD_NOME_PRIN);
CREATE        INDEX IDX_PROD_NOME_REDU ON TBL_PRODUTOS (PROD_NOME_REDU);
CREATE        INDEX IDX_PROD_INIC_COME ON TBL_PRODUTOS (PROD_INIC_COME);
CREATE        INDEX IDX_PROD_TERM_COME ON TBL_PRODUTOS (PROD_TERM_COME);
CREATE        INDEX IDX_PROD_AREA_ABRA ON TBL_PRODUTOS (PROD_AREA_ABRA);
CREATE        INDEX IDX_PROD_IDEN_REGU ON TBL_PRODUTOS (PROD_IDEN_REGU);

/******************************************************************************/
/****                               Triggers                               ****/
/******************************************************************************/

SET TERM ^ ;

/* Trigger: TRI_PROD_PK */
CREATE TRIGGER TRI_PROD_PK FOR TBL_PRODUTOS
ACTIVE BEFORE INSERT POSITION 0
AS
DECLARE VARIABLE TEMP INTEGER;
BEGIN

  IF (NEW.PROD_PK IS NULL) THEN
  BEGIN
    NEW.PROD_PK = GEN_ID(GEN_PROD_PK, 1);
  END
  ELSE
  BEGIN
    IF (NEW.PROD_PK > GEN_ID(GEN_PROD_PK, 0)) THEN
    BEGIN
       TEMP = GEN_ID(GEN_PROD_PK, NEW.PROD_PK - GEN_ID(GEN_PROD_PK, 0));
    END
  END

END
^

SET TERM ; ^

/******************************************************************************/
/****                              Stored Procedures                       ****/
/******************************************************************************/

SET TERM ^ ;

ALTER PROCEDURE SP_GEN_PROD_PK
RETURNS (
    ID INTEGER)
AS
BEGIN
  ID = GEN_ID(GEN_PROD_PK, 1);
  SUSPEND;
END^

SET TERM ; ^
