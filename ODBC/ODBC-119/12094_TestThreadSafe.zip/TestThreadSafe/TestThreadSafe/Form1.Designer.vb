﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.but_teste3 = New System.Windows.Forms.Button()
        Me.but_teste4 = New System.Windows.Forms.Button()
        Me.but_TestLoadingDataWithFirebirdODBCDriver = New System.Windows.Forms.Button()
        Me.chk_safethread = New System.Windows.Forms.CheckBox()
        Me.but_TestLoadingDataWithNETFirebirdClient = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbt_datareaderadapter = New System.Windows.Forms.RadioButton()
        Me.rbt_dataadapter = New System.Windows.Forms.RadioButton()
        Me.rbt_datareader = New System.Windows.Forms.RadioButton()
        Me.lsb_erros = New System.Windows.Forms.ListBox()
        Me.btnCreateDatabase = New System.Windows.Forms.Button()
        Me.btnInsertRecords = New System.Windows.Forms.Button()
        Me.chk_log_erros = New System.Windows.Forms.CheckBox()
        Me.but_suggestions = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'but_teste3
        '
        Me.but_teste3.Location = New System.Drawing.Point(213, 174)
        Me.but_teste3.Name = "but_teste3"
        Me.but_teste3.Size = New System.Drawing.Size(243, 23)
        Me.but_teste3.TabIndex = 7
        Me.but_teste3.Text = "Test Speed with Firebird ODBC Driver"
        Me.but_teste3.UseVisualStyleBackColor = True
        '
        'but_teste4
        '
        Me.but_teste4.Location = New System.Drawing.Point(213, 203)
        Me.but_teste4.Name = "but_teste4"
        Me.but_teste4.Size = New System.Drawing.Size(243, 23)
        Me.but_teste4.TabIndex = 8
        Me.but_teste4.Text = "Test Speed with .NET Firebird Client "
        Me.but_teste4.UseVisualStyleBackColor = True
        '
        'but_TestLoadingDataWithFirebirdODBCDriver
        '
        Me.but_TestLoadingDataWithFirebirdODBCDriver.Location = New System.Drawing.Point(213, 89)
        Me.but_TestLoadingDataWithFirebirdODBCDriver.Name = "but_TestLoadingDataWithFirebirdODBCDriver"
        Me.but_TestLoadingDataWithFirebirdODBCDriver.Size = New System.Drawing.Size(243, 23)
        Me.but_TestLoadingDataWithFirebirdODBCDriver.TabIndex = 4
        Me.but_TestLoadingDataWithFirebirdODBCDriver.Text = "Test loading data with Firebird ODBC Driver"
        Me.but_TestLoadingDataWithFirebirdODBCDriver.UseVisualStyleBackColor = True
        '
        'chk_safethread
        '
        Me.chk_safethread.AutoSize = True
        Me.chk_safethread.Location = New System.Drawing.Point(213, 66)
        Me.chk_safethread.Name = "chk_safethread"
        Me.chk_safethread.Size = New System.Drawing.Size(118, 17)
        Me.chk_safethread.TabIndex = 3
        Me.chk_safethread.Text = "ODBC Safe Thread"
        Me.chk_safethread.UseVisualStyleBackColor = True
        '
        'but_TestLoadingDataWithNETFirebirdClient
        '
        Me.but_TestLoadingDataWithNETFirebirdClient.Location = New System.Drawing.Point(213, 114)
        Me.but_TestLoadingDataWithNETFirebirdClient.Name = "but_TestLoadingDataWithNETFirebirdClient"
        Me.but_TestLoadingDataWithNETFirebirdClient.Size = New System.Drawing.Size(243, 23)
        Me.but_TestLoadingDataWithNETFirebirdClient.TabIndex = 5
        Me.but_TestLoadingDataWithNETFirebirdClient.Text = "Test loading data with .NET Firebird Client "
        Me.but_TestLoadingDataWithNETFirebirdClient.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbt_datareaderadapter)
        Me.GroupBox1.Controls.Add(Me.rbt_dataadapter)
        Me.GroupBox1.Controls.Add(Me.rbt_datareader)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 56)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(191, 90)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Load data with"
        '
        'rbt_datareaderadapter
        '
        Me.rbt_datareaderadapter.AutoSize = True
        Me.rbt_datareaderadapter.Checked = True
        Me.rbt_datareaderadapter.Location = New System.Drawing.Point(6, 64)
        Me.rbt_datareaderadapter.Name = "rbt_datareaderadapter"
        Me.rbt_datareaderadapter.Size = New System.Drawing.Size(173, 17)
        Me.rbt_datareaderadapter.TabIndex = 2
        Me.rbt_datareaderadapter.TabStop = True
        Me.rbt_datareaderadapter.Text = "Data Reader and Data Adapter"
        Me.rbt_datareaderadapter.UseVisualStyleBackColor = True
        '
        'rbt_dataadapter
        '
        Me.rbt_dataadapter.AutoSize = True
        Me.rbt_dataadapter.Location = New System.Drawing.Point(6, 41)
        Me.rbt_dataadapter.Name = "rbt_dataadapter"
        Me.rbt_dataadapter.Size = New System.Drawing.Size(88, 17)
        Me.rbt_dataadapter.TabIndex = 1
        Me.rbt_dataadapter.Text = "Data Adapter"
        Me.rbt_dataadapter.UseVisualStyleBackColor = True
        '
        'rbt_datareader
        '
        Me.rbt_datareader.AutoSize = True
        Me.rbt_datareader.Location = New System.Drawing.Point(6, 19)
        Me.rbt_datareader.Name = "rbt_datareader"
        Me.rbt_datareader.Size = New System.Drawing.Size(86, 17)
        Me.rbt_datareader.TabIndex = 0
        Me.rbt_datareader.Text = "Data Reader"
        Me.rbt_datareader.UseVisualStyleBackColor = True
        '
        'lsb_erros
        '
        Me.lsb_erros.FormattingEnabled = True
        Me.lsb_erros.Location = New System.Drawing.Point(16, 264)
        Me.lsb_erros.Name = "lsb_erros"
        Me.lsb_erros.Size = New System.Drawing.Size(633, 121)
        Me.lsb_erros.TabIndex = 10
        Me.lsb_erros.Visible = False
        '
        'btnCreateDatabase
        '
        Me.btnCreateDatabase.Location = New System.Drawing.Point(16, 12)
        Me.btnCreateDatabase.Name = "btnCreateDatabase"
        Me.btnCreateDatabase.Size = New System.Drawing.Size(110, 38)
        Me.btnCreateDatabase.TabIndex = 0
        Me.btnCreateDatabase.Text = "Create DataBase"
        Me.btnCreateDatabase.UseVisualStyleBackColor = True
        '
        'btnInsertRecords
        '
        Me.btnInsertRecords.Location = New System.Drawing.Point(132, 12)
        Me.btnInsertRecords.Name = "btnInsertRecords"
        Me.btnInsertRecords.Size = New System.Drawing.Size(110, 38)
        Me.btnInsertRecords.TabIndex = 1
        Me.btnInsertRecords.Text = "Insert Records"
        Me.btnInsertRecords.UseVisualStyleBackColor = True
        '
        'chk_log_erros
        '
        Me.chk_log_erros.AutoSize = True
        Me.chk_log_erros.Location = New System.Drawing.Point(16, 241)
        Me.chk_log_erros.Name = "chk_log_erros"
        Me.chk_log_erros.Size = New System.Drawing.Size(71, 17)
        Me.chk_log_erros.TabIndex = 9
        Me.chk_log_erros.Text = "Log Erros"
        Me.chk_log_erros.UseVisualStyleBackColor = True
        Me.chk_log_erros.Visible = False
        '
        'but_suggestions
        '
        Me.but_suggestions.Location = New System.Drawing.Point(248, 12)
        Me.but_suggestions.Name = "but_suggestions"
        Me.but_suggestions.Size = New System.Drawing.Size(133, 38)
        Me.but_suggestions.TabIndex = 6
        Me.but_suggestions.Text = "suggestions for solving"
        Me.but_suggestions.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(472, 236)
        Me.Controls.Add(Me.but_suggestions)
        Me.Controls.Add(Me.chk_log_erros)
        Me.Controls.Add(Me.btnInsertRecords)
        Me.Controls.Add(Me.btnCreateDatabase)
        Me.Controls.Add(Me.lsb_erros)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.but_TestLoadingDataWithNETFirebirdClient)
        Me.Controls.Add(Me.chk_safethread)
        Me.Controls.Add(Me.but_TestLoadingDataWithFirebirdODBCDriver)
        Me.Controls.Add(Me.but_teste4)
        Me.Controls.Add(Me.but_teste3)
        Me.Name = "Form1"
        Me.Text = "TestThreadSafe"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents but_teste3 As System.Windows.Forms.Button
    Friend WithEvents but_teste4 As System.Windows.Forms.Button
    Friend WithEvents but_TestLoadingDataWithFirebirdODBCDriver As System.Windows.Forms.Button
    Friend WithEvents chk_safethread As System.Windows.Forms.CheckBox
    Friend WithEvents but_TestLoadingDataWithNETFirebirdClient As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbt_datareaderadapter As System.Windows.Forms.RadioButton
    Friend WithEvents rbt_dataadapter As System.Windows.Forms.RadioButton
    Friend WithEvents rbt_datareader As System.Windows.Forms.RadioButton
    Friend WithEvents lsb_erros As System.Windows.Forms.ListBox
    Friend WithEvents btnCreateDatabase As System.Windows.Forms.Button
    Friend WithEvents btnInsertRecords As System.Windows.Forms.Button
    Friend WithEvents chk_log_erros As System.Windows.Forms.CheckBox
    Friend WithEvents but_suggestions As System.Windows.Forms.Button

End Class
