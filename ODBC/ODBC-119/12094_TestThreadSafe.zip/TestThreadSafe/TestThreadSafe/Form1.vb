﻿Imports FirebirdSql.Data.FirebirdClient
Imports Microsoft.VisualBasic
Imports System.Data.Odbc
Imports System.IO
Imports System.Threading
Imports System.Text

Public Class Form1

    Dim StrConnOdbc As String = "Driver={Firebird/InterBase(r) driver};dbname=localhost:c:\temp\DbTest.fdb;charset=WIN1252;uid=SYSDBA;pwd=masterkey;client=fbclient.dll;SAFETHREAD=N"
    Dim StrConnOdbcSafeThread As String = "Driver={Firebird/InterBase(r) driver};dbname=localhost:c:\temp\DbTest.fdb;charset=WIN1252;uid=SYSDBA;pwd=masterkey;client=fbclient.dll;SAFETHREAD=Y"

    Dim StrConnFbNET As String = "character set=WIN1252;data source=localhost;initial catalog=c:\temp\DbTest.fdb;user id=SYSDBA;password=masterkey;pooling=True;maxpoolsize=100;minpoolsize=0;connectionlifetime=15;connectiontimeout=30;dialect=3"

    Dim mConnODBC As OdbcConnection
    Dim mConnFbNET As FbConnection

    Dim mThread1 As Thread
    Dim mThread2 As Thread

    Private WithEvents mProc As System.Diagnostics.Process
    Private startInfo As ProcessStartInfo

    Private Sub btnCreateDatabase_Click(sender As System.Object, e As System.EventArgs) Handles btnCreateDatabase.Click

        Dim mSql As New StringBuilder
        Dim mFile As String
        Dim mValues() As String
        Dim mIsqlExe As String

        Dim mReg As Microsoft.Win32.RegistryKey

        Dim mFileInfo As System.IO.FileInfo

        mReg = My.Computer.Registry.LocalMachine.OpenSubKey("SYSTEM\ControlSet001\services\FirebirdGuardianDefaultInstance")

        If mReg Is Nothing Then
            mReg = My.Computer.Registry.LocalMachine.OpenSubKey("SYSTEM\ControlSet001\services\FirebirdServerDefaultInstance")
        End If

        mFile = mReg.GetValue("ImagePath")
        mValues = mFile.Split("""")

        mFileInfo = New FileInfo(mValues(1))

        mIsqlExe = mFileInfo.DirectoryName

        If mIsqlExe.Substring(mIsqlExe.Length - 1, 1) <> "\" Then
            mIsqlExe = String.Concat(mIsqlExe, "\")
        End If

        mIsqlExe = String.Concat(mIsqlExe, "isql.exe")

        If Not System.IO.Directory.Exists("c:\temp") Then
            System.IO.Directory.CreateDirectory("c:\temp")
        End If

        If System.IO.File.Exists("c:\temp\DbTest.fdb") Then
            System.IO.File.Delete("c:\temp\DbTest.fdb")
        End If

        Using TxtWriter As New System.IO.StreamWriter("c:\temp\DbTest.sql", False, System.Text.Encoding.ASCII)

            mSql = New StringBuilder

            mSql.AppendLine(" SET SQL DIALECT 3; ")
            mSql.AppendLine(" SET NAMES WIN1252; ")

            mSql.AppendLine(" CREATE DATABASE 'localhost:c:\temp\DbTest.fdb' ")
            mSql.AppendLine("   USER 'SYSDBA' PASSWORD 'masterkey' ")
            mSql.AppendLine("   PAGE_SIZE 16384 ")
            mSql.AppendLine("   DEFAULT CHARACTER SET WIN1252; ")

            mSql.AppendLine(" CREATE TABLE TABLETEST ( ")
            mSql.AppendLine("     ID     INTEGER NOT NULL, ")
            mSql.AppendLine("     BLOB1  BLOB SUB_TYPE 1 SEGMENT SIZE 80 ")
            mSql.AppendLine(" ); ")

            mSql.AppendLine(" ALTER TABLE TABLETEST ADD CONSTRAINT PK_TABLETEST PRIMARY KEY (ID); ")

            TxtWriter.Write(mSql.ToString)

            TxtWriter.Flush()
            TxtWriter.Close()

        End Using

        startInfo = New ProcessStartInfo(mIsqlExe)
        startInfo.Arguments = String.Concat("-q -i c:\temp\DbTest.sql")
        startInfo.CreateNoWindow = False
        startInfo.WindowStyle = ProcessWindowStyle.Hidden

        mProc = New System.Diagnostics.Process
        mProc.EnableRaisingEvents = True
        mProc.StartInfo = startInfo
        mProc.Start()
        mProc.WaitForExit()

        MsgBox("Database was created", MsgBoxStyle.Information)

    End Sub

    Private Sub btnInsertRecords_Click(sender As System.Object, e As System.EventArgs) Handles btnInsertRecords.Click

        Dim mSql As New StringBuilder

        Using mConn As New OdbcConnection(StrConnOdbcSafeThread)

            mConn.Open()

            mSql = New StringBuilder

            mSql.AppendLine(" INSERT INTO TABLETEST ( ")
            mSql.AppendLine("     ID, ")
            mSql.AppendLine("     BLOB1 ")
            mSql.AppendLine(" ) VALUES ( ")
            mSql.AppendLine("     ?, ")
            mSql.AppendLine("     ? ")
            mSql.AppendLine(" ) ")

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                mCmd.Parameters.Add("ID", OdbcType.Int, 0, "ID").Value = 1
                mCmd.Parameters.Add("BLOB1", OdbcType.Text, 0, "BLOB1").Value = "Data for test"

                mCmd.ExecuteNonQuery()

            End Using

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                mCmd.Parameters.Add("ID", OdbcType.Int, 0, "ID").Value = 2
                mCmd.Parameters.Add("BLOB1", OdbcType.NText, 0, "BLOB1").Value = "Data for test"

                mCmd.ExecuteNonQuery()

            End Using

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                mCmd.Parameters.Add("ID", OdbcType.Int, 0, "ID").Value = 4
                mCmd.Parameters.Add("BLOB1", OdbcType.VarChar, 0, "BLOB1").Value = "Data for test"

                mCmd.ExecuteNonQuery()

            End Using

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                mCmd.Parameters.Add("ID", OdbcType.Int, 0, "ID").Value = 3
                mCmd.Parameters.Add("BLOB1", OdbcType.NVarChar, 0, "BLOB1").Value = "Data for test"

                mCmd.ExecuteNonQuery()

            End Using

            mConn.Close()

        End Using

        MsgBox("Records was inserted", MsgBoxStyle.Information)

    End Sub

    Private Sub but_TestLoadingDataWithFirebirdODBCDriver_Click(sender As System.Object, e As System.EventArgs) Handles but_TestLoadingDataWithFirebirdODBCDriver.Click

        lsb_erros.Items.Clear()

        If Not mConnODBC Is Nothing Then
            If mConnODBC.State <> ConnectionState.Closed Then
                mConnODBC.Close()
            End If
            mConnODBC.Dispose()
        End If

        If chk_safethread.Checked Then
            mConnODBC = New OdbcConnection(StrConnOdbcSafeThread)
        Else
            mConnODBC = New OdbcConnection(StrConnOdbc)
        End If

        mConnODBC.Open()

        If rbt_datareader.Checked Then

            mThread1 = New Thread(New ThreadStart(AddressOf TesteODBCLoadingWithDataReader))
            mThread2 = New Thread(New ThreadStart(AddressOf TesteODBCLoadingWithDataReader))

            mThread1.Start()
            mThread2.Start()

        End If

        If rbt_dataadapter.Checked Then

            mThread1 = New Thread(New ThreadStart(AddressOf TesteODBCLoadingWithDataAdapter))
            mThread2 = New Thread(New ThreadStart(AddressOf TesteODBCLoadingWithDataAdapter))

            mThread1.Start()
            mThread2.Start()

        End If

        If rbt_datareaderadapter.Checked Then

            mThread1 = New Thread(New ThreadStart(AddressOf TesteODBCLoadingWithDataAdapter))
            mThread2 = New Thread(New ThreadStart(AddressOf TesteODBCLoadingWithDataReader))

            mThread1.Start()
            mThread2.Start()

        End If

        My.Application.DoEvents()

    End Sub

    ''' <summary>
    '''some errors reported:
    '''System.AccessViolationException: Attempted to read or write protected memory. This is often an indication that other memory is corrupt.
    '''ERROR [08S01] [ODBC Firebird Driver][Firebird]Error reading data from the connection.
    '''ERROR [HY000] [ODBC Firebird Driver][Firebird]request synchronization error
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub TesteODBCLoadingWithDataAdapter()
        Dim x As Integer
        Dim mDs As DataSet

        mDs = New DataSet

        My.Application.DoEvents()

        For x = 1 To 100

            'Try

            '    '    'SyncLock _LockObject2

            Using mCmd2 As New OdbcCommand("SELECT * FROM TABLETEST", mConnODBC)

                Using mAdp2 As New OdbcDataAdapter(mCmd2)
                    mAdp2.Fill(mDs, "TABLETEST")
                End Using

            End Using

            '    '    'End SyncLock

            'Catch ex As Exception

            '    If chk_log_erros.Checked Then
            '        AtualizaErros(ex)
            '    Else
            '        Throw New Exception("Error", ex)
            '    End If

            'End Try

        Next

        My.Application.DoEvents()

    End Sub

    ''' <summary>
    ''' some errors reported:
    '''Attempted to read or write protected memory. This is often an indication that other memory is corrupt.
    '''ERROR [08S01] [ODBC Firebird Driver][Firebird]Error reading data from the connection.
    '''ERROR [HY000] [ODBC Firebird Driver][Firebird]request synchronization error
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub TesteODBCLoadingWithDataReader()
        Dim x, y As Integer
        Dim mObj As Object
        Dim Count As Integer

        My.Application.DoEvents()

        For x = 1 To 100

            'Try

            '    '        'SyncLock _LockObject2

            Using mCmd3 As New OdbcCommand("SELECT * FROM TABLETEST", mConnODBC)

                Using mDrd3 As OdbcDataReader = mCmd3.ExecuteReader()

                    Count = mDrd3.FieldCount - 1

                    Do While mDrd3.Read()
                        For y = 0 To Count
                            mObj = mDrd3(y)
                        Next
                    Loop

                End Using

            End Using

            '    '        'End SyncLock

            'Catch ex As Exception

            '    If chk_log_erros.Checked Then
            '        AtualizaErros(ex)
            '    Else
            '        Throw New Exception("Error", ex)
            '    End If

            'End Try

        Next

        My.Application.DoEvents()

    End Sub

    Private Delegate Sub DelAtualizaErros(pEx As Exception)

    Private Shared _LockObject1 As New Object
    Private Shared _LockObject2 As New Object
    Private Shared _LockObject3 As New Object

    Private Sub AtualizaErros(pEx As Exception)

        'SyncLock _LockObject1

        'Try

        If Me.InvokeRequired Then
            Dim mDelAtualizaErros As New DelAtualizaErros(AddressOf Me.AtualizaErros)
            Me.Invoke(mDelAtualizaErros, New Object() {pEx})
        Else
            lsb_erros.Items.Add(pEx.Message)
        End If

        'Catch ex As Exception

        '    If chk_log_erros.Checked Then
        '        AtualizaErros(ex)
        '    Else
        '        Throw New Exception("Error", ex)
        '    End If

        'End Try

        'End SyncLock

    End Sub

    Private Sub but_TestLoadingDataWithNETFirebirdClient_Click(sender As System.Object, e As System.EventArgs) Handles but_TestLoadingDataWithNETFirebirdClient.Click

        If Not mConnFbNET Is Nothing Then
            If mConnFbNET.State <> ConnectionState.Closed Then
                mConnFbNET.Close()
            End If
            mConnFbNET.Dispose()
        End If

        mConnFbNET = New FbConnection(StrConnFbNET)

        mConnFbNET.Open()

        If rbt_datareader.Checked Then

            mThread1 = New Thread(New ThreadStart(AddressOf TesteNETFirebirdClientLoadingWithDataReader))
            mThread2 = New Thread(New ThreadStart(AddressOf TesteNETFirebirdClientLoadingWithDataReader))

            mThread1.Start()
            mThread2.Start()

        End If

        If rbt_dataadapter.Checked Then

            mThread1 = New Thread(New ThreadStart(AddressOf TesteNETFirebirdClientLoadingWithDataAdapter))
            mThread2 = New Thread(New ThreadStart(AddressOf TesteNETFirebirdClientLoadingWithDataAdapter))

            mThread1.Start()
            mThread2.Start()

        End If

        If rbt_datareaderadapter.Checked Then

            mThread1 = New Thread(New ThreadStart(AddressOf TesteNETFirebirdClientLoadingWithDataAdapter))
            mThread2 = New Thread(New ThreadStart(AddressOf TesteNETFirebirdClientLoadingWithDataReader))

            mThread1.Start()
            mThread2.Start()

        End If

        My.Application.DoEvents()

    End Sub


    Protected Sub TesteNETFirebirdClientLoadingWithDataAdapter()
        Dim x As Integer
        Dim mDs As DataSet

        mDs = New DataSet

        My.Application.DoEvents()

        For x = 1 To 100

            Using mCmd2 As New FbCommand("SELECT * FROM TABLETEST", mConnFbNET)

                Using mAdp2 As New FbDataAdapter(mCmd2)
                    mAdp2.Fill(mDs, "TABLETEST")
                End Using

            End Using

        Next

        My.Application.DoEvents()

    End Sub

    Protected Sub TesteNETFirebirdClientLoadingWithDataReader()
        Dim x, y As Integer
        Dim mObj As Object
        Dim Count As Integer

        My.Application.DoEvents()

        For x = 1 To 100

            Using mCmd3 As New FbCommand("SELECT * FROM TABLETEST", mConnFbNET)

                Using mDrd3 As FbDataReader = mCmd3.ExecuteReader()

                    Count = mDrd3.FieldCount - 1

                    Do While mDrd3.Read()
                        For y = 0 To Count
                            mObj = mDrd3(y)
                        Next
                    Loop

                End Using

            End Using

        Next

        My.Application.DoEvents()

    End Sub

    Private Sub but_teste3_Click(sender As System.Object, e As System.EventArgs) Handles but_teste3.Click

        Dim x As Integer
        Dim mStartTimer As Date

        Dim mLocalStrCon As String

        If chk_safethread.Checked Then
            mLocalStrCon = StrConnOdbcSafeThread
        Else
            mLocalStrCon = StrConnOdbc
        End If

        mStartTimer = Now

        My.Application.DoEvents()

        For x = 1 To 1000

            Using mConn As New OdbcConnection(mLocalStrCon)
                mConn.Open()
            End Using

        Next

        My.Application.DoEvents()

        MsgBox(String.Format("End {0}", x, Microsoft.VisualBasic.DateDiff(DateInterval.Second, mStartTimer, Now)))

    End Sub

    Private Sub but_teste4_Click(sender As System.Object, e As System.EventArgs) Handles but_teste4.Click
        Dim x As Integer
        Dim mStartTimer As Date

        mStartTimer = Now

        My.Application.DoEvents()

        For x = 1 To 1000

            Using mConnFbNET As New FbConnection(StrConnFbNET)
                mConnFbNET.Open()
            End Using

        Next

        My.Application.DoEvents()

        MsgBox(String.Format("End {0}", Microsoft.VisualBasic.DateDiff(DateInterval.Second, mStartTimer, Now)))

    End Sub

    Private Sub but_suggestions_Click(sender As System.Object, e As System.EventArgs) Handles but_suggestions.Click

        Dim mSuggestions As StringBuilder

        mSuggestions = New StringBuilder

        mSuggestions.AppendLine("some errors reported:")
        mSuggestions.AppendLine("")
        mSuggestions.AppendLine("(1) System.AccessViolationException: Attempted to read or write protected memory. This is often an indication that other memory is corrupt.")
        mSuggestions.AppendLine("")
        mSuggestions.AppendLine("(2) ERROR [08S01] [ODBC Firebird Driver][Firebird]Error reading data from the connection.")
        mSuggestions.AppendLine("")
        mSuggestions.AppendLine("(3) ERROR [HY000] [ODBC Firebird Driver][Firebird]request synchronization error.")

        mSuggestions.AppendLine("")
        mSuggestions.AppendLine("-------------------------------------------------------------------")
        mSuggestions.AppendLine("")

        mSuggestions.AppendLine("The read error occurs when the option is not used thread-safe.")
        mSuggestions.AppendLine("As a suggestion, it would be nice if the thread-safe option was enabled by default in the drive.")
        mSuggestions.AppendLine("not passing the attribute SAFETHREAD = Y in the connection string.")
        mSuggestions.AppendLine("because in most ODBC drivers are already thread-safe without any attribute.")

        MsgBox(mSuggestions.ToString(), MsgBoxStyle.Information)

    End Sub

End Class
