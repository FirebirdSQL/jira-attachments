﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnCreateDatabase = New System.Windows.Forms.Button
        Me.btnInsertRecords = New System.Windows.Forms.Button
        Me.btnLoadRecords = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.txtData = New System.Windows.Forms.TextBox
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnCreateDatabase
        '
        Me.btnCreateDatabase.Location = New System.Drawing.Point(12, 26)
        Me.btnCreateDatabase.Name = "btnCreateDatabase"
        Me.btnCreateDatabase.Size = New System.Drawing.Size(110, 38)
        Me.btnCreateDatabase.TabIndex = 0
        Me.btnCreateDatabase.Text = "Create DataBase"
        Me.btnCreateDatabase.UseVisualStyleBackColor = True
        '
        'btnInsertRecords
        '
        Me.btnInsertRecords.Location = New System.Drawing.Point(12, 143)
        Me.btnInsertRecords.Name = "btnInsertRecords"
        Me.btnInsertRecords.Size = New System.Drawing.Size(110, 38)
        Me.btnInsertRecords.TabIndex = 1
        Me.btnInsertRecords.Text = "Insert Records"
        Me.btnInsertRecords.UseVisualStyleBackColor = True
        '
        'btnLoadRecords
        '
        Me.btnLoadRecords.Location = New System.Drawing.Point(128, 143)
        Me.btnLoadRecords.Name = "btnLoadRecords"
        Me.btnLoadRecords.Size = New System.Drawing.Size(110, 38)
        Me.btnLoadRecords.TabIndex = 2
        Me.btnLoadRecords.Text = "Load Records"
        Me.btnLoadRecords.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 187)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(342, 169)
        Me.DataGridView1.TabIndex = 3
        '
        'txtData
        '
        Me.txtData.Location = New System.Drawing.Point(12, 75)
        Me.txtData.Multiline = True
        Me.txtData.Name = "txtData"
        Me.txtData.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtData.Size = New System.Drawing.Size(342, 62)
        Me.txtData.TabIndex = 4
        Me.txtData.Text = resources.GetString("txtData.Text")
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(363, 368)
        Me.Controls.Add(Me.txtData)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnLoadRecords)
        Me.Controls.Add(Me.btnInsertRecords)
        Me.Controls.Add(Me.btnCreateDatabase)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCreateDatabase As System.Windows.Forms.Button
    Friend WithEvents btnInsertRecords As System.Windows.Forms.Button
    Friend WithEvents btnLoadRecords As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents txtData As System.Windows.Forms.TextBox

End Class
