﻿Imports System.Text
Imports System.IO
Imports System.Data.Odbc
Imports Microsoft.VisualBasic

Public Class Form1

    Private WithEvents mProc As System.Diagnostics.Process
    Private startInfo As ProcessStartInfo

    Private Sub btnCreateDatabase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateDatabase.Click

        Dim mSql As New StringBuilder
        Dim mFile As String
        Dim mValues() As String
        Dim mIsqlExe As String

        Dim mReg As Microsoft.Win32.RegistryKey

        Dim mFileInfo As System.IO.FileInfo

        mReg = My.Computer.Registry.LocalMachine.OpenSubKey("SYSTEM\ControlSet001\services\FirebirdGuardianDefaultInstance")
        mFile = mReg.GetValue("ImagePath")
        mValues = mFile.Split("""")

        mFileInfo = New FileInfo(mValues(1))

        mIsqlExe = mFileInfo.DirectoryName

        If mIsqlExe.Substring(mIsqlExe.Length - 1, 1) <> "\" Then
            mIsqlExe = String.Concat(mIsqlExe, "\")
        End If

        mIsqlExe = String.Concat(mIsqlExe, "isql.exe")

        If Not System.IO.Directory.Exists("c:\temp") Then
            System.IO.Directory.CreateDirectory("c:\temp")
        End If

        If System.IO.File.Exists("c:\temp\DbTest.fdb") Then
            System.IO.File.Delete("c:\temp\DbTest.fdb")
        End If

        Using TxtWriter As New System.IO.StreamWriter("c:\temp\DbTest.sql", False, System.Text.Encoding.ASCII)

            mSql = New StringBuilder

            mSql.AppendLine(" SET SQL DIALECT 3; ")
            mSql.AppendLine(" SET NAMES WIN1252; ")

            mSql.AppendLine(" CREATE DATABASE 'localhost:c:\temp\DbTest.fdb' ")
            mSql.AppendLine("   USER 'SYSDBA' PASSWORD 'masterkey' ")
            mSql.AppendLine("   PAGE_SIZE 16384 ")
            mSql.AppendLine("   DEFAULT CHARACTER SET WIN1252; ")

            mSql.AppendLine(" CREATE TABLE TABLETEST ( ")
            mSql.AppendLine("     ID     INTEGER NOT NULL, ")
            mSql.AppendLine("     BLOB1  BLOB SUB_TYPE 1 SEGMENT SIZE 80 ")
            mSql.AppendLine(" ); ")

            mSql.AppendLine(" ALTER TABLE TABLETEST ADD CONSTRAINT PK_TABLETEST PRIMARY KEY (ID); ")

            TxtWriter.Write(mSql.ToString)

            TxtWriter.Flush()
            TxtWriter.Close()

        End Using

        startInfo = New ProcessStartInfo(mIsqlExe)
        startInfo.Arguments = String.Concat("-q -i c:\temp\DbTest.sql")
        startInfo.CreateNoWindow = False
        startInfo.WindowStyle = ProcessWindowStyle.Hidden

        mProc = New System.Diagnostics.Process
        mProc.EnableRaisingEvents = True
        mProc.StartInfo = startInfo
        mProc.Start()
        mProc.WaitForExit()

        MsgBox("Database was created", MsgBoxStyle.Information)

    End Sub

    Private Sub btnInsertRecords_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertRecords.Click

        Dim mSql As New StringBuilder

        Using mConn As New OdbcConnection("Driver={Firebird/InterBase(r) driver};dbname=localhost:c:\temp\DbTest.fdb;uid=SYSDBA;CHARACTERSET=WIN1252;dialect=3;pwd=masterkey;CLIENT=C:\Windows\System32\GDS32.DLL")

            mConn.Open()

            mSql = New StringBuilder

            mSql.AppendLine(" INSERT INTO TABLETEST ( ")
            mSql.AppendLine("     ID, ")
            mSql.AppendLine("     BLOB1 ")
            mSql.AppendLine(" ) VALUES ( ")
            mSql.AppendLine("     ?, ")
            mSql.AppendLine("     ? ")
            mSql.AppendLine(" ) ")

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                mCmd.Parameters.Add("ID", OdbcType.Int, 0, "ID").Value = 1
                mCmd.Parameters.Add("BLOB1", OdbcType.Text, 0, "BLOB1").Value = txtData.Text

                mCmd.ExecuteNonQuery()

            End Using

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                mCmd.Parameters.Add("ID", OdbcType.Int, 0, "ID").Value = 2
                mCmd.Parameters.Add("BLOB1", OdbcType.NText, 0, "BLOB1").Value = txtData.Text

                mCmd.ExecuteNonQuery()

            End Using

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                mCmd.Parameters.Add("ID", OdbcType.Int, 0, "ID").Value = 4
                mCmd.Parameters.Add("BLOB1", OdbcType.VarChar, 0, "BLOB1").Value = txtData.Text

                mCmd.ExecuteNonQuery()

            End Using

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                mCmd.Parameters.Add("ID", OdbcType.Int, 0, "ID").Value = 3
                mCmd.Parameters.Add("BLOB1", OdbcType.NVarChar, 0, "BLOB1").Value = txtData.Text

                mCmd.ExecuteNonQuery()

            End Using

            mConn.Close()

        End Using

        MsgBox("Records was inserted", MsgBoxStyle.Information)

    End Sub

    Dim mDs As System.Data.DataSet
    Dim mTb As System.Data.DataTable

    Private Sub btnLoadRecords_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadRecords.Click
        Dim mSql As New StringBuilder

        Using mConn As New OdbcConnection("Driver={Firebird/InterBase(r) driver};dbname=localhost:c:\temp\DbTest.fdb;uid=SYSDBA;CHARACTERSET=WIN1252;dialect=3;pwd=masterkey;CLIENT=C:\Windows\System32\GDS32.DLL")

            mConn.Open()

            mSql = New StringBuilder

            mSql.AppendLine(" SELECT ")
            mSql.AppendLine("     ID, ")
            mSql.AppendLine("     BLOB1 ")
            mSql.AppendLine(" FROM ")
            mSql.AppendLine("     TABLETEST ")
            mSql.AppendLine(" ORDER BY ")
            mSql.AppendLine("     ID ")

            Using mCmd = New OdbcCommand(mSql.ToString, mConn)

                Using mDr As IDataReader = mCmd.ExecuteReader()

                    mDs = New System.Data.DataSet
                    mTb = New System.Data.DataTable("TABLETEST")

                    mTb.Load(mDr)

                    mDs.Tables.Add(mTb)

                    DataGridView1.DataMember = "TABLETEST"
                    DataGridView1.DataSource = mDs
                    DataGridView1.Refresh()

                End Using

            End Using

            mConn.Close()

        End Using

        MsgBox("Records was loaded", MsgBoxStyle.Information)

    End Sub
End Class
