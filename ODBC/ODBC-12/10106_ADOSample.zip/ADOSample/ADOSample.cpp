#include "stdafx.h"
#import "C:\Program Files\Fichiers communs\System\ado\msado15.dll" rename_namespace("MSXML")  rename("EOF", "ADOEOF")
using namespace MSXML;

#include "stdio.h"
#include "io.h"
void dump_error(_com_error &e) ; //exception handling

void main()
{
	HRESULT hr;
	CoInitialize(NULL);

	try
	{
		_ConnectionPtr pConn;
		_RecordsetPtr pRs;
		
		hr = pConn.CreateInstance(__uuidof(Connection));
		hr = pRs.CreateInstance(__uuidof(Recordset));		
	
		pConn->ConnectionString = "DSN=ODBC_SCHED_FIREsourceforge;UID=sysdba;PWD=masterkey"; 
		pConn->CommandTimeout = 33;
		pConn->CursorLocation = adUseServer;
		
		pConn->Open("","","",adConnectUnspecified);
		printf("opening ODBC_SCHED_FIRE as UID=sysdba PWD=masterkey\n");

		hr = pRs->Open("SELECT * from artpack", pConn.GetInterfacePtr(), adOpenForwardOnly, adLockReadOnly, adCmdText);
		
		printf("extracting ARTPACK content in C:\\ARTPACK.xml\n");

		DeleteFile("ARTPACK.xml"); //if the file exists, delete it
		try
		{
			pRs->Save("C:\\ARTPACK.xml",adPersistXML);
		}
		catch(_com_error& e)
		{
			dump_error (e);
		}

		hr = pRs->Close();
		
	}
	catch(_com_error &e)
	{
		dump_error(e);
	}	
}

void dump_error(_com_error &e)
{
	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	
	// Print Com errors.  
	printf("Error\n");
	printf("\tCode = %08lx\n", e.Error());
	printf("\tCode meaning = %s", e.ErrorMessage());
	printf("\tSource = %s\n", (LPCSTR) bstrSource);
	printf("\tDescription = %s\n", (LPCSTR) bstrDescription);
	
}
