#include <string.h>
#include <windows.h>
#include <sql.h>
#include <conio.h>
#include <sqlext.h>
#include <stdio.h>
#include <iostream>

using namespace std; 

#define ROWS 5	

int main(int argc, char* argv[])
{
	SQLHENV henv;
	SQLHDBC hdbc;
	SQLHSTMT hstmt = 0;
	SQLRETURN ret;
	SQLINTEGER MAX_ROWS = 1;

	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER*)SQL_OV_ODBC3, 0); 
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc); 
	ret = SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (SQLPOINTER)5, 0);
	ret = SQLConnect(hdbc, (SQLCHAR*) "employee", SQL_NTS, (SQLCHAR*) NULL, 0, NULL, 0);

 	HSTMT statement;
    ret = SQLAllocHandle (SQL_HANDLE_STMT, hdbc, &statement);
    ret = SQLSetStmtAttr (statement, SQL_ATTR_CURSOR_SCROLLABLE, (void*) SQL_SCROLLABLE, 0);
    ret = SQLSetStmtAttr (statement, SQL_ATTR_CURSOR_TYPE, (void*) SQL_CURSOR_FORWARD_ONLY, 0);
    ret = SQLPrepare (statement, (UCHAR*) 
                "SELECT first_name FROM EMPLOYEE "
                "WHERE (1=1) or FIRST_NAME=?", SQL_NTS);

    ret = SQLSetStmtAttr (statement, SQL_ATTR_ROW_BIND_TYPE, (void*) SQL_BIND_BY_COLUMN, 0);
    ret = SQLSetStmtAttr (statement, SQL_ATTR_ROW_ARRAY_SIZE, (void*) ROWS, 0);

	int stname;
    ret = SQLSetStmtAttr (statement, SQL_ATTR_ROW_STATUS_PTR, &stname , 0);

	int rfname;
    ret = SQLSetStmtAttr (statement, SQL_ATTR_ROWS_FETCHED_PTR, &rfname , 0);

    SWORD   type;
    SQLULEN  precision;
    SWORD   scale;
    SWORD   nullable;

    ret = SQLDescribeParam (statement, 1, &type, &precision, &scale, &nullable);

    char  robert[] = "Robert";
    ret = SQLBindParameter (statement, 1, SQL_PARAM_INPUT, 
                            SQL_C_CHAR, type, precision, scale, robert, 0, NULL);
 
    ret = SQLExecute (statement);
 
    UCHAR firstName [ROWS][31];
    SQLLEN firstNameLength[ROWS];

    ret = SQLBindCol (statement, 1, SQL_C_CHAR, firstName[0], sizeof(firstName[0]), firstNameLength);

	SQLROWSETSIZE row_count = ROWS;
	SQLUSMALLINT row_status[ ROWS ];

	do
	{
	   ret = SQLExtendedFetch( statement, SQL_FETCH_NEXT, 0,
			 &row_count, row_status );

	   if ( SQL_SUCCEEDED( ret ))
	   {
		  int row;

		  /* display each row */
		  for ( row = 0; row < row_count; row ++ )
		  {
			 printf( "Row %d >", row );
			 if ( row_status[ row ] == SQL_ERROR )
			 {
				printf( "ROW ERROR\n" );
			 }
			 else if ( row_status[ row ] == SQL_SUCCESS ||
				row_status[ row ] == SQL_SUCCESS_WITH_INFO )
			 {
				/* display data */
				if ( firstNameLength[ row ] == SQL_NULL_DATA )
				{
				   printf( "NULL<>" );
				}
				else
				{
				   printf( "%s<%d>", firstName[ row ], firstNameLength[row] );
				}
				printf( "\n" );
			 }
		  }
	   }
	} while( SQL_SUCCEEDED( ret ) );

    ret = SQLFreeHandle (SQL_HANDLE_STMT, statement);

    return 0;   
}