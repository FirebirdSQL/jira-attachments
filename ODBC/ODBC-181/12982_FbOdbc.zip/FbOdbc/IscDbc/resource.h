// Used by IscDbc.rc
//
