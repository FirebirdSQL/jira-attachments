//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ODbcJdbc.rc
//
#define IDC_STATIC                      -1

#define IDD_CON_PROPERTIES              129
#define IDC_USER                        1001
#define IDC_PASSWORD                    1002
#define IDC_ROLE                        1003

//
// ID for translate strings
//
#define IDS_DLG_TITLE_CONNECT		0
#define IDS_BUTTON_OK			1
#define IDS_BUTTON_CANCEL		2
#define IDS_STATIC_ACCOUNT		3
#define IDS_STATIC_PASSWORD		4
#define IDS_STATIC_ROLE			5
