#include "stdafx.h"

#include "Util.h"
#include "DbBuilder.h"

SQLRETURN setupTestDb()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  ENFORCESUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) _T("create table getputdata ( id integer primary key, ascii_field char(5) character set UTF8, vstring varchar(30) character set UTF8 )"), SQL_NTS);
    ENFORCESUCCESS2(ret, hStmt);
  }
  
  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) _T("create table getputblob ( id integer primary key, longstr blob sub_type 1 character set UTF8 )"), SQL_NTS);
    ENFORCESUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) _T("create table getputblob0 ( id integer primary key, longstr blob sub_type 0 )"), SQL_NTS);
    ENFORCESUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    ENFORCESUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) _T("insert into getputdata values ( 1, 'ab', 'utf8' )"), SQL_NTS);
    ENFORCESUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) _T("insert into getputdata values ( 2, 'abcde', 'utf8 ���' )"), SQL_NTS);
    ENFORCESUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) _T("insert into getputdata values ( 3, 'AbCdE', 'utf8 ��� 1234567890 0123456789' )"), SQL_NTS);
    ENFORCESUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    ENFORCESUCCESS(ret);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) _T("insert into getputblob values ( 1, 'This is some blob with ��� embedded in it.' )"), SQL_NTS);
    ENFORCESUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    ENFORCESUCCESS(ret);
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    ENFORCESUCCESS(ret);
  }

  return ret;
}