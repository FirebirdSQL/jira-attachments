#include "stdafx.h"

#include "util.h"


SQLHANDLE hEnv = SQL_NULL_HANDLE;
SQLHANDLE hConn = SQL_NULL_HANDLE;


SQLRETURN initEnvironment()
{
  SQLRETURN ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv);
  ENFORCESUCCESS(ret);
  ENFORCE(hEnv != SQL_NULL_HANDLE);

  ret = SQLSetEnvAttr(hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER) SQL_OV_ODBC3, SQL_IS_UINTEGER);
  ENFORCESUCCESS(ret);

  return ret;
}

SQLRETURN closeEnvironment()
{
  SQLRETURN ret = SQL_SUCCESS;
  if (hEnv != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_ENV, hEnv);
    VERIFYSUCCESS(ret);
    hEnv = SQL_NULL_HANDLE;
  }
  return ret;
}

SQLRETURN initConnection( const TCHAR* dbfile )
{
  SQLRETURN ret = SQLAllocHandle(SQL_HANDLE_DBC, hEnv, &hConn);
  ENFORCESUCCESS(ret);
  ENFORCE(hConn != SQL_NULL_HANDLE);

  TCHAR connStringOut[1024];
#ifdef _UNICODE
  const TCHAR* cp = _T("UTF8");
#else
  const TCHAR* cp = _T("WIN1252");
#endif
  std::_otstringstream connStringCommon;
  connStringCommon << _T("={localhost:") << dbfile << _T("};UID=SYSDBA;PWD=masterkey;DIALECT=3;QUOTED=N;LOCKTIMEOUT=2000;SAFETHREAD=Y;CHARSET=");
  std::_otstringstream connStringDriver;
  connStringDriver << _T("DRIVER={") << TESTDRIVERNAME << _T("}");
  std::_tstring connStringOpen = connStringDriver.str() + _T(";DATABASE") + connStringCommon.str() + cp;
  std::_tstring connStringCreate = connStringDriver.str() + _T(";CREATE_DB") + connStringCommon.str() + _T("UTF8");

  // First connect with CREATE_DB and always UTF8 to have the db default cp = UTF8
  ret = SQLDriverConnect(hConn, NULL, (SQLTCHAR*) connStringCreate.c_str(), SQL_NTS, connStringOut, _countof(connStringOut), NULL, SQL_DRIVER_NOPROMPT);
  ENFORCESUCCESS(ret);

  ret = SQLDisconnect(hConn);
  ENFORCESUCCESS(ret);

  // Now connect in open-only mode with UTF8 for UNICODE build and WIN1252 for ANSI build
  ret = SQLDriverConnect(hConn, NULL, (SQLTCHAR*) connStringOpen.c_str(), SQL_NTS, connStringOut, _countof(connStringOut), NULL, SQL_DRIVER_NOPROMPT);
  ENFORCESUCCESS(ret);

  ret = SQLSetConnectAttr(hConn, SQL_ATTR_CURSOR_TYPE, (SQLPOINTER) SQL_CURSOR_STATIC/*SQL_CURSOR_FORWARD_ONLY*/, SQL_IS_UINTEGER);
  VERIFYSUCCESS(ret);
  ret = SQLSetConnectAttr(hConn, SQL_ATTR_CONCURRENCY, (SQLPOINTER) SQL_CONCUR_READ_ONLY, SQL_IS_UINTEGER);
  VERIFYSUCCESS(ret);
  ret = SQLSetConnectAttr(hConn, SQL_ATTR_AUTOCOMMIT, (SQLPOINTER) SQL_AUTOCOMMIT_OFF, SQL_IS_UINTEGER);
  VERIFYSUCCESS(ret);

  return ret;
}

SQLRETURN closeConnection()
{
  SQLRETURN ret = SQL_SUCCESS;
  if (hConn != SQL_NULL_HANDLE)
  {
    ret = SQLDisconnect(hConn);
    VERIFYSUCCESS(ret);

    ret = SQLFreeHandle(SQL_HANDLE_DBC, hConn);
    VERIFYSUCCESS(ret);
    hConn = SQL_NULL_HANDLE;
  }
  return ret;
}

bool hadFailures = false;

void outputFailure( const TCHAR* errormsg, int line, const TCHAR* file, const TCHAR* fn, bool stop )
{
  hadFailures = true;
  std::_otstringstream s;
  s << file << _T("(") << line << _T("): ") << fn << _T(": ")  << errormsg << _T("\n");
  _ftprintf(stderr, _T("%s"), s.str().c_str());
  OutputDebugString(s.str().c_str());
  if (stop)
    exit(1);
}

ParamMap cmdParams;

bool parseCmdLine( int argc, TCHAR* argv[] )
{
  std::_tstring lastSwitch;
  for (int i = 0; i < argc; ++i)
  {
    switch (argv[i][0])
    {
    case _T('-'):
#ifdef _WINDOWS_
    case _T('/'):
#endif
      lastSwitch = argv[i]+1;
      cmdParams[lastSwitch];
      break;
    default:
      cmdParams[lastSwitch].push_back(argv[i]);
      break;
    }
  }
  return true;
}

std::_tstring sqlErrorMsg(SQLHANDLE hEnv, SQLHANDLE hConn, SQLHANDLE hStmt, SQLHANDLE hDesc)
{
  TCHAR sqlstate[64] = _T("");
  TCHAR msg[1024] = _T("");
  SQLINTEGER nativeError = 0;
  SQLSMALLINT msglen;
  SQLRETURN ret;
  SQLHANDLE hdl = hEnv;
  SQLSMALLINT hdltype = SQL_HANDLE_ENV;
  if (hDesc != SQL_NULL_HANDLE)
  {
    hdl = hDesc;
    hdltype = SQL_HANDLE_DESC;
  }
  else if (hStmt != SQL_NULL_HANDLE)
  {
    hdl = hStmt;
    hdltype = SQL_HANDLE_STMT;
  }
  else if (hConn != SQL_NULL_HANDLE)
  {
    hdl = hConn;
    hdltype = SQL_HANDLE_DBC;
  }
  else if (hEnv != SQL_NULL_HANDLE)
  {
    hdl = hEnv;
    hdltype = SQL_HANDLE_ENV;
  }
  if (hdl != SQL_NULL_HANDLE)
    ret = SQLGetDiagRec(hdltype, hdl, 1, sqlstate, &nativeError, msg, _countof(msg), &msglen);
  std::_otstringstream s;
  s << "sqlstate=" << sqlstate << ", native=" << nativeError << ", " << msg;
  return s.str();
}

std::_tstring failedMsg( const TCHAR* cond )
{
  return std::_tstring(_T("condition failed: ")) += cond;
}
