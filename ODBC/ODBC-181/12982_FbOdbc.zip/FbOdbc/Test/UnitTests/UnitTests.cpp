// UnitTests.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "Util.h"
#include "DbBuilder.h"
#include "Tests.h"


typedef SQLRETURN (*TestFunction)();
struct TestDefinition 
{
  LPCTSTR name;
  TestFunction fn;
} tests[] =
{
  { _T("putDataString"), testPutDataString },
  { _T("putBlobString"), testPutBlobString },
  { _T("writeBlobString"), testWriteBlobString },
  { _T("getBlobString"), testGetBlobString },
  { _T("readBlobString"), testReadBlobString },
  { _T("getDataString"), testGetDataString },
  { _T("readDataString"), testReadDataString },
  { _T("putBlobBinary"), testPutBlobBinary },
  { _T("writeBlobBinary"), testWriteBlobBinary },
  { _T("getBlobBinary"), testGetBlobBinary },
  { _T("readBlobBinary"), testReadBlobBinary },
};


int _tmain(int argc, _TCHAR* argv[])
{
  if (!parseCmdLine(argc, argv))
    return 99;

  LPCTSTR helpSwitches[] = { _T("h"), _T("?") };
  if (std::find_first_of(cmdParams.begin(), cmdParams.end(), helpSwitches, helpSwitches + _countof(helpSwitches), [] (const ParamMap::value_type& x, LPCTSTR y) { return x.first == y; }) != cmdParams.end())
  {
    _tprintf(_T("UnitTests for Firebird ODBC driver\n"));
    _tprintf(_T(" -d <filename>\n\tdatabase file name to (re)create\n"));
    _tprintf(_T(" -t <test1> <test2>\n\trun tests named test1 and test2\n\tspecify * to run all tests\n"));
    _tprintf(_T(" -x <dllname>\n\tthe driver dll to test\n"));
    return 99;
  }

  TCHAR wkdir_[MAX_PATH];
  _tgetcwd(wkdir_, _countof(wkdir_));
  std::_tstring wkdir = wkdir_;
  if (wkdir != _T("") && std::_tstring(_T("\\/")).find(wkdir[wkdir.length()-1]) == std::_tstring::npos)
    wkdir += _T("\\");

  if (cmdParams[_T("d")].size() == 0)
  {
    cmdParams[_T("d")].push_back(wkdir + _T("unittests.fdb"));
  }

  if (cmdParams[_T("t")].size() == 0)
  {
    cmdParams[_T("t")].push_back(_T("*"));
  }

  if (cmdParams[_T("x")].size() == 0)
  {
    LPCTSTR drfn = _T("..\\..\\Builds\\MsVc110.win\\Win32\\Debug\\OdbcFb.dll");
    ENFORCEMSG(_taccess((wkdir + drfn).c_str(), 0) == 0, _T("the driver dll could not be found. check -x parameter"));
    cmdParams[_T("x")].push_back(wkdir + drfn);
  }

  SQLRETURN ret;
  ret = initEnvironment();
  if (SQL_SUCCEEDED(ret))
  {
    TCHAR drmsg[1024];
    WORD drmsglen;
    DWORD uc;
    SQLConfigDriver(NULL, ODBC_REMOVE_DRIVER, TESTDRIVERNAME, _T(""), drmsg, _countof(drmsg), &drmsglen);
    if (SQLRemoveDriver(TESTDRIVERNAME, TRUE, &uc))
      ENFORCE(uc == 0);

    TCHAR pathOut[MAX_PATH];
    std::_otstringstream spec;
    WORD cchPathOut;
    std::_tstring drpath = cmdParams[_T("x")][0];
    std::_tstring drdir = drpath.substr(0, drpath.rfind(_T('\\')));
    std::_tstring drname = drpath.substr(drpath.rfind(_T('\\')) + 1);
    spec << TESTDRIVERNAME << TCHAR(0) << _T("Driver=") << drname << TCHAR(0) << TCHAR(0);
    if (!SQLInstallDriverEx(spec.str().c_str(), drdir.c_str(), pathOut, _countof(pathOut), &cchPathOut, ODBC_INSTALL_COMPLETE, &uc))
    {
      ret = SQL_ERROR;
      TCHAR msg[1024];
      WORD msglen;
      DWORD ecode;
      for (WORD i = 1; i <= 8; ++i)
      {
        SQLRETURN lret = SQLInstallerError(i, &ecode, msg, _countof(msg), &msglen);
        if (SQL_SUCCEEDED(lret))
          VERIFYMSG(false, msg);
        if (lret == SQL_NO_DATA)
          break;
      }
      return 1;
    }
    ENFORCE(uc == 1);

    if (!SQLConfigDriver(NULL, ODBC_INSTALL_DRIVER, TESTDRIVERNAME, _T(""), drmsg, _countof(drmsg), &drmsglen))
    {
      ret = SQL_ERROR;
      TCHAR msg[1024];
      WORD msglen;
      DWORD ecode;
      for (WORD i = 1; i <= 8; ++i)
      {
        SQLRETURN lret = SQLInstallerError(i, &ecode, msg, _countof(msg), &msglen);
        if (SQL_SUCCEEDED(lret))
          VERIFYMSG(false, msg);
        if (lret == SQL_NO_DATA)
          break;
      }
      return 1;
    }
  }
  if (SQL_SUCCEEDED(ret))
  {
    bool testAll = std::find(cmdParams[_T("t")].begin(), cmdParams[_T("t")].end(), _T("*")) != cmdParams[_T("t")].end();
    for (auto test : tests)
    {
      if (testAll || std::find(cmdParams[_T("t")].begin(), cmdParams[_T("t")].end(), test.name) != cmdParams[_T("t")].end())
      {
        if (_taccess(cmdParams[_T("d")][0].c_str(), 0) == 0)
          ENFORCEMSG(_tremove(cmdParams[_T("d")][0].c_str()) == 0, _T("failed to delete test database to cleanup before running new test"));

        ret = initConnection(cmdParams[_T("d")][0].c_str());
        if (SQL_SUCCEEDED(ret))
        {
          ret = setupTestDb();
          if (SQL_SUCCEEDED(ret))
          {
            ret = test.fn();
          }
        }
        ret = closeConnection();
      }
    }
  }
  ret = closeEnvironment();

	return hadFailures ? 1 : 0;
}

