#pragma once

extern SQLRETURN testPutDataString();
extern SQLRETURN testPutBlobString();
extern SQLRETURN testWriteBlobString();
extern SQLRETURN testGetBlobString();
extern SQLRETURN testReadBlobString();
extern SQLRETURN testGetDataString();
extern SQLRETURN testReadDataString();
extern SQLRETURN testPutBlobBinary();
extern SQLRETURN testWriteBlobBinary();
extern SQLRETURN testGetBlobBinary();
extern SQLRETURN testReadBlobBinary();
