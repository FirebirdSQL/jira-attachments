// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#ifdef _MSC_VER
#include "targetver.h"
#include <windows.h>
#endif

#include <sql.h>
#include <sqlext.h>
#include <odbcinst.h>

#include <stdio.h>
#include <tchar.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <sstream>



// TODO: reference additional headers your program requires here
