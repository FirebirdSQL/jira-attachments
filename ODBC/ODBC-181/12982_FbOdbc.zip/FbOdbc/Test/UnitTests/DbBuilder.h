#pragma once

extern SQLRETURN setupTestDb();
