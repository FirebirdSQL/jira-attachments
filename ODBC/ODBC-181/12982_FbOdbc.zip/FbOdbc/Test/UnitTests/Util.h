#pragma once

_STD_BEGIN

#ifdef _UNICODE
  typedef wstring _tstring;
#else
  typedef string _tstring;
#endif
typedef basic_stringstream<_tstring::value_type> _tstringstream;
typedef basic_ostringstream<_tstring::value_type> _otstringstream;
typedef basic_istringstream<_tstring::value_type> _itstringstream;

_STD_END

#define TESTDRIVERNAME _T("OdbcFb_UnitTests")

extern SQLHANDLE hEnv;
extern SQLHANDLE hConn;

extern SQLRETURN initEnvironment();
extern SQLRETURN initConnection(const TCHAR* dbfile);
extern SQLRETURN closeEnvironment();
extern SQLRETURN closeConnection();

extern bool hadFailures;

extern std::_tstring sqlErrorMsg(SQLHANDLE hEnv, SQLHANDLE hConn, SQLHANDLE hStmt, SQLHANDLE hDesc);
extern std::_tstring failedMsg(const TCHAR* cond);
extern void outputFailure(const TCHAR* errormsg, int line, const TCHAR* file, const TCHAR* fn, bool stop);

#define ENFORCEMSG(cond, errormsg) if (!(cond)) outputFailure(errormsg, __LINE__, _T(__FILE__), _T(__FUNCTION__), true);
#define ENFORCE(cond) ENFORCEMSG(cond, failedMsg(_T(#cond)).c_str())
#define ENFORCESUCCESS(ret) ENFORCEMSG(SQL_SUCCEEDED(ret), sqlErrorMsg(hEnv, hConn, SQL_NULL_HANDLE, SQL_NULL_HANDLE).c_str())
#define ENFORCESUCCESS2(ret, hStmt) ENFORCEMSG(SQL_SUCCEEDED(ret), sqlErrorMsg(hEnv, hConn, hStmt, SQL_NULL_HANDLE).c_str())
#define ENFORCESUCCESS3(ret, hDesc) ENFORCEMSG(SQL_SUCCEEDED(ret), sqlErrorMsg(hEnv, hConn, SQL_NULL_HANDLE, hDesc).c_str())

#define VERIFYMSG(cond, errormsg) if (!(cond)) outputFailure(errormsg, __LINE__, _T(__FILE__), _T(__FUNCTION__), false);
#define VERIFY(cond) VERIFYMSG(cond, failedMsg(_T(#cond)).c_str())
#define VERIFYSUCCESS(ret) VERIFYMSG(SQL_SUCCEEDED(ret), sqlErrorMsg(hEnv, hConn, SQL_NULL_HANDLE, SQL_NULL_HANDLE).c_str())
#define VERIFYSUCCESS2(ret, hStmt) VERIFYMSG(SQL_SUCCEEDED(ret), sqlErrorMsg(hEnv, hConn, hStmt, SQL_NULL_HANDLE).c_str())
#define VERIFYSUCCESS3(ret, hDesc) VERIFYMSG(SQL_SUCCEEDED(ret), sqlErrorMsg(hEnv, hConn, SQL_NULL_HANDLE, hDesc).c_str())

typedef std::map<std::_tstring, std::vector<std::_tstring>> ParamMap;
extern ParamMap cmdParams;

extern bool parseCmdLine(int argc, TCHAR* argv[]);
