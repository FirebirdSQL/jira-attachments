#include "stdafx.h"
#include "Util.h"
#include "Tests.h"

SQLRETURN testPutDataString()
{
  TCHAR s1[] = _T("12345");
  TCHAR s2[] = _T("utf8 ��� 1234567890 0123456789");

  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("insert into getputdata values ( ?, ?, ? )"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR name[64];
    SQLSMALLINT nameLen;
    SQLSMALLINT sqlType;
    SQLSMALLINT subType;
    SQLLEN octets;
    SQLUINTEGER len;
    SQLSMALLINT prec;
    SQLSMALLINT scale;
    SQLSMALLINT nullable;
    SQLHANDLE hDesc = SQL_NULL_HANDLE;

/*
    ret = SQLGetStmtAttr(hStmt, SQL_ATTR_APP_PARAM_DESC/ *SQL_ATTR_IMP_PARAM_DESC* /, &hDesc, sizeof(hDesc), NULL);
    VERIFYSUCCESS2(ret, hStmt);

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLGetDescRec(hDesc, 1, (SQLTCHAR*) name, _countof(name), &nameLen, &sqlType, &subType, &octets, &prec, &scale, &nullable);
      VERIFYSUCCESS3(ret, hDesc);
      VERIFY(nameLen == _tcslen(name));
      VERIFY(sqlType == SQL_INTEGER);
      VERIFY(octets == sizeof(SQLINTEGER));
      VERIFY(prec == 10);
      VERIFY(scale == 0);
      VERIFY(nullable == SQL_NO_NULLS);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLGetDescRec(hDesc, 2, (SQLTCHAR*) name, _countof(name), &nameLen, &sqlType, &subType, &octets, &prec, &scale, &nullable);
      VERIFYSUCCESS3(ret, hDesc);
      VERIFY(nameLen == _tcslen(name));
      VERIFY(sqlType == SQL_CHAR);
      VERIFY(octets == 5);
      VERIFY(prec == 5);
      VERIFY(nullable == SQL_NULLABLE);
    }
*/

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLDescribeParam(hStmt, 1, &sqlType, &len, &scale, &nullable);
      VERIFYSUCCESS2(ret, hStmt);
      VERIFY(sqlType == SQL_INTEGER);
      VERIFY(len == 10);
      VERIFY(nullable == SQL_NO_NULLS);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLDescribeParam(hStmt, 2, &sqlType, &len, &scale, &nullable);
      VERIFYSUCCESS2(ret, hStmt);
      VERIFY(sqlType == SQL_WCHAR);
      VERIFY(len == 5);
      VERIFY(nullable == SQL_NULLABLE);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLDescribeParam(hStmt, 3, &sqlType, &len, &scale, &nullable);
      VERIFYSUCCESS2(ret, hStmt);
      VERIFY(sqlType == SQL_WVARCHAR);
      VERIFY(len == 30);
      VERIFY(nullable == SQL_NULLABLE);
    }

    SQLINTEGER id_field;
    TCHAR ascii_field[128];
    TCHAR utf8_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER ascii_field_len;
    SQLINTEGER utf8_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_CHAR, 5, 0, ascii_field, sizeof(ascii_field), &ascii_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 3, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_VARCHAR, 30, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLGetStmtAttr(hStmt, SQL_ATTR_APP_PARAM_DESC/*SQL_ATTR_IMP_PARAM_DESC*/, &hDesc, sizeof(hDesc), NULL);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLGetDescRec(hDesc, 1, (SQLTCHAR*) name, _countof(name), &nameLen, &sqlType, &subType, &octets, &prec, &scale, &nullable);
      VERIFYSUCCESS3(ret, hDesc);
      VERIFY(nameLen == _tcslen(name));
      VERIFY(sqlType == SQL_INTEGER);
      VERIFY(octets == sizeof(SQLINTEGER));
      VERIFY(prec == 10);
      VERIFY(scale == 0);
      VERIFY(nullable == SQL_NO_NULLS);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLGetDescRec(hDesc, 2, (SQLTCHAR*) name, _countof(name), &nameLen, &sqlType, &subType, &octets, &prec, &scale, &nullable);
      VERIFYSUCCESS3(ret, hDesc);
      VERIFY(nameLen == _tcslen(name));
      VERIFY(sqlType == SQL_C_TCHAR);
      VERIFY(octets == sizeof(ascii_field));
      VERIFY(prec == 5);
      VERIFY(nullable == SQL_NULLABLE);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLGetDescRec(hDesc, 3, (SQLTCHAR*) name, _countof(name), &nameLen, &sqlType, &subType, &octets, &prec, &scale, &nullable);
      VERIFYSUCCESS3(ret, hDesc);
      VERIFY(nameLen == _tcslen(name));
      VERIFY(sqlType == SQL_C_TCHAR);
      VERIFY(octets == sizeof(utf8_field));
      VERIFY(prec == 30);
      VERIFY(nullable == SQL_NULLABLE);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 100;

      ascii_field_len = SQL_NTS;
      _tcscpy_s(ascii_field, _T("z$x;Y"));

      utf8_field_len = SQL_NTS;
      memset(utf8_field, 0, sizeof(utf8_field));
      for (int i = 0; i < 30; ++i)
        _tcscat_s(utf8_field, _T("\xD834\xDD1E"));

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLExecute(hStmt);
        VERIFYSUCCESS2(ret, hStmt);
      }

      id_field++;
      ascii_field_len = 1 * sizeof(SQLTCHAR);
      _tcscpy_s(ascii_field, _T("Q"));
      utf8_field_len = SQL_NTS;
      memset(utf8_field, 0, sizeof(utf8_field));
      for (int i = 0; i < 29; ++i)
        _tcscat_s(utf8_field, _T("\xD834\xDD1E"));
      _tcscat_s(utf8_field, _T("01"));

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLExecute(hStmt);
        VERIFYSUCCESS2(ret, hStmt);
        VERIFY(ret == SQL_SUCCESS_WITH_INFO);
      }

      id_field++;
      ascii_field_len = SQL_LEN_DATA_AT_EXEC(5*(int)sizeof(SQLTCHAR));
      _tcscpy_s(ascii_field, _T("12w45"));
      utf8_field_len = SQL_DATA_AT_EXEC;
      memset(utf8_field, 0, sizeof(utf8_field));
      for (int i = 0; i < 30; ++i)
        _tcscat_s(utf8_field, _T("\xD834\xDD1E"));

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLExecute(hStmt);
        if (ret == SQL_NEED_DATA)
        {
          SQLPOINTER fldid;
          ret = SQLParamData(hStmt, &fldid);
          VERIFY(ret == SQL_NEED_DATA);
          if (ret != SQL_NEED_DATA)
            VERIFYSUCCESS2(ret, hStmt);
          VERIFY(fldid == ascii_field);

          ret = SQLPutData(hStmt, ascii_field, 3*sizeof(SQLTCHAR));
          VERIFYSUCCESS2(ret, hStmt);

          ret = SQLPutData(hStmt, ascii_field + 3, 2*sizeof(SQLTCHAR));
          VERIFYSUCCESS2(ret, hStmt);

          ret = SQLParamData(hStmt, &fldid);
          VERIFY(ret == SQL_NEED_DATA);
          if (ret != SQL_NEED_DATA)
            VERIFYSUCCESS2(ret, hStmt);
          VERIFY(fldid == utf8_field);

          ret = SQLPutData(hStmt, utf8_field, SQL_NTS);
          VERIFYSUCCESS2(ret, hStmt);

          ret = SQLParamData(hStmt, &fldid);
          VERIFYSUCCESS2(ret, hStmt);
        }
        else
        {
          VERIFYSUCCESS2(ret, hStmt);
        }
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

TCHAR data_s1[] = _T("12345");
TCHAR data_s2[] = _T("utf8 ��� 1234567890 0123456789");
TCHAR data_s3[] = _T("\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E \xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E \xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E");
TCHAR data_s4[] = _T("\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E\xD834\xDD1E");
TCHAR data_s5[] = _T("12�");

SQLRETURN testPutBlobString()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("insert into getputblob values ( ?, ? )"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    SQLINTEGER id_field;
    TCHAR utf8_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER utf8_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_LONGVARCHAR, 0, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 100;
      utf8_field_len = SQL_DATA_AT_EXEC;
      memset(utf8_field, 0, sizeof(utf8_field));
      for (int i = 0; i < _countof(utf8_field)/2-1; ++i)
        _tcscat_s(utf8_field, _T("\xD834\xDD1E"));

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLExecute(hStmt);
        if (ret == SQL_NEED_DATA)
        {
          SQLPOINTER fldid;
          ret = SQLParamData(hStmt, &fldid);
          VERIFY(ret == SQL_NEED_DATA);
          if (ret != SQL_NEED_DATA)
            VERIFYSUCCESS2(ret, hStmt);
          VERIFY(fldid == utf8_field);

          ret = SQLPutData(hStmt, utf8_field, SQL_NTS);
          VERIFYSUCCESS2(ret, hStmt);

          ret = SQLPutData(hStmt, utf8_field, 4*sizeof(SQLTCHAR));
          VERIFYSUCCESS2(ret, hStmt);

          ret = SQLParamData(hStmt, &fldid);
          VERIFYSUCCESS2(ret, hStmt);
        }
        else
        {
          VERIFYSUCCESS2(ret, hStmt);
        }
      }

      id_field++;
      ret = SQLExecute(hStmt);
      if (ret == SQL_NEED_DATA)
      {
        SQLPOINTER fldid;
        ret = SQLParamData(hStmt, &fldid);
        VERIFY(ret == SQL_NEED_DATA);
        if (ret != SQL_NEED_DATA)
          VERIFYSUCCESS2(ret, hStmt);
        VERIFY(fldid == utf8_field);

        ret = SQLPutData(hStmt, data_s1, SQL_NTS);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLPutData(hStmt, data_s2, SQL_NTS);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLPutData(hStmt, data_s3, SQL_NTS);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLParamData(hStmt, &fldid);
        VERIFYSUCCESS2(ret, hStmt);
      }
      else
      {
        VERIFYSUCCESS2(ret, hStmt);
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

SQLRETURN testWriteBlobString()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("insert into getputblob values ( ?, ? )"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    SQLINTEGER id_field;
    TCHAR utf8_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER utf8_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_LONGVARCHAR, 0, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 100;
      utf8_field_len = SQL_NTS;

      _tcscpy_s(utf8_field, data_s1);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      id_field++;
      _tcscpy_s(utf8_field, data_s2);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      id_field++;
      _tcscpy_s(utf8_field, data_s3);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

SQLRETURN testGetBlobString()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_s1)];
    _stprintf_s(sql, _T("insert into getputblob values ( %d, '%s' )"), 100, data_s1);
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_s2)];
    _stprintf_s(sql, _T("insert into getputblob values ( %d, '%s' )"), 101, data_s2);
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_s3)];
    _stprintf_s(sql, _T("insert into getputblob values ( %d, '%s' )"), 102, data_s3);
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("select id, longstr from getputblob where id between 100 and 102 order by id"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    SQLINTEGER id_field;
    TCHAR utf8_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER utf8_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindCol(hStmt, 1, SQL_C_LONG, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcscmp(utf8_field, data_s1) == 0);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFY(ret == SQL_NO_DATA_FOUND);


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcscmp(utf8_field, data_s2) == 0);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFY(ret == SQL_NO_DATA_FOUND);


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field[0]) * 2, &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field + _tcslen(utf8_field), sizeof(utf8_field) - _tcslen(utf8_field) * sizeof(utf8_field[0]), &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field + _tcslen(utf8_field), sizeof(utf8_field) - _tcslen(utf8_field) * sizeof(utf8_field[0]), &utf8_field_len);
        VERIFY(ret == SQL_NO_DATA_FOUND);

        VERIFY(_tcscmp(utf8_field, data_s3) == 0);
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

SQLRETURN testReadBlobString()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_s1)];
    _stprintf_s(sql, _T("insert into getputblob values ( %d, '%s' )"), 100, data_s1);
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_s2)];
    _stprintf_s(sql, _T("insert into getputblob values ( %d, '%s' )"), 101, data_s2);
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_s3)];
    _stprintf_s(sql, _T("insert into getputblob values ( %d, '%s' )"), 102, data_s3);
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("select id, longstr from getputblob where id between 100 and 102 order by id"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    SQLINTEGER id_field;
    TCHAR utf8_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER utf8_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindCol(hStmt, 1, SQL_C_LONG, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);

      ret = SQLBindCol(hStmt, 2, SQL_C_TCHAR, &utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcscmp(utf8_field, data_s1) == 0);


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcscmp(utf8_field, data_s2) == 0);


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcscmp(utf8_field, data_s3) == 0);
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

SQLRETURN testReadDataString()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  SQLINTEGER id_field;
  TCHAR utf8_field[128];
  TCHAR ascii_field[128];
  SQLINTEGER id_field_len;
  SQLINTEGER utf8_field_len;
  SQLINTEGER ascii_field_len;

  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("insert into getputdata values ( ?, ?, ? )"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_VARCHAR, 0, 0, ascii_field, sizeof(ascii_field), &ascii_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 3, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_VARCHAR, 0, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 100;
      utf8_field_len = SQL_NTS;
      ascii_field_len = SQL_NTS;

      _tcscpy_s(ascii_field, data_s1);
      _tcscpy_s(utf8_field, data_s2);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      id_field++;
      ascii_field_len = SQL_NULL_DATA;
      _tcscpy_s(utf8_field, data_s4);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      id_field++;
      ascii_field_len = SQL_NTS;
      utf8_field_len = SQL_NULL_DATA;
      _tcscpy_s(ascii_field, data_s5);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);
    }

    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("select id, ascii_field, vstring from getputdata where id between 100 and 102 order by id"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindCol(hStmt, 1, SQL_C_LONG, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);

      ret = SQLBindCol(hStmt, 2, SQL_C_TCHAR, &ascii_field, sizeof(ascii_field), &ascii_field_len);
      VERIFYSUCCESS2(ret, hStmt);

      ret = SQLBindCol(hStmt, 3, SQL_C_TCHAR, &utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcscmp(ascii_field, data_s1) == 0);
        VERIFY(ascii_field_len == sizeof(TCHAR) * _tcslen(data_s1));
        VERIFY(_tcscmp(utf8_field, data_s2) == 0);
        VERIFY(utf8_field_len == sizeof(TCHAR) * _tcslen(data_s2));


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(ascii_field[0] == 0);
        VERIFY(ascii_field_len == SQL_NULL_DATA);
        VERIFY(_tcscmp(utf8_field, data_s4) == 0);
        VERIFY(utf8_field_len == sizeof(TCHAR) * _tcslen(data_s4));


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcsncmp(ascii_field, data_s5, _tcslen(data_s5)) == 0);
        VERIFY(ascii_field_len == sizeof(TCHAR) * 5);
        VERIFY(utf8_field[0] == 0);
        VERIFY(utf8_field_len == SQL_NULL_DATA);


        ret = SQLFetch(hStmt);
        VERIFY(ret = SQL_NO_DATA_FOUND);
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

SQLRETURN testGetDataString()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  SQLINTEGER id_field;
  TCHAR utf8_field[128];
  TCHAR ascii_field[128];
  SQLINTEGER id_field_len;
  SQLINTEGER utf8_field_len;
  SQLINTEGER ascii_field_len;

  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("insert into getputdata values ( ?, ?, ? )"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_VARCHAR, 0, 0, ascii_field, sizeof(ascii_field), &ascii_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 3, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_VARCHAR, 0, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 100;
      utf8_field_len = SQL_NTS;
      ascii_field_len = SQL_NTS;

      _tcscpy_s(ascii_field, data_s1);
      _tcscpy_s(utf8_field, data_s2);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      id_field++;
      ascii_field_len = SQL_NULL_DATA;
      _tcscpy_s(utf8_field, data_s4);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      id_field++;
      ascii_field_len = SQL_NTS;
      utf8_field_len = SQL_NULL_DATA;
      _tcscpy_s(ascii_field, data_s5);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);
    }

    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("select id, ascii_field, vstring from getputdata where id between 100 and 102 order by id"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLGetData(hStmt, 1, SQL_C_LONG, &id_field, sizeof(id_field), &id_field_len);
        VERIFYSUCCESS2(ret, hStmt);
        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, &ascii_field, sizeof(ascii_field), &ascii_field_len);
        VERIFYSUCCESS2(ret, hStmt);
        ret = SQLGetData(hStmt, 3, SQL_C_TCHAR, &utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcscmp(ascii_field, data_s1) == 0);
        VERIFY(ascii_field_len == sizeof(TCHAR) * _tcslen(data_s1));
        VERIFY(_tcscmp(utf8_field, data_s2) == 0);
        VERIFY(utf8_field_len == sizeof(TCHAR) * _tcslen(data_s2));


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLGetData(hStmt, 1, SQL_C_LONG, &id_field, sizeof(id_field), &id_field_len);
        VERIFYSUCCESS2(ret, hStmt);
        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, &ascii_field, sizeof(ascii_field), &ascii_field_len);
        VERIFYSUCCESS2(ret, hStmt);
        ret = SQLGetData(hStmt, 3, SQL_C_TCHAR, &utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(ascii_field[0] == 0);
        VERIFY(ascii_field_len == SQL_NULL_DATA);
        VERIFY(_tcscmp(utf8_field, data_s4) == 0);
        VERIFY(utf8_field_len == sizeof(TCHAR) * _tcslen(data_s4));


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLGetData(hStmt, 1, SQL_C_LONG, &id_field, sizeof(id_field), &id_field_len);
        VERIFYSUCCESS2(ret, hStmt);
        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, &ascii_field, sizeof(ascii_field), &ascii_field_len);
        VERIFYSUCCESS2(ret, hStmt);
        ret = SQLGetData(hStmt, 3, SQL_C_TCHAR, &utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(_tcsncmp(ascii_field, data_s5, _tcslen(data_s5)) == 0);
        VERIFY(ascii_field_len == sizeof(TCHAR) * 5);
        VERIFY(utf8_field[0] == 0);
        VERIFY(utf8_field_len == SQL_NULL_DATA);


        ret = SQLFetch(hStmt);
        VERIFY(ret = SQL_NO_DATA_FOUND);
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}


BYTE data_bin1[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
TCHAR data_sbin1[] = _T("00010203040506070809");
BYTE data_bin2[] = { 0xAF, 0xFE, 0, 0xAF, 0xFE, 0 };
TCHAR data_sbin2[] = _T("AFFE00AFFE00");

SQLRETURN testPutBlobBinary()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("insert into getputblob0 values ( ?, ? )"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    SQLINTEGER id_field;
    TCHAR utf8_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER utf8_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_LONGVARBINARY, 0, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 100;
      utf8_field_len = SQL_DATA_AT_EXEC;

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLExecute(hStmt);
        if (ret == SQL_NEED_DATA)
        {
          SQLPOINTER fldid;
          ret = SQLParamData(hStmt, &fldid);
          VERIFY(ret == SQL_NEED_DATA);
          if (ret != SQL_NEED_DATA)
            VERIFYSUCCESS2(ret, hStmt);
          VERIFY(fldid == utf8_field);

          ret = SQLPutData(hStmt, data_sbin1, 2 * sizeof(data_sbin1[0]));
          VERIFYSUCCESS2(ret, hStmt);
          ret = SQLPutData(hStmt, data_sbin1 + 2, (_tcslen(data_sbin1) - 2)  * sizeof(data_sbin1[0]));
          VERIFYSUCCESS2(ret, hStmt);

          ret = SQLParamData(hStmt, &fldid);
          VERIFYSUCCESS2(ret, hStmt);
        }
        else
        {
          VERIFYSUCCESS2(ret, hStmt);
        }
      }

      id_field++;
      ret = SQLExecute(hStmt);
      if (ret == SQL_NEED_DATA)
      {
        SQLPOINTER fldid;
        ret = SQLParamData(hStmt, &fldid);
        VERIFY(ret == SQL_NEED_DATA);
        if (ret != SQL_NEED_DATA)
          VERIFYSUCCESS2(ret, hStmt);
        VERIFY(fldid == utf8_field);

        ret = SQLPutData(hStmt, data_sbin2, SQL_NTS);
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLParamData(hStmt, &fldid);
        VERIFYSUCCESS2(ret, hStmt);
      }
      else
      {
        VERIFYSUCCESS2(ret, hStmt);
      }
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_BINARY, SQL_LONGVARBINARY, 0, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 200;
      utf8_field_len = SQL_DATA_AT_EXEC;

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLExecute(hStmt);
        if (ret == SQL_NEED_DATA)
        {
          SQLPOINTER fldid;
          ret = SQLParamData(hStmt, &fldid);
          VERIFY(ret == SQL_NEED_DATA);
          if (ret != SQL_NEED_DATA)
            VERIFYSUCCESS2(ret, hStmt);
          VERIFY(fldid == utf8_field);

          ret = SQLPutData(hStmt, data_bin1, 2 * sizeof(data_bin1[0]));
          VERIFYSUCCESS2(ret, hStmt);
          ret = SQLPutData(hStmt, data_bin1 + 2, (sizeof(data_bin1) - 2)  * sizeof(data_bin1[0]));
          VERIFYSUCCESS2(ret, hStmt);

          ret = SQLParamData(hStmt, &fldid);
          VERIFYSUCCESS2(ret, hStmt);
        }
        else
        {
          VERIFYSUCCESS2(ret, hStmt);
        }
      }

      id_field++;
      ret = SQLExecute(hStmt);
      if (ret == SQL_NEED_DATA)
      {
        SQLPOINTER fldid;
        ret = SQLParamData(hStmt, &fldid);
        VERIFY(ret == SQL_NEED_DATA);
        if (ret != SQL_NEED_DATA)
          VERIFYSUCCESS2(ret, hStmt);
        VERIFY(fldid == utf8_field);

        ret = SQLPutData(hStmt, data_sbin2, sizeof(data_bin2));
        VERIFYSUCCESS2(ret, hStmt);

        ret = SQLParamData(hStmt, &fldid);
        VERIFYSUCCESS2(ret, hStmt);
      }
      else
      {
        VERIFYSUCCESS2(ret, hStmt);
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

SQLRETURN testWriteBlobBinary()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("insert into getputblob0 values ( ?, ? )"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    SQLINTEGER id_field;
    TCHAR utf8_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER utf8_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_TCHAR, SQL_LONGVARBINARY, 0, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 100;
      utf8_field_len = SQL_NTS;

      _tcscpy_s(utf8_field, data_sbin1);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      id_field++;
      _tcscpy_s(utf8_field, data_sbin2);
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindParameter(hStmt, 2, SQL_PARAM_INPUT, SQL_C_BINARY, SQL_LONGVARBINARY, 0, 0, utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      id_field_len = sizeof(SQLINTEGER);
      id_field = 200;

      utf8_field_len = sizeof(data_bin1);
      memcpy(utf8_field, data_bin1, sizeof(data_bin1));
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      id_field++;
      utf8_field_len = sizeof(data_bin2);
      memcpy(utf8_field, data_bin2, sizeof(data_bin2));
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

void testGetBlobBinary_buildInsert(TCHAR* dst, int dstsize, int id, BYTE* src, int cb)
{
  TCHAR tmp[32];
  _stprintf_s(dst, dstsize, _T("insert into getputblob0 values ( %d, _OCTETS ''"), id);
  while (cb--)
  {
    _stprintf_s(tmp, _T("||ascii_char(%d)"), *(src++));
    _tcscat_s(dst, dstsize, tmp);
  }
  _tcscat_s(dst, dstsize, _T(" )"));
}

SQLRETURN testGetBlobBinary()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_bin1)*32];
    testGetBlobBinary_buildInsert(sql, _countof(sql), 100, data_bin1, _countof(data_bin1));
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_bin2)*32];
    testGetBlobBinary_buildInsert(sql, _countof(sql), 101, data_bin2, _countof(data_bin2));
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("select id, longstr from getputblob0 where id between 100 and 101")
      _T(" union ")
      _T("select id + 1000, longstr from getputblob0 where id between 100 and 101 order by 1"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    SQLINTEGER id_field;
    TCHAR utf8_field[128];
    BYTE byte_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER utf8_field_len;
    SQLINTEGER byte_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindCol(hStmt, 1, SQL_C_LONG, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(id_field == 100);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(utf8_field_len == _tcslen(data_sbin1) * sizeof(utf8_field[0]));
        VERIFY(_tcscmp(utf8_field, data_sbin1) == 0);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFY(ret == SQL_NO_DATA_FOUND);


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(id_field == 101);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field[0]) * 3, &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(utf8_field_len == _tcslen(data_sbin2) * sizeof(utf8_field[0]));

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field + 2, sizeof(utf8_field) - sizeof(utf8_field[0]) * 2, &utf8_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(utf8_field_len == (_tcslen(data_sbin2) - 2) * sizeof(utf8_field[0]));
        VERIFY(_tcscmp(utf8_field, data_sbin2) == 0);

        ret = SQLGetData(hStmt, 2, SQL_C_TCHAR, utf8_field, sizeof(utf8_field), &utf8_field_len);
        VERIFY(ret == SQL_NO_DATA_FOUND);


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(id_field == 1100);

        ret = SQLGetData(hStmt, 2, SQL_C_BINARY, byte_field, sizeof(byte_field), &byte_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(byte_field_len == sizeof(data_bin1));
        VERIFY(memcmp(byte_field, data_bin1, sizeof(data_bin1)) == 0);

        ret = SQLGetData(hStmt, 2, SQL_C_BINARY, byte_field, sizeof(byte_field), &byte_field_len);
        VERIFY(ret == SQL_NO_DATA_FOUND);


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(id_field == 1101);

        ret = SQLGetData(hStmt, 2, SQL_C_BINARY, byte_field, sizeof(byte_field[0]) * 2, &byte_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(byte_field_len == sizeof(data_bin2));

        ret = SQLGetData(hStmt, 2, SQL_C_BINARY, byte_field + 2, sizeof(byte_field) - sizeof(byte_field[0]) * 2, &byte_field_len);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(byte_field_len == (_countof(data_bin2) - 2) * sizeof(byte_field[0]));
        VERIFY(memcmp(byte_field, data_bin2, sizeof(data_bin2)) == 0);

        ret = SQLGetData(hStmt, 2, SQL_C_BINARY, byte_field, sizeof(byte_field), &byte_field_len);
        VERIFY(ret == SQL_NO_DATA_FOUND);
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

SQLRETURN testReadBlobBinary()
{
  SQLRETURN ret;
  SQLHANDLE hStmt = SQL_NULL_HANDLE;
  ret = SQLAllocHandle(SQL_HANDLE_STMT, hConn, &hStmt);
  VERIFYSUCCESS(ret);

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_bin1)*32];
    testGetBlobBinary_buildInsert(sql, _countof(sql), 100, data_bin1, _countof(data_bin1));
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    TCHAR sql[256+_countof(data_bin2)*32];
    testGetBlobBinary_buildInsert(sql, _countof(sql), 101, data_bin2, _countof(data_bin2));
    ret = SQLExecDirect(hStmt, (SQLTCHAR*) sql, SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    ret = SQLPrepare(hStmt, (SQLTCHAR*) _T("select id, longstr, longstr from getputblob0 where id between 100 and 101"), SQL_NTS);
    VERIFYSUCCESS2(ret, hStmt);
  }

  if (SQL_SUCCEEDED(ret))
  {
    SQLINTEGER id_field;
    TCHAR utf8_field[128];
    BYTE byte_field[128];
    SQLINTEGER id_field_len;
    SQLINTEGER utf8_field_len;
    SQLINTEGER byte_field_len;

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLBindCol(hStmt, 1, SQL_C_LONG, &id_field, sizeof(id_field), &id_field_len);
      VERIFYSUCCESS2(ret, hStmt);

      ret = SQLBindCol(hStmt, 2, SQL_C_TCHAR, &utf8_field, sizeof(utf8_field), &utf8_field_len);
      VERIFYSUCCESS2(ret, hStmt);

      ret = SQLBindCol(hStmt, 3, SQL_C_BINARY, &byte_field, sizeof(byte_field), &byte_field_len);
      VERIFYSUCCESS2(ret, hStmt);
    }

    if (SQL_SUCCEEDED(ret))
    {
      ret = SQLExecute(hStmt);
      VERIFYSUCCESS2(ret, hStmt);

      if (SQL_SUCCEEDED(ret))
      {
        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(utf8_field_len == _tcslen(data_sbin1) * sizeof(utf8_field[0]));
        VERIFY(byte_field_len == sizeof(data_bin1));
        VERIFY(_tcscmp(utf8_field, data_sbin1) == 0);
        VERIFY(memcmp(byte_field, data_bin1, sizeof(data_bin1)) == 0);


        ret = SQLFetch(hStmt);
        VERIFYSUCCESS2(ret, hStmt);

        VERIFY(utf8_field_len == _tcslen(data_sbin2) * sizeof(utf8_field[0]));
        VERIFY(byte_field_len == sizeof(data_bin2));
        VERIFY(_tcscmp(utf8_field, data_sbin2) == 0);
        VERIFY(memcmp(byte_field, data_bin2, sizeof(data_bin2)) == 0);
      }
    }
  }

  if (hStmt != SQL_NULL_HANDLE)
  {
    ret = SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    VERIFYSUCCESS2(ret, hStmt);
  }

  ret = SQLTransact(hEnv, hConn, SQL_COMMIT);
  VERIFYSUCCESS2(ret, hStmt);

  return ret;
}

