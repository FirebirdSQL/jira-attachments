/* --------------------------------------------------------------------------
  --- Initialize TPC-B
-------------------------------------------------------------------------- */

create procedure tpcb_func_p_init (
  i_num_branches          bigint,
  i_num_tellers           bigint,
  i_num_accounts          bigint,
  i_tps                   bigint
)
as
  declare v_cnt bigint;
begin
--{
  -- branches
  v_cnt = 0;  

  while (v_cnt < i_num_branches * i_tps) do
  begin
  --{
    -- insert
    insert
      into tpcb_branch 
           (
            branch_id,
            branch_balance
           )    
    values (
            :v_cnt,
            0
           );
    
    v_cnt = v_cnt + 1;
  --}
  end

  -- tellers
  v_cnt = 0;  

  while (v_cnt < i_num_tellers * i_tps) do
  begin
  --{
    -- insert
    insert
      into tpcb_teller 
           (
            teller_id,
            branch_id,
            teller_balance
           )    
    values (
            :v_cnt,
            :v_cnt / :i_num_tellers,
            0
           );

    v_cnt = v_cnt + 1;
  --}
  end

  -- accounts
  v_cnt = 0;  

  while (v_cnt < i_num_accounts * i_tps) do
  begin
  --{
    -- insert
    insert
      into tpcb_account 
           (
            account_id,
            branch_id,
            account_balance
           )    
    values (
            :v_cnt,
            :v_cnt / :i_num_accounts,
            0
           );

    v_cnt = v_cnt + 1;
  --}
  end

--}
end
