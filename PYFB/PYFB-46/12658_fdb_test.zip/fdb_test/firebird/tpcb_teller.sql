create table tpcb_teller (
  teller_id               bigint        not null,
  branch_id               bigint        not null,
  teller_balance          bigint        default null,
  filler                  char(76)      default '1234567890123456789012345678901234567890123456789012345678901234567890123456'
);