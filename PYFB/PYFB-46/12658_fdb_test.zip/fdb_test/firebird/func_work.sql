/* --------------------------------------------------------------------------
  --- TPC-B work
-------------------------------------------------------------------------- */

create procedure tpcb_func_p_work(
  i_branch_id         bigint,
  i_teller_id         bigint,
  i_account_id        bigint,
  i_delta             bigint
)
returns (
  o_account_balance   bigint
)
as
begin
--{
  -- Step 1: set new balance
  update tpcb_account
     set account_balance = account_balance + :i_delta
   where account_id = :i_account_id; 

  -- Step 2: get current balance
  select account_balance
    from tpcb_account
   where account_id = :i_account_id
    into :o_account_balance;
    
  -- Step 3: teller
  update tpcb_teller
     set teller_balance = teller_balance + :i_delta
   where teller_id = :i_teller_id; 

  -- Step 4: branch
  update tpcb_branch
     set branch_balance = branch_balance + :i_delta
   where branch_id = :i_branch_id; 

  -- Step 5: write log
  insert
    into tpcb_history 
         (
          teller_id,
          branch_id,
          account_id,
          delta,
          ta_time
         )    
  values (
          :i_teller_id,
          :i_branch_id,
          :i_account_id,
          :i_delta,
          current_timestamp
         );

  suspend;
--}  
end;
