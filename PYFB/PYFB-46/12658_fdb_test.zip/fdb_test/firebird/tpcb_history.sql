/* --------------------------------------------------------------------------
  --- tpcb_history
-------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------
--
-------------------------------------------------------------------------- */

create table tpcb_history (
  teller_id               bigint        not null,
  branch_id               bigint        not null,
  account_id              bigint        not null,
  delta                   bigint        default null,
  ta_time                 timestamp,
  filler                  char(10)      default '1234567890'
);
