create table tpcb_branch (
  branch_id               bigint        not null,
  branch_balance          bigint        not null,
  filler                  char(84)      default '123456789012345678901234567890123456789012345678901234567890123456789012345678901234'
);