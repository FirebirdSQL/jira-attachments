#!/usr/bin/python3

import os
import fdb
import sys
import threading
import timeit
import random
random.seed()

if os.name == "posix":
    import signal
    import faulthandler
    faulthandler.register(signal.SIGUSR1)


# ---------------------------------------------------------------------------
# --- Help Functions for Transactions ---------------------------------------
# ---------------------------------------------------------------------------

class tpcbRandom():
    def __init__(self, scale):
        self.scale = scale

    def next(self):
        teller_id = random.randint(0, 10 * self.scale - 1)
        branch_id = teller_id // 10
        account_id = random.randint(0, 100000 * self.scale - 1)
        delta = random.randint(-999999, 999999)
        return branch_id, teller_id, account_id, delta

# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# --- Database transactions in Threads --------------------------------------
# ---------------------------------------------------------------------------

class tpcbThread(threading.Thread):

    def run(self):

        # Initialisation
        connections = 2
        duration = 60.0
        rand = tpcbRandom(scale)
        
        # Connect several database sessions
        cons = []
        curs = []
        for c in range(connections):
            con = fdb.connect(dsn='localhost:' + dbname, 
                              user=user_name,
                              password=password)
            #con.default_tpb = fdb.ISOLATION_LEVEL_REPEATABLE_READ
            cur = con.cursor()
            cons.append(con)
            curs.append(cur)

        # Initialise cycle
        c = 0
        cmax = len(curs)
        t0 = timeit.default_timer()
        t1 = t0

        # Run transaction's cycle
        while t1 - t0 <= duration:
            # Use clients via "round robin"
            c = (c + 1) % cmax
            # Random numbers for transaction input values
            branch_id, teller_id, account_id, delta = rand.next()
            sql = "execute procedure TPCB_FUNC_P_WORK({0:d}, " \
                  "{1:d}, {2:d}, {3:d})".format(branch_id, teller_id,
                                                account_id, delta)
            try:
                t1 = timeit.default_timer()
                #cons[c].begin()
                curs[c].execute(sql)
                x = curs[c].fetchone()[0]
                #curs[c].close()
                cons[c].commit()
                print("[connection: {0:d}] o_account_balance = {1:d}".format(
                    c, x))
            except:
                #cons[c].rollback()
                print("Transaction rollback due to lock.")

        print("Transactions finished.")

        # Close database sessions
        for c in range(connections):
            curs[c].close()
            cons[c].commit()
            cons[c].close()

        # Cleanup
        while curs:
            del curs[0]
        while cons:
            del cons[0]
        del rand

# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# --- Help Functions for Database Generation --------------------------------
# ---------------------------------------------------------------------------

def execute(sql, con, cur):
    cur.execute(sql)
    con.commit()

def timeexec(prnt, sql, con, cur):
    print(prnt + " ... " + "started" + ".")
    execute(sql, con, cur)
    print(prnt + " ... " + "finished" + ".")

def fileexec(prnt, filename, con, cur):
    path = os.path.join("firebird", filename)
    print("Path to SQL file: '%s'", path)
    sql = open(path, "r").read()
    execute(sql, con, cur)
    print(prnt)

# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# --- Preparation -----------------------------------------------------------
# ---------------------------------------------------------------------------

dbname      = "tpc.fdb"
user_name   = "SYSDBA"
password    = "masterkey"
scale       = 2


# Drop old database
con = None
con = fdb.connect(dsn='localhost:' + dbname, 
                  user=user_name,
                  password=password)
con.drop_database()
con.close()

# Create new Firebird database
con = fdb.create_database("create database '" + dbname + "' " + 
                          "user '" + user_name + "' " +
                          "password '" + password + "' " +
                          "page_size 16384 " +
                          "default character set utf8")
cur = con.cursor()

# Tables
fileexec("Table 'tpcb_branch' created.", "tpcb_branch.sql", con, cur)
fileexec("Table 'tpcb_teller' created.", "tpcb_teller.sql", con, cur)
fileexec("Table 'tpcb_account' created.", "tpcb_account.sql", con, cur)
fileexec("Table 'tpcb_history' created.", "tpcb_history.sql", con, cur)

# Functions
fileexec("Function 'func_init' created.", "func_init.sql", con, cur)
fileexec("Function 'func_work' created.", "func_work.sql", con, cur)

# Initialisation
timeexec(
    "Initializing TPC-B with scale={0:d}.".format(scale),
    "execute procedure tpcb_func_p_init(1, 10, 100000, {0:d})".format(scale),
    con, cur)

# Create Index
timeexec(
    "Creating primary key on 'tpcb_branch'.",
    "alter table tpcb_branch add constraint tpcb_branch_pk "
    "primary key (branch_id)",
    con, cur)

timeexec(
    "Creating primary key on 'tpcb_teller'.",
    "alter table tpcb_teller add constraint tpcb_teller_pk "
    "primary key (teller_id)",
    con, cur)
timeexec(
    "Creating foreign key to 'tpcb_branch' on 'tpcb_teller'.",
    "alter table tpcb_teller add constraint tpcb_teller_fk "
    "foreign key (branch_id) references tpcb_branch(branch_id)",
    con, cur)

timeexec(
    "Creating primary key on 'tpcb_account'.",
    "alter table tpcb_account add constraint tpcb_account_pk "
    "primary key (account_id)",
    con, cur)
timeexec(
    "Creating foreign key to 'tpcb_branch' on 'tpcb_account'.",
    "alter table tpcb_account add constraint tpcb_account_fk "
    "foreign key (branch_id) references tpcb_branch(branch_id)",
    con, cur)

timeexec(
    "Creating foreign key to 'tpcb_branch' on 'tpcb_history'.",
    "alter table tpcb_history add constraint tpcb_history_fk_1 "
    "foreign key (branch_id) references tpcb_branch(branch_id)",
    con, cur)
timeexec(
    "Creating foreign key to 'tpcb_teller' on 'tpcb_history'.",
    "alter table tpcb_history add constraint tpcb_history_fk_2 "
    "foreign key (teller_id) references tpcb_teller(teller_id)",
    con, cur)
timeexec(
    "Creating foreign key to 'tpcb_account' on 'tpcb_history'.",
    "alter table tpcb_history add constraint tpcb_history_fk_3 "
    "foreign key (account_id) references tpcb_account(account_id)",
    con, cur)

con.commit()
cur.close()
con.close()

# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# --- Testing ---------------------------------------------------------------
# ---------------------------------------------------------------------------

no_threads = 4

workers = []
# Start several threads
for t in range(no_threads):
    w = tpcbThread()
    workers.append(w)
    w.start()
# Wait finish of threads
for w in workers:
    w.join()
    del w

# ---------------------------------------------------------------------------



"""
fdb: 1.4.3
Firebird: 2.5.3
Output after: kill -USR1 <pid>

Thread 0x00007f3039020700 (most recent call first):
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3028 in _close
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3149 in __del__
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 2383 in __XSQLDA2Tuple
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3070 in _execute
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3353 in execute
  File "fbcall.py", line 70 in run
  File "/usr/lib/python3.4/threading.py", line 920 in _bootstrap_inner
  File "/usr/lib/python3.4/threading.py", line 888 in _bootstrap

Thread 0x00007f3039821700 (most recent call first):
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3062 in _execute
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3353 in execute
  File "fbcall.py", line 70 in run
  File "/usr/lib/python3.4/threading.py", line 920 in _bootstrap_inner
  File "/usr/lib/python3.4/threading.py", line 888 in _bootstrap

Thread 0x00007f303a022700 (most recent call first):
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3062 in _execute
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3353 in execute
  File "fbcall.py", line 70 in run
  File "/usr/lib/python3.4/threading.py", line 920 in _bootstrap_inner
  File "/usr/lib/python3.4/threading.py", line 888 in _bootstrap

Thread 0x00007f303a823700 (most recent call first):
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3062 in _execute
  File "/usr/local/lib/python3.4/dist-packages/fdb/fbcore.py", line 3353 in execute
  File "fbcall.py", line 70 in run
  File "/usr/lib/python3.4/threading.py", line 920 in _bootstrap_inner
  File "/usr/lib/python3.4/threading.py", line 888 in _bootstrap

Current thread 0x00007f303eaa2700 (most recent call first):
  File "/usr/lib/python3.4/threading.py", line 1076 in _wait_for_tstate_lock
  File "/usr/lib/python3.4/threading.py", line 1060 in join
  File "fbcall.py", line 226 in <module>
"""
