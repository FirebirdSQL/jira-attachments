set list on;
set bail on;
commit;

set transaction snapshot no wait;
select
    current_connection
   ,current_transaction
   ,'Start job at ' || current_timestamp as msg 
from rdb$database;

set term ^;
execute block
as
    declare m int = 50;
    declare i int;
    declare a_w int;
    declare v_c int;
    declare v_w int;
    declare v_x int;
    declare v_y int;
    declare c_qa cursor for (select w, x, y from qa where w = :a_w);
    declare c_qb cursor for (select w, x, y from qb where w = :a_w);
    declare v_qa_inserted int = 0;
    declare v_qb_inserted int = 0;
    declare v_qa_deleted int = 0;
    declare v_qb_deleted int = 0;
begin

    rdb$set_context('USER_SESSION', 'QA_INSERTED', null);
    rdb$set_context('USER_SESSION', 'QB_INSERTED', null);
    rdb$set_context('USER_SESSION', 'QA_DELETED',  null);
    rdb$set_context('USER_SESSION', 'QB_DELETED' , null);

    if ( exists( select * from stoptest ) ) 
    then
        exception exc_mism_detected using ( (select id from stoptest rows 1) );

    delete from gtt_job;
    i = m;
    while (i > 0) do
    begin
      merge into gtt_job t
      using (select cast(rand()*400 as int) w, cast(rand()*20 as int) c from rdb$database union all select 1,1 from rdb$database where 1=0) s
      on s.w = t.w
      when not matched then insert values(s.w, s.c)
      when matched then update set t.c = t.c + s.c
      ;
      i = i -1;
    end
    
    for select w, c from gtt_job into a_w, v_c
    do begin
      open c_qa;
      while (v_c > 0) do
      begin

        begin
          fetch c_qa into v_w, v_x, v_y;
          if (row_count = 0) then leave;
          delete from qa where current of c_qa;
          insert into qb(w, x, y) values(:v_w, :v_x, :v_y);

          v_qa_deleted = v_qa_deleted + 1;
          v_qb_inserted = v_qb_inserted + 1;

        when any do
          begin
            -- lock_conflict, concurrent_transaction, deadlock, update_conflict
            if ( gdscode NOT in (335544345, 335544878, 335544336,335544451 ) )
            then
                begin
                    in autonomous transaction do insert into exc_log(fbgds) values(gdscode);
                    exception exc_strange_gds using (gdscode);
                end
          end
        end
 
        v_c = v_c - 1;

      end
      close c_qa;
    end
    
    delete from gtt_job;
    i = m;
    while (i > 0) do
    begin
      merge into gtt_job t
      using (select cast(rand()*400 as int) w, cast(rand()*20 as int) c from rdb$database union all select 1,1 from rdb$database where 1=0) s
      on s.w = t.w
      when not matched then insert values(s.w, s.c)
      when matched then update set t.c = t.c + s.c
      ;
      i = i -1;
    end
    
    for select w, c from gtt_job into a_w, v_c
    do begin
      open c_qb;
      while (v_c > 0) do
      begin
        begin
          fetch c_qb into v_w, v_x, v_y;
          if (row_count = 0) then leave;
          delete from qb where current of c_qb;
          insert into qa(w, x, y) values(:v_w, :v_x, :v_y);

          v_qb_deleted = v_qb_deleted + 1;
          v_qa_inserted = v_qa_inserted + 1;

        when any do
          begin
            -- lock_conflict, concurrent_transaction, deadlock, update_conflict
            if ( gdscode NOT in (335544345, 335544878, 335544336,335544451 ) )
            then
                begin
                    in autonomous transaction do insert into exc_log(fbgds) values(gdscode);
                    exception exc_strange_gds using (gdscode);
                end
          end
        end

        v_c = v_c -1;

      end
      close c_qb;
    end
  
    rdb$set_context('USER_SESSION', 'QA_INSERTED', v_qa_inserted);
    rdb$set_context('USER_SESSION', 'QB_INSERTED', v_qb_inserted);
    rdb$set_context('USER_SESSION', 'QA_DELETED',  v_qa_deleted);
    rdb$set_context('USER_SESSION', 'QB_DELETED' , v_qb_deleted);

end
^
set term ;^

select 
     current_connection
    ,current_transaction
    ,'Finish job at ' || current_timestamp as msg 
    ,rdb$get_context('USER_SESSION', 'QA_INSERTED') as qa_inserted
    ,rdb$get_context('USER_SESSION', 'QB_INSERTED') as qb_inserted
    ,rdb$get_context('USER_SESSION', 'QA_DELETED') as qa_deleted
    ,rdb$get_context('USER_SESSION', 'QB_DELETED') as qb_deleted
    ,iif( rdb$get_context('USER_SESSION', 'QA_INSERTED') is distinct from rdb$get_context('USER_SESSION', 'QB_DELETED')
          or 
          rdb$get_context('USER_SESSION', 'QB_INSERTED') is distinct from rdb$get_context('USER_SESSION', 'QA_DELETED')
         ,'### ACHTUNG ###'
         ,'Ok.'
        ) as check_result
from rdb$database;

commit;

set bail off;
