create or alter view v_check_for_mismatch as select 1 id from rdb$database;

recreate exception exc_strange_gds 'Got strange gdscode = @1.';
recreate exception exc_mism_detected 'Mismatch detected at least for id=@1.';

set term ^;
execute block as
begin
  execute statement 'drop sequence g';
  when any do begin end
end
^ set term ;^

commit;

create sequence g;

recreate table stoptest(id int, qa_cnt int, qb_cnt int);

recreate table qa(x int, y int, w int);
recreate table qb(x int, y int, w int);
recreate table exc_log(fbgds int);

insert into qa(x, y, w)
select rand()*5, rand()*5, mod( gen_id(g,1), 400)
from rdb$types,rdb$types
rows 50000;

insert into qb(x, y, w)
select rand()*5, rand()*5, mod( gen_id(g,1), 400)
from rdb$types,rdb$types
rows 50000;

commit;

create index qa_xy on qa(w, x, y);
create index qb_xy on qb(w, x, y);
commit;

recreate global temporary table gtt_job(w int primary key using index gtt_job_pk, c int);
commit;

create or alter view v_check_for_mismatch as
select w, max(qa_cnt) qa_cnt, max(qb_cnt) qb_cnt
from (
    select 'qa' src, w, count(*) qa_cnt, 0 as qb_cnt
    from qa
    group by w
    union all
    select 'qb' src, w, 0, count(*) qb_cnt
    from qb
    group by w
)
group by w
having max(qa_cnt) + max(qb_cnt) is distinct from 250;
