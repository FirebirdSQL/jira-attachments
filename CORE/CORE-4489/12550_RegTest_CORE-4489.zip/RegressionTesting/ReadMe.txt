Please configure the RegTest_d567.ini file to point to where your Firebird 3 fbclient.dll is located.

Then, you should be able to run Win32\Debug\RegTest_d567.exe unit testing app.

Please let me know if I can help further.

Jason Wharton
www.ibobjects.com


