
    set echo on;

    set term ^;
    execute block as
    begin
        begin
            execute statement 'alter table department drop constraint fk_employee_department';
            when any do begin end
        end
        begin
            execute statement 'alter table usr drop constraint fk_department_usr';
            when any do begin end
        end
        begin
            execute statement 'alter table usr drop constraint fk_employee_usr';
            when any do begin end
        end
    end
    ^
    set term ;^
    commit;

    
    --1) making the table employee
    recreate table employee(
          empl_name varchar(30) not null
    );
    
    alter table employee
    add constraint pk_employee
    primary key (empl_name);
    
    --2) making the table department
    
    recreate table department(
           employee varchar(30) not null,
           dep_name varchar(30) not null
    );
    
    alter table department
    add constraint pk_department
    primary key (employee, dep_name);
    
    --3) making the table usr
    
    recreate table usr(
           employee varchar(30) not null,
           usr_name varchar(30) not null,
           department varchar(30)
    );
    
    alter table usr
    add constraint pk_usr
    primary key (employee, usr_name);
    
    commit;
    
    --4) making the relationships
    --4.1) employee -> department
    
    alter table department
    add constraint fk_employee_department
    foreign key (employee)
    references employee(empl_name)
    on update cascade;
    
    --4.2) department -> usr
    
    alter table usr
    add constraint fk_department_usr
    foreign key (employee, department)
    references department (employee, dep_name)
    on update cascade;
    
    --4.3) employee -> usr
    
    alter table usr
    add constraint fk_employee_usr
    foreign key (employee)
    references employee (empl_name)
    on update cascade;
    
    commit;
    
    --* i am making the relationships for that the field
    --department in table usr doesn't be required.
    --5) enter data in employee and department
    
    insert into employee (empl_name)
    values ('foo');
    
        
    insert into department (employee, dep_name)
    values ('foo', 'administrative');
    
    commit;
    
    --6) for test, updating the table employee
    
    update employee set empl_name = 'bar'
    where empl_name = 'foo';
    
    commit;

    select * from employee;

    select * from department;


    -- 7) enter data in usr

    insert into usr (employee, department, usr_name)
    values ('bar', 'administrative', 'andrew');

    insert into usr (employee, usr_name) values ('bar', 'joe');

    commit;

    --8) try to update employee

    update employee set empl_name = 'foo'
    where empl_name = 'bar'; 

    -- error
    --    the error says "foreign key reference target does not exist"
    --    however, when i delete the relashionships and make
    --    again, the error has solved.
    commit;
    set echo off;

    set term ^;
    execute block as
    begin
        begin
            execute statement 'alter table department drop constraint fk_employee_department';
            when any do begin end
        end
        begin
            execute statement 'alter table usr drop constraint fk_department_usr';
            when any do begin end
        end
        begin
            execute statement 'alter table usr drop constraint fk_employee_usr';
            when any do begin end
        end
    end
    ^
    set term ;^
    commit;


    drop table employee;
    drop table department;
    drop table usr;
    commit;

    set count on;
    set echo on;
    select * from rdb$relations 
    where rdb$relation_name in (upper('employee'), upper('department'), upper('usr'));
    select * from rdb$relation_constraints
    where rdb$relation_name in (upper('employee'), upper('department'), upper('usr'));
    set echo off;
    set count off;

    -- ##############################################################

