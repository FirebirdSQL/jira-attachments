shell del C:\MIX\firebird\QA\fbt-repo\tmp\c0077.fdb 2>nul;
create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\c0077.fdb';
show version;
commit;

set term ^;
execute block as
begin
  execute statement 'drop sequence g';
  when any do begin end
end
^
set term ;^
commit;
create sequence g;
commit;

set heading off;
set list on;
set bail on;

select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;
select '##### iter N ' || gen_id(g,1) || ' #####' as " " from rdb$database; in c0077-chk.sql;

