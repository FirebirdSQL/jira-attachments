shell del C:\MIX\firebird\QA\fbt-repo\tmp\c5092.fdb 2>nul;
set names utf8;
--create database '/:C:\MIX\firebird\QA\fbt-repo\tmp\c5092.fdb' default character set win1252;
create database '/:C:\MIX\firebird\QA\fbt-repo\tmp\c5092.fdb' default character set utf8;
show version;

recreate table t1 (
     n0 int

     ,si smallint computed by(32767)
    ,bi bigint computed by (2147483647)
    ,s2 smallint computed by ( mod(bi, nullif(si,0)) )

    ,dx double precision computed by (pi())
    ,fx float computed by (dx*dx)
    ,nf numeric(3,1) computed by (fx)

    ,dt date computed by ('now')
    ,tm time computed by ('now')
    -- eval not supported: ,dx  computed by ( dateadd(1 day to dt) )
    
    ,c1 char character set win1251 computed by ('ы')
    ,c2 char character set win1252 computed by ('å')
    ,cu char character set utf8 computed by ('∑')
    
    ,c1x char computed by(c1)
    ,c2x char computed by(c2)
    ,cux char computed by(cu)
    
    ,b1 blob character set win1251 computed by ('ы')
    ,b2 blob character set win1252 computed by ('ä')
    ,bu blob character set utf8 computed by ('∑')
    ,bb blob computed by ('∞')
    
    ,b1x blob computed by (b1)
    ,b2x blob computed by (b2)
    ,bux blob computed by (bu)
    ,bbx blob computed by (bb)
); 

insert into t1 values(null);
commit;

set sqlda_display on;
set blob all;
set list on;
select * from t1;
commit;
set echo on;
show table t1;
