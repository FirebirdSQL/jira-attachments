    shell del C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb 2>nul;
    create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb';
    show version;

    set list on;

    set term ^;
    create or alter trigger trg_tx_start_beta inactive on transaction start position 0 as begin end
    ^
    create or alter trigger trg_tx_start_anna inactive on transaction start position 0 as begin end
    ^
    create or alter trigger trg_tx_start_ciao inactive on transaction start position 0 as begin end
    ^
    commit
    ^
    drop trigger trg_tx_start_beta
    ^
    drop trigger trg_tx_start_anna
    ^
    drop trigger trg_tx_start_ciao
    ^

    recreate table trg_log( id integer, msg varchar(20) );
    ^

    execute block as
    begin
        execute statement 'drop sequence g';
        when any do begin end
    end
    ^
    set term ;^
    commit;

    ------------------------------------------------------------------
    connect 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb';
    ------------------------------------------------------------------

    set autoddl off;
    set bail on;

    create sequence g;
    commit;

    set term ^;
    create trigger trg_log_bi for trg_log active before insert position 0 as
    begin
        new.id = coalesce( new.id, gen_id(g,1) );
    end 
    ^
    set term ;^
    commit;


    set term ^;
    create or alter trigger trg_tx_start_ciao active on transaction start position 111 as
    begin
        if ( rdb$get_context('USER_SESSION','RUN_DB_LEVEL_TRG') is not null ) then
            insert into trg_log(msg) values('trigger tx_ciao');
    end 
    ^

    create or alter trigger trg_tx_start_anna active on transaction start position 3 as
    begin
        if ( rdb$get_context('USER_SESSION','RUN_DB_LEVEL_TRG') is not null ) then
            insert into trg_log(msg) values('trigger tx_anna');
    end 
    ^

    create or alter trigger trg_tx_start_beta active on transaction start position 22 as
    begin
        if ( rdb$get_context('USER_SESSION','RUN_DB_LEVEL_TRG') is not null ) then
            insert into trg_log(msg) values('trigger tx_beta');
    end 
    ^
    
    set term ;^
    commit;

    select
         r.rdb$trigger_name             
        ,r.rdb$trigger_sequence
        ,r.rdb$trigger_type
    from rdb$triggers r
    where r.rdb$trigger_name starting with upper('TRG_TX_START')
    order by r.rdb$trigger_sequence --------------------------- ! ---
    ;


    set term ^;
    execute block as
    begin
      rdb$set_context('USER_SESSION','RUN_DB_LEVEL_TRG', 1);
    end
    ^
    set term ;^

    
    set echo on;
    set count on;

    commit;
    select * from trg_log;
