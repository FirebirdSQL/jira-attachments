    shell del C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb 2>nul;
    create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb';
    show version;

    set list on;

    set term ^;
    create or alter trigger trg_tx_commit_beta inactive on transaction commit position 0 as begin end
    ^
    create or alter trigger trg_tx_commit_anna inactive on transaction commit position 0 as begin end
    ^
    create or alter trigger trg_tx_commit_ciao inactive on transaction commit position 0 as begin end
    ^
    commit
    ^
    drop trigger trg_tx_commit_beta
    ^
    drop trigger trg_tx_commit_anna
    ^
    drop trigger trg_tx_commit_ciao
    ^

    execute block as
    begin
        execute statement 'drop sequence g';
        when any do begin end
    end
    ^
    set term ;^
    commit;

    ------------------------------------------------------------------
    connect 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb';
    ------------------------------------------------------------------

    set autoddl off;
    set bail on;

    create sequence g;
    commit;


    set term ^;
    create or alter trigger trg_tx_commit_ciao active on transaction commit position 111 as
        declare c int;
    begin
        if ( rdb$get_context('USER_SESSION','RUN_DB_LEVEL_TRG') is not null ) then
        begin
            select count(*) from rdb$types,rdb$types,(select 1 i from rdb$types rows 3) into c;
            rdb$set_context('USER_SESSION','RUN_DB_LEVEL_TRG_CIAO', gen_id(g,1) || ': TRG_TX_COMMIT_CIAO ' || cast('now' as timestamp) );
        end
    end 
    ^

    create or alter trigger trg_tx_commit_anna active on transaction commit position 3 as
        declare c int;
    begin
        if ( rdb$get_context('USER_SESSION','RUN_DB_LEVEL_TRG') is not null ) then
        begin
            select count(*) from rdb$types,rdb$types,(select 1 i from rdb$types rows 3) into c;
            rdb$set_context('USER_SESSION','RUN_DB_LEVEL_TRG_ANNA', gen_id(g,1) || ': TRG_TX_COMMIT_ANNA ' || cast('now' as timestamp) );
        end
    end 
    ^

    create or alter trigger trg_tx_commit_beta active on transaction commit position 22 as
        declare c int;
    begin
        if ( rdb$get_context('USER_SESSION','RUN_DB_LEVEL_TRG') is not null ) then
        begin
            select count(*) from rdb$types,rdb$types,(select 1 i from rdb$types rows 3) into c;
            rdb$set_context('USER_SESSION','RUN_DB_LEVEL_TRG_BETA', gen_id(g,1) || ': TRG_TX_COMMIT_BETA ' || cast('now' as timestamp) );
        end
    end 
    ^
    
    set term ;^
    commit;

    select
         r.rdb$trigger_name             
        ,r.rdb$trigger_sequence
        ,r.rdb$trigger_type
    from rdb$triggers r
    where r.rdb$trigger_name starting with upper('trg_tx_commit')
    order by r.rdb$trigger_sequence --------------------------- ! ---
    ;


    set term ^;
    execute block as
    begin
      rdb$set_context('USER_SESSION','RUN_DB_LEVEL_TRG', 1);
    end
    ^
    set term ;^

    
    set echo on;
    set count on;

    commit;

    select 
        c.MON$VARIABLE_VALUE
       ,c.MON$VARIABLE_NAME
    from mon$context_variables c
    where c.mon$attachment_id = current_connection and c.mon$variable_name similar to '%(ANNA|BETA|CIAO)'
    order by c.mon$variable_VALUE ---------------------------------- ! ---
    ;
