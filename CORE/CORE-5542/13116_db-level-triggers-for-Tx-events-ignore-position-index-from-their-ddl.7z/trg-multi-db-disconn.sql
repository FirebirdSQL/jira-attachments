    shell del C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb 2>nul;
    create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb';
    show version;

    set list on;

    set term ^;
    create or alter trigger trg_db_deattach_beta inactive on connect position 0 as begin end
    ^
    create or alter trigger trg_db_deattach_anna inactive on connect position 0 as begin end
    ^
    create or alter trigger trg_db_deattach_ciao inactive on connect position 0 as begin end
    ^
    commit
    ^
    drop trigger trg_db_deattach_beta
    ^
    drop trigger trg_db_deattach_anna
    ^
    drop trigger trg_db_deattach_ciao
    ^

    recreate table tsignal( id integer )
    ^
    recreate table trg_log( id integer, msg varchar(20) );
    ^

    execute block as
    begin
        execute statement 'drop sequence g';
        when any do begin end
    end
    ^
    set term ;^
    commit;

    set autoddl off;
    set bail on;

    create sequence g;
    commit;

    set term ^;
    create trigger trg_log_bi for trg_log active before insert position 0 as
    begin
        new.id = coalesce( new.id, gen_id(g,1) );
    end 
    ^
    set term ;^
    commit;

    ------------------------------------------------------------------------

    set term ^;
    create or alter trigger trg_db_deattach_ciao active on connect position 111 as
    begin
        if ( exists(select * from tsignal) ) then
            insert into trg_log(msg) values('trigger tx_ciao');
    end 
    ^

    create or alter trigger trg_db_deattach_anna active on connect position 22 as
    begin
        if ( exists(select * from tsignal) ) then
            insert into trg_log(msg) values('trigger tx_anna');
    end 
    ^

    create or alter trigger trg_db_deattach_beta active on connect position 3 as
    begin
        if ( exists(select * from tsignal) ) then
            insert into trg_log(msg) values('trigger tx_beta');
    end 
    ^
    
    set term ;^
    commit;

    insert into tsignal(id) values(1);
    commit;

    ------------------------------------------------------------------
    connect 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\trg-multi.fdb';
    ------------------------------------------------------------------
    

    select
         r.rdb$trigger_name             
        ,r.rdb$trigger_sequence
        ,r.rdb$trigger_type
    from rdb$triggers r
    where r.rdb$trigger_name starting with upper('trg_db_deattach')
    order by r.rdb$trigger_sequence --------------------------- ! ---
    ;

    set echo on;
    set count on;
    select * from trg_log;
