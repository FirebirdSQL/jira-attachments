#include <stdio.h>
#include "include/ibase.h"

int pr_error (ISC_STATUS* status, const char* operation)
{
    printf("[\n");
    printf("PROBLEM ON \"%s\".\n", operation);

    isc_print_status(status);

    printf("SQLCODE:%d\n", isc_sqlcode(status));

    printf("]\n");

    return 1;
}


int main()
{
    ISC_STATUS_ARRAY status;               /* status vector */
	const ISC_SCHAR	dpb[] = {isc_dpb_version1,
							 isc_dpb_user_name, 6, 'S','Y','S','D','B','A',
							 isc_dpb_password, 9, 'm','a','s','t','e','r','k','e','y',
							 isc_dpb_lc_ctype, 7, 'w','i','n','1','2','5','1',
							 isc_dpb_sql_dialect, 1, 3
							};
	isc_db_handle db = 0;
	isc_tr_handle trans = 0;
	isc_stmt_handle stmt = 0;
 
    if (isc_attach_database(status, 0, "test", &db, sizeof(dpb), dpb))
        if (pr_error(status, "attach database"))
            return 1;

	if (isc_dsql_alloc_statement2(status, &db, &stmt))
        if (pr_error(status, "allocate statement"))
            return 1;


    /* newdb will be set to null on success */ 
    if (isc_detach_database(status, &db))
        if (pr_error(status, "attach database"))
            return 1;

	printf("statement handle after detach = %d\n", (int)stmt);
}
