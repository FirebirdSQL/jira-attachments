set bail on;

create domain dm_test int not null check ( value >=-1 );

create table test(mode varchar(30), result dm_test);
commit;

set term ^;
create procedure sp_test(
   i1 dm_test
  ,i2 type of dm_test
  ,i3 type of column test.result
) returns (
  o1 dm_test
  ,o2 type of dm_test
  ,o3 type of column test.result
)
as
  declare v1 dm_test = 3;
  declare v2 type of dm_test = 7;
  declare v3 type of column test.result = 9;
begin
  o1 = v1 * i1;
  o2 = v2 * i2;
  o3 = v3 * i3;

  suspend;

end
^

create function fn_test(
   i1 dm_test
  ,i2 type of dm_test
  ,i3 type of column test.result
) returns type of column test.result
as
  declare v1 dm_test = 11;
  declare v2 type of dm_test = 13;
  declare v3 type of column test.result = 17;
begin
  return v1 * i1 + v2 * i2 + v3 * i3;
end
^

create package pg_test as
begin
  procedure pg_proc(
     i1 dm_test
    ,i2 type of dm_test
    ,i3 type of column test.result
  ) returns (
    o1 dm_test
    ,o2 type of dm_test
    ,o3 type of column test.result
  );

  function pg_func(
     i1 dm_test
    ,i2 type of dm_test
    ,i3 type of column test.result
  ) returns type of column test.result;
end
^

create package body pg_test as
begin
  procedure pg_proc(
     i1 dm_test
    ,i2 type of dm_test
    ,i3 type of column test.result
  ) returns (
    o1 dm_test
    ,o2 type of dm_test
    ,o3 type of column test.result
  ) as
    declare v1 dm_test = 19;
    declare v2 type of dm_test = 23;
    declare v3 type of column test.result = 29;
  begin

    o1 = v1 * i1;
    o2 = v2 * i2;
    o3 = v3 * i3;

    suspend;

  end

  function pg_func(
     i1 dm_test
    ,i2 type of dm_test
    ,i3 type of column test.result
  ) returns type of column test.result as
    declare v1 dm_test = 13;
    declare v2 type of dm_test = 17;
    declare v3 type of column test.result = 19;
  begin
    return v1 * i1 + v2 * i2 + v3 * i3;
  end

end
^

set term ^;
commit;

--set echo on;

insert into test(mode, result)
select 'standalone proc', p.o1 + p.o2 + p.o3
from sp_test(9, 7, 5) p;

insert into test(mode, result)
select 'standalone func', fn_test(9, 7, 5)
from rdb$database;

insert into test(mode, result)
select 'packaged proc', p.o1 + p.o2 + p.o3
from pg_test.pg_proc(9, 7, 5) p;

insert into test(mode, result)
select 'packaged func', pg_test.pg_func(9, 7, 5)
from rdb$database;

select * from test;
commit;
/*
MODE                                 RESULT 
============================== ============ 
standalone proc                         121 
standalone func                         275 
packaged proc                           477 
packaged func                           331 
*/
