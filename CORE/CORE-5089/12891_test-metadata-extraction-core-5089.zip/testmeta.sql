set bail on;
set echo on;

SET SQL DIALECT 3; 

/* CREATE DATABASE '/:e30' PAGE_SIZE 8192 DEFAULT CHARACTER SET NONE; */

/* Domain definitions */
CREATE DOMAIN DM_TEST AS INTEGER NOT NULL;
COMMIT WORK;

COMMIT WORK;
SET AUTODDL OFF;
SET TERM ^ ;

/* Stored functions headers */
CREATE OR ALTER FUNCTION FN_TEST (I1 INTEGER,
I2 INTEGER,
I3 INTEGER)
RETURNS INTEGER
AS 
BEGIN END ^

SET TERM ; ^
COMMIT WORK;
SET AUTODDL ON;

COMMIT WORK;
SET AUTODDL OFF;
SET TERM ^ ;

/* Stored procedures headers */
CREATE OR ALTER PROCEDURE SP_TEST (I1 INTEGER,
I2 INTEGER,
I3 INTEGER)
RETURNS (O1 INTEGER,
O2 INTEGER,
O3 INTEGER)
AS 
BEGIN SUSPEND; END ^

SET TERM ; ^
COMMIT WORK;
SET AUTODDL ON;

COMMIT WORK;
SET AUTODDL OFF;
SET TERM ^ ;

/* Package headers */

/* Package header: PG_TEST, Owner: SYSDBA */
CREATE PACKAGE PG_TEST AS
begin
  procedure pg_proc(
     i1 dm_test
    ,i2 type of dm_test
    ,i3 type of column test.result
  ) returns (
    o1 dm_test
    ,o2 type of dm_test
    ,o3 type of column test.result
  );

  function pg_func(
     i1 dm_test
    ,i2 type of dm_test
    ,i3 type of column test.result
  ) returns type of column test.result;
end^

SET TERM ; ^
COMMIT WORK;
SET AUTODDL ON;

/* Table: TEST, Owner: SYSDBA */
CREATE TABLE TEST (MODE VARCHAR(30),
        RESULT DM_TEST);

COMMIT WORK;
SET AUTODDL OFF;
SET TERM ^ ;

/* Stored functions bodies */

ALTER FUNCTION FN_TEST (I1 DM_TEST,
I2 TYPE OF DM_TEST,
I3 TYPE OF COLUMN TEST.RESULT)
RETURNS TYPE OF COLUMN TEST.RESULT
AS 
declare v1 dm_test = 11;
  declare v2 type of dm_test = 13;
  declare v3 type of column test.result = 17;
begin
  return v1 * i1 + v2 * i2 + v3 * i3;
end ^

SET TERM ; ^
COMMIT WORK;
SET AUTODDL ON;

COMMIT WORK;
SET AUTODDL OFF;
SET TERM ^ ;

/* Stored procedures bodies */

ALTER PROCEDURE SP_TEST (I1 DM_TEST,
I2 TYPE OF DM_TEST,
I3 TYPE OF COLUMN TEST.RESULT)
RETURNS (O1 DM_TEST,
O2 TYPE OF DM_TEST,
O3 TYPE OF COLUMN TEST.RESULT)
AS 
declare v1 dm_test = 3;
  declare v2 type of dm_test = 7;
  declare v3 type of column test.result = 9;
begin
  o1 = v1 * i1;
  o2 = v2 * i2;
  o3 = v3 * i3;

  suspend;

end ^

SET TERM ; ^
COMMIT WORK;
SET AUTODDL ON;

COMMIT WORK;
SET AUTODDL OFF;
SET TERM ^ ;

/* Package bodies */

/* Package body: PG_TEST, Owner: SYSDBA */
CREATE PACKAGE BODY PG_TEST AS
begin
  procedure pg_proc(
     i1 dm_test
    ,i2 type of dm_test
    ,i3 type of column test.result
  ) returns (
    o1 dm_test
    ,o2 type of dm_test
    ,o3 type of column test.result
  ) as
    declare v1 dm_test = 19;
    declare v2 type of dm_test = 23;
    declare v3 type of column test.result = 29;
  begin

    o1 = v1 * i1;
    o2 = v2 * i2;
    o3 = v3 * i3;

    suspend;

  end

  function pg_func(
     i1 dm_test
    ,i2 type of dm_test
    ,i3 type of column test.result
  ) returns type of column test.result as
    declare v1 dm_test = 13;
    declare v2 type of dm_test = 17;
    declare v3 type of column test.result = 19;
  begin
    return v1 * i1 + v2 * i2 + v3 * i3;
  end

end^

SET TERM ; ^
COMMIT WORK;
SET AUTODDL ON;

/* Domain constraints */
ALTER DOMAIN DM_TEST ADD CONSTRAINT
         check ( value >=-1 );
