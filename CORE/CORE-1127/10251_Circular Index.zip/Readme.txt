These changes to the firebird 2.0 release code base detect a circular index database corruption that created in a version 1.5.1 data.

Firebired 2.0.0.12748 
Windows XP SP2
Superserver

Firebird-loops.log - output from the run which firebird loops infinitely during validation to recover this database
Firebird-detects.log - output from the machine running the modified server which detects the circular references and successfully repairs the database