set bail on;
shell del c:\temp\c6250t.fdb 2>nul;
create database 'localhost:c:\temp\c6250t.fdb';

set term ^;
create or alter package pg_test as
begin
  procedure sp_test ( a_since timestamp ) ;
end
^
recreate package body pg_test as
begin
    procedure sp_test ( a_since timestamp ) as begin end
end
^
set term ;^
commit;

set blob all;
set list on;
select p.rdb$package_body_source from rdb$packages p;
