shell del C:\MIX\firebird\QA\fbt-repo\tmp\c1364-utf8.fdb 2>nul;
set names utf8;
create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\c1364-utf8.fdb' user sysdba password 'masterkey';

set list on;
set bail on;
recreate table test(
  id int
  ,f1 varchar(100) character set iso8859_1 collate fr_fr_ci_ai -- failes on 'Œ' because it was not added into iso8859
);
commit;
recreate sequence g;
commit;

-- https://fr.wikipedia.org/wiki/Alphabet_fran%C3%A7ais
-- L’alphabet propre — 16 lettres 
-- À à 	Â â 	Æ æ 	Ç ç 	É é 	È è 	Ê ê 	Ë ë
-- Î î 	Ï ï 	Ô ô 	Œ œ 	Ù ù 	Û û 	Ü ü 	Ÿ ÿ 

insert into test(id, f1) values( gen_id(g,1) , 'À');
insert into test(id, f1) values( gen_id(g,1) , 'à');

insert into test(id, f1) values( gen_id(g,1) , 'Â');
insert into test(id, f1) values( gen_id(g,1) , 'â');

insert into test(id, f1) values( gen_id(g,1) , 'Æ');
insert into test(id, f1) values( gen_id(g,1) , 'æ');

insert into test(id, f1) values( gen_id(g,1) , 'Ç'); 
insert into test(id, f1) values( gen_id(g,1) , 'ç'); 	

insert into test(id, f1) values( gen_id(g,1) , 'É'); 
insert into test(id, f1) values( gen_id(g,1) , 'é'); 	

insert into test(id, f1) values( gen_id(g,1) , 'È');
insert into test(id, f1) values( gen_id(g,1) , 'è'); 	

insert into test(id, f1) values( gen_id(g,1) , 'Ê'); 
insert into test(id, f1) values( gen_id(g,1) , 'ê'); 	

insert into test(id, f1) values( gen_id(g,1) , 'Ë');
insert into test(id, f1) values( gen_id(g,1) , 'ë');

insert into test(id, f1) values( gen_id(g,1) , 'Î');
insert into test(id, f1) values( gen_id(g,1) , 'î');
	
insert into test(id, f1) values( gen_id(g,1) , 'Ï');
insert into test(id, f1) values( gen_id(g,1) , 'ï');	

insert into test(id, f1) values( gen_id(g,1) , 'Ô');
insert into test(id, f1) values( gen_id(g,1) , 'ô');


insert into test(id, f1) values( gen_id(g,1) , 'Ù');
insert into test(id, f1) values( gen_id(g,1) , 'ù');	

insert into test(id, f1) values( gen_id(g,1) , 'Û');
insert into test(id, f1) values( gen_id(g,1) , 'û');	

insert into test(id, f1) values( gen_id(g,1) , 'Ü');
insert into test(id, f1) values( gen_id(g,1) , 'ü');	

--insert into test(id, f1) values( gen_id(g,1) , 'Ÿ'); -- [a]
--insert into test(id, f1) values( gen_id(g,1) , 'ÿ'); -- [b] --failed

commit;

select count(*) as total_count from test;

set count on;
set echo on;
select t.* from test t 
where  _iso8859_1 'ÀÂÇÉÈÊËÎÏÔÙÛÜ' collate fr_fr_ci_ai like '%' || f1 || '%'
order by f1, id
;

select t.* from test t 
where  _iso8859_1 'àâçéèêëîïôùûü' collate fr_fr_ci_ai like '%' || f1 || '%'
order by f1, id
;
------------

exit;

select t.* from test t 
where  position( f1 in _iso8859_1 'ÀÂÇÉÈÊËÎÏÔÙÛÜ' collate fr_fr_ci_ai ) > 0
order by f1, id
;

select t.* from test t 
where  position( f1 in _iso8859_1 'àâçéèêëîïôùûü' collate fr_fr_ci_ai ) > 0
order by f1, id
;

--select 1 from rdb$database where _iso8859_1 'àâçéèêëîïôùûü' collate fr_fr_ci_ai like '%î%';
--select 2 from rdb$database where _iso8859_1 'ÀÂÇÉÈÊËÎÏÔÙÛÜ' collate fr_fr_ci_ai like '%Ô%';


-- https://www.quora.com/What-are-French-words-with-the-letters-%C3%A4-%C3%AB-%C3%AF-%C3%B6-%C3%BC-%C3%BF
-- Alex Taht, Jan 13, 2018
--- ÿ
-- ë, ï are the only ones that occur natively in French; 
-- ä, ö, ü, ÿ are used in the native Celtic languages in France, mostly in names.

/*
Œ and œ were omitted from ISO-8859-1 (as well as derived standards, such as IBM code page 850), which are still widespread in internet protocols and applications. Œ is the only character in modern French that is not included in ISO-8859-1, and this has led to it becoming replaced by 'oe' in many computer-assisted publications (including printed magazines and newspapers). This was due, in part, to the lack of available characters in the French ISO/IEC 646 version that was used earlier for computing. Another reason is that œ is absent from most French keyboards, and as a result, few people know how to input it. 
*/
--insert into test(id, f1) values( gen_id(g,1) , 'Œ'); -- [3]
--insert into test(id, f1) values( gen_id(g,1) , 'œ'); -- [4]

--insert into test(id, f1) values( gen_id(g,1) , '
--à 	Â â 	Æ æ 	Ç ç 	É é 	È è 	Ê ê 	Ë ë
--î 	Ï ï 	Ô ô 	Œ œ 	Ù ù 	Û û 	Ü ü 	Ÿ ÿ 


/*
 2012-08-29 15:43  asfernandes 
   D src/intl/collations/bl88591fr0.h
   M src/intl/lc_iso8859_1.cpp
   M src/intl/ld.cpp
   M src/jrd/IntlManager.cpp
Fixed CORE-3638 - Introduce FR_CA_CI_AI collation and change FR_FR and FR_FR_CI_AI to be identical to FR_CA and FR_CA_CI_AI respectively.
. . .
 2007-07-19 01:25  asfernandes 
   M builds/install/misc/fbintl.conf
   M src/intl/charsets.h
   M src/jrd/intlnames.h
1) CORE-1366 - French insensitive collation FR_FR_CI_AI
2) Renamed CP932 to CP943C per user feedback in CORE-1324

*/
