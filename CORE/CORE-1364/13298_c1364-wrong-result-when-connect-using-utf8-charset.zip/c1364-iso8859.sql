shell del C:\MIX\firebird\QA\fbt-repo\tmp\c1364-iso8859_1.fdb 2>nul;
set names iso8859_1;
create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\c1364-iso8859_1.fdb' user sysdba password 'masterkey';

set list on;
set bail on;
recreate table test(
  id int
  ,f1 varchar(100) character set iso8859_1 collate fr_fr_ci_ai -- failes on 'O' because it was not added into iso8859
);
commit;
recreate sequence g;
commit;

-- https://fr.wikipedia.org/wiki/Alphabet_fran%C3%A7ais
-- L'alphabet propre - 16 lettres 
-- � � 	� � 	� � 	� � 	� � 	� � 	� � 	� �
-- � � 	� � 	� � 	O o 	� � 	� � 	� � 	Y � 

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');

insert into test(id, f1) values( gen_id(g,1) , '�'); 
insert into test(id, f1) values( gen_id(g,1) , '�'); 	

insert into test(id, f1) values( gen_id(g,1) , '�'); 
insert into test(id, f1) values( gen_id(g,1) , '�'); 	

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�'); 	

insert into test(id, f1) values( gen_id(g,1) , '�'); 
insert into test(id, f1) values( gen_id(g,1) , '�'); 	

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');
	
insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');	

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');


insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');	

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');	

insert into test(id, f1) values( gen_id(g,1) , '�');
insert into test(id, f1) values( gen_id(g,1) , '�');	

--insert into test(id, f1) values( gen_id(g,1) , 'Y'); -- [a]
--insert into test(id, f1) values( gen_id(g,1) , '�'); -- [b] --failed

commit;

select count(*) as total_count from test;

set count on;
set echo on;
select t.* from test t 
where  _iso8859_1 '�������������' collate fr_fr_ci_ai like '%' || f1 || '%'
order by f1, id
;

select t.* from test t 
where  _iso8859_1 '�������������' collate fr_fr_ci_ai like '%' || f1 || '%'
order by f1, id
;
------------
exit;

select t.* from test t 
where  position( f1 in _iso8859_1 '�������������' collate fr_fr_ci_ai ) > 0
order by f1, id
;

select t.* from test t 
where  position( f1 in _iso8859_1 '�������������' collate fr_fr_ci_ai ) > 0
order by f1, id
;

select 1 from rdb$database where _iso8859_1 '�������������' collate fr_fr_ci_ai like '%�%';
select 2 from rdb$database where _iso8859_1 '�������������' collate fr_fr_ci_ai like '%�%';


