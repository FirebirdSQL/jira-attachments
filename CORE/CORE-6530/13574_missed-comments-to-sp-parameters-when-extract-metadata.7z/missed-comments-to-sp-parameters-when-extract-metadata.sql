set bail on;
shell del C:\temp\tmp.fdb 2>nul;
create database 'localhost:C:\temp\tmp.fdb';
set term ^;
create or alter procedure sp_1(
     p00 int                                                    -- single-line comment for `p00`
    ,p01 int                                                    
                                                                /*
                                                                     multi-line comment
                                                                     for `p01`,
                                                                     typed on
                                                                     several
                                                                     lines
                                                                */
    ,p02 int                                                    /* multi-line comment for `p02`, typed in one line */
    ,p03 varchar(1) character set utf8                          -- single line comment for `p03` which has `character set` clause
    ,p04 type of column rdb$database.rdb$relation_id            /* multi-line comment for `p04` which has `type of column` clause */
    ,
    p05 int default null                                       -- p05
    --      ^^^^^^^
    ,
    p06 int = null                                             /* p06 */
    --      ^
) returns (
    r01 int                                                     -- r01
   ,r02 char(1) not null                                       /* r02 */
)
as
begin
    -- nop --
end
^
set term ;^
commit; 
