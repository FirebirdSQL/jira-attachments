﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> dbs = new List<string>();

        public MainWindow()
        {
            InitializeComponent();
            m_Timer = new DispatcherTimer();
            m_Timer.Interval = TimeSpan.FromMilliseconds(50);
            m_Timer.Tick += M_Timer_Tick;
            m_Timer.Start();
        }

        private void M_Timer_Tick(object sender, EventArgs e)
        {
            Alive = m_ProcessAlive;
            Crashed = m_ProcessCrashed;
            Simultanious = m_Simul;
        }

        bool m_Stopped = true;
        DispatcherTimer m_Timer;

        Random m_Random = new Random();

        void RunCommand(FbConnection aCon, string Path = null)
        {
            using (var tr = aCon.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
            {
                using (var cmd = aCon.CreateCommand())
                {
                    cmd.Transaction = tr;
                    cmd.CommandText = "select version_start2() from rdb$database";
                    cmd.ExecuteNonQuery();
                    tr.Commit();
                }
            }
        }

        int m_ProcessId;
        int m_ProcessAlive;
        int m_ProcessCrashed;
        int m_Simul;

        public int Alive
        {
            get { return (int)GetValue(AliveProperty); }
            set { SetValue(AliveProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Alive.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AliveProperty =
            DependencyProperty.Register("Alive", typeof(int), typeof(MainWindow), new PropertyMetadata(0));



        public int Crashed
        {
            get { return (int)GetValue(CrashedProperty); }
            set { SetValue(CrashedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Crashed.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CrashedProperty =
            DependencyProperty.Register("Crashed", typeof(int), typeof(MainWindow), new PropertyMetadata(0));



        public int Simultanious
        {
            get { return (int)GetValue(SimultaniousProperty); }
            set { SetValue(SimultaniousProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Simultanious.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SimultaniousProperty =
            DependencyProperty.Register("Simultanious", typeof(int), typeof(MainWindow), new PropertyMetadata(0));



        void Process()
        {
            Interlocked.Increment(ref m_ProcessAlive);
            var process = Interlocked.Increment(ref m_ProcessId);
            try
            {
                while (!m_Stopped)
                {
                    var constr = dbs[m_Random.Next(dbs.Count)];
                    Interlocked.Increment(ref m_Simul);
                    try
                    {
                        using (var con = new FbConnection(constr))
                        {
                            con.Open();
                            RunCommand(con);
                        }
                    }
                    finally
                    {
                        Interlocked.Decrement(ref m_Simul);
                    }
                    Thread.Sleep(m_Random.Next(500));
                }
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                Interlocked.Increment(ref m_ProcessCrashed);
            }
            finally
            {
                Interlocked.Decrement(ref m_ProcessAlive);
            }
        }

        FbConnection m_Con;

        void Start(object sender, RoutedEventArgs e)
        {
            if (m_Stopped)
            {
                btn.Content = "Stop";
                dbs.Clear();
                var fbsb = new FbConnectionStringBuilder();
                fbsb.Charset = "UTF8";
                //fbsb.Database = @"d:\fast.fdb";
                fbsb.DataSource = "localhost";
                fbsb.Password = "masterkey";
                fbsb.UserID = "SYSDBA";
                fbsb.Port = Convert.ToInt32(txtPort.Text);
                fbsb.Pooling = false;
                var rootfolder = txtRoot.Text;
                dbs.Clear();
                for (int i = 0; i < 10; i++)
                {
                    fbsb.Database = System.IO.Path.Combine(rootfolder, i.ToString(), "test.fdb");
                    dbs.Add(fbsb.ToString());
                }

                m_ProcessAlive = 0;
                m_ProcessCrashed = 0;

                if (chkOpen.IsChecked ?? false)
                {
                    btnStopConnection.IsEnabled = true;
                    m_Con = new FbConnection(dbs[0]);
                    m_Con.Open();
                    RunCommand(m_Con);
                }

                m_Stopped = false;
                var max = Convert.ToInt32(txtClients.Text);
                for (int i = 0; i < max; i++)
                {
                    Task.Run(() => Process());
                }
            }
            else
            {
                m_Stopped = true;
                btn.Content = "Start";
                if (m_Con != null)
                {
                    m_Con.Dispose();
                    m_Con = null;
                }
            }
        }

        private void StopConnection(object sender, RoutedEventArgs e)
        {
            if (m_Con != null)
            {
                chkOpen.IsChecked = false;
                btnStopConnection.IsEnabled = false;
                m_Con.Dispose();
                m_Con = null;
            }
        }
    }
}
