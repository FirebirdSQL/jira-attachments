shell del C:\MIX\firebird\QA\fbt-repo\tmp\c0749.fdb 2>nul;
set bail on;
set names utf8;
create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\c0749.fdb';

create domain 
"Лев" smallint
;

create exception
"Все"
'Все смешалось в доме Облонских. Жена узнала, что муж был в связи
    с бывшею в их доме француженкою-гувернанткой, и объявила мужу, что
    не может жить с ним в одном доме'
;
    
create sequence
"йцу"    
;

create role
"кенг"
;

create table
"табла"
(
"ид" "Лев",
"хм" "Лев" 
);

create view
"яя" as
select 
     "ид" as
     "чч"
    ,"хм" as
    "Лев"
from 
"табла"
;

set term ^;
create procedure
"ыы" (
"хм" "Лев"
) returns (
"табла" "Лев"
)
as
declare 
"фф"
"Лев";
begin
select
"Лев"
from
"яя"
where 
"чч" < "Лев"
and "Лев" > :"хм"
rows 1
into
"фф";
"табла" = "фф";
suspend;
end
^
set term ;^
commit;

set list on;
insert into "яя" values(123, 456);
select * from "ыы"(100);
