reCREATE TABLE testlpad (
 t_key integer not null,
 t_value integer,
 primary key( t_key)
);
COMMIT;
insert into testlpad(t_key,t_value) values (0,1);
insert into testlpad(t_key,t_value) values (1,2);
insert into testlpad(t_key,t_value) values (2,3);
COMMIT;

set echo on;
set list on;
SELECT lpad('', t_value,'-') from testlpad;
