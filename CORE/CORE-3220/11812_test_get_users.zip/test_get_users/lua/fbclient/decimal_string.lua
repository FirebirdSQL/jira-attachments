--[=[
	Decimal string support

	df(lo,hi,scale) -> s; to be used with getdecimal()
	sdf(s,scale)	-> lo,hi; to be used with setdecimal()

	xsqlvar:getdecstring() -> s
	xsqlvar:setdecstring(s)

	xsqlvar:set(s), extended to support string-type decimals
	xsqlvar:get() -> s, extended to support string-type decimals

	USAGE: just require the module.

	LIMITATIONS:
	- assumes 2's complement signed int64 format (no byte order assumption though).

]=]

module(...,require 'fbclient.init')

local xsqlvar_class = require('fbclient.xsqlvar').xsqlvar_class

--stolen from here: http://lua-users.org/lists/lua-l/2010-01/msg00261.html
local function dec2hex(s)
	local base = 2^24
	local function adddigit(t,d)
		local carry = d
		for i = 1, #t do
			local p = t[i] * 1000000 + carry
			t[i] = p % base
			carry = math.floor(p/base)
		end
		if carry ~= 0 then
			t[#t+1] = carry
		end
	end
	if #s < 15 then
		return ('%x'):format(s)
	end
	local thex = {}
	local j = #s % 6
	if j ~= 0 then
		thex[1] = tonumber(s:sub(1, j))
	end
	for i = j+1, #s, 6 do
		adddigit (thex, tonumber(s:sub(i, i+5)))
	end
	local hex = ''
	for i = 1, #thex-1 do
		hex = ('%06x'):format(thex[i]) .. hex
	end
	return ('%x'):format(thex[#thex]) .. hex
end

local hex2dec(s)

end

function I64toStr(I64 : array[1..4] of byte) : string;
//convert a 64 bit integer to a string
const d = 10;
      hb = $80;
      msk = $7f;
var i,j,b,c : byte;
    sum : word;
begin
 result := '';
 repeat
   I64[8] := 0;
   for i := 1 to 64 do
    begin
     for j := 8 downto 1 do
      begin
       c := I64[j-1] shr 7;
       I64[j] := ((I64[j] and msk) shl 1) or c;
      end;//for j
      if I64[8] >= d then begin
                           b := 1;
                           I64[8] := I64[8] - d;
                           end
      else b := 0;
     I64[0] := ((I64[0] and msk) shl 1) or b;
    end;//for i
   insert(chr(ord('0') + I64[8]),result,0);
  sum := 0;
  for j := 0 to 7 do inc(sum,I64[j]);
 until sum = 0;
end;


--convert the lo,hi dword pairs of a 64bit integer into the a decimal
--number and scale it down
function df(lo,hi,scale)
	if hi*2^32+lo

	if hi > 0 then
		local hex = ('%x%x'):format(hi,lo)
		local dec = hex2dec(hex)
		return dec:sub(1,-scale-1)..util.DECIMAL_DOT_SYMBOL..dec:sub(scale-1)
	end
end

--scale up a decimal (or hex) string number and convert it into the
--corresponding lo,hi dword pairs of its int64 representation
function sdf(s,scale)
	local hex = s:match('^0x(%x+)$') --string is a hex number, always unsigned
	if not hex then
		local sign,int,frac = s:find('^(%-?)(%d*)%.?(%d*)$') --string is a decimal number, possibly signed
		local dec = int..frac..('0'):rep(scale-#frac)
		if sign == '-' then
			--
		end
		hex = dec2hex(dec)
	end
	return
end

function xsqlvar_class:getdecstring()
	return self:getdecimal(df)
end

function xsqlvar_class:setdecstring(s)
	self:setdecimal(s,sdf)
end

xsqlvar_class.add_set_handler(
	function(self,p,typ,opt)
		if type(p) == 'string' and (typ == 'int16' or typ == 'int32' or typ == 'int64') then
			self:setdecstring(p)
			return true
		end
	end
)

xsqlvar_class.add_get_handler(
	function(self,typ,opt)
		if typ == 'int16' or typ == 'int32' or typ == 'int64' then
			return true,self:getdecstring()
		end
	end
)
