--[[
	IndexedList -> a list of table elements with one or more unique keys to index by.
	DetailList -> a proxy list whose elements are actually kept in sub-lists in a master list.
	IndexedDetailList -> a detail list that can also be indexed.
	SelectedList -> a list you can load with the resulted rows of an sql statement.
]]

module(...,require 'fbclient.init')

local oo = require 'loop.multiple'

List = oo.class({}, List)
--List.keys = {key1_name = true,...}
--List.primary_key = key_name
--List.foreign_keys = {{key=, list=, lookup_key=},...}

function List:__init()
	local self = oo.rawnew(self,{})
	for key in pairs(self.keys) do
		self['by_'..key] = {}
	end
	self.count = 0
	return self
end

function List:add(e)
	for key in pairs(self.keys) do
		self['by_'..key][e[key]] = e
	end
	self.count = self.count+1
	self:link(e)
end

function List:remove(e)
	for key in pairs(self.keys) do
		self['by_'..key][e[key]] = nil
	end
	self.count = self.count-1
end

function List:get(e)
	return self['by_'..self.primary_key][e[self.primary_key]]
end

function List:wrap(e) return e end

function List:set(e)
	local ee = self:get(e)
	if not ee then
		ee = self:wrap(e)
		self:add(ee)
	end
	self:update(ee,e)
end

function List:update(ee,e)
	for k,v in pairs(e) do
		ee[k] = v
	end
	for i,fk in ipairs(self.foreign_keys) do
		fk.lookup_list[fk.lookup_key]
	end
end

function List:load(transaction,...)
	for st in transaction:exec(self:select_query(...)) do
		self:set(st:row())
	end
end

DetailList = oo.class({}, List)
--DetailList.master_key = name of an unique key in the master list
--DetailList.detail_list_name = the name of the detail list in the master list
--DetailList.parent_key = the name of the foreign key in the detail list
--DetailList.parent_list_name = the name of a reference to the parent list in the detail list (optional)

function DetailList:__init(master_list)
	return oo.rawnew(self, {
		master_list = master_list,
	})
end

function DetailList:get_parent_list(e)
	if self.parent_list_name and e[parent_list_name] then
		return e[parent_list_name]
	else
		local parent_list = assert(self.master_list['by_'..self.master_key][e[self.parent_key]], 'parent not found')
		if self.parent_list_name then
			e[parent_list_name] = parent_list
		end
		return assert(parent_list[self.detail_list_name], 'detail list not found')
	end
end

function DetailList:add(e) self:get_parent_list(e):add(e) end
function DetailList:remove(e) self:get_parent_list(e):remove(e) end
function DetailList:get(e) return self:get_parent_list(e):get(e) end
function DetailList:set(e) self:get_parent_list(e):set(e) end

IndexedDetailList = oo.class({}, IndexedList)

function IndexedDetailList:add(e)
	IndexedList.add(self,e)
	DetailList.add(self,e)
end

function IndexedDetailList:remove(e)
	IndexedList.remove(self,e)
	DetailList.remove(self,e)
end

TreeList = oo.class({}, List)
--TreeList.

