
--change this to your setup: firebird 2.0.x instance is needed (I used 2.0.6)
local server = 'localhost/3206'

local config = require 'test_config'

function test_everything(env)

	require 'fbclient.error_codes'
	local service_class = require 'fbclient.service_class'
	local util = require 'fbclient.util'
	local dump = util.dump
	local timeout = 2

	local svc = service_class.connect(env.server, env.username, env.password, timeout, env.libname)
	print(string.format('connect("%s", "%s", "%s", "%s", "%s")',
					env.server or '(embedded)', env.username, env.password, timeout, env.libname))

	svc:user_delete('wrong_user')

	--to workaround the bug, uncomment the following line, which queries for isc_info_svc_line
	--for line_num,line in svc:lines() do print(line_num,line) end

	print('user_list()')
	dump(svc:user_list())
end

local comb = {lib='fbclient',ver='2.5.0',server=server,server_ver='2.0.6'}

config.run(test_everything,comb,nil,...)

