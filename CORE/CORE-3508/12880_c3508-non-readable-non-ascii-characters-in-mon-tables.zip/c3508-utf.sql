shell del C:\MIX\firebird\QA\fbt-repo\tmp\Ministère_des_Affaires_étrangères 2>nul;
shell del C:\MIX\firebird\QA\fbt-repo\tmp\Министерство_иностранных_дел 2>nul;
set names utf8;
create database '/3333:C:\MIX\firebird\QA\fbt-repo\tmp\Ministère_des_Affaires_étrangères';
set list on;
select 'literal string' as source, 'Ministère_des_Affaires_étrangères' as non_ascii_name from rdb$database
union all
select 'mon$database_name', mon$database_name from mon$database
union all
select 'mon$attachment_name', mon$attachment_name from mon$attachments where mon$attachment_id = current_connection
;
commit;
drop database;

create database '/3333:C:\MIX\firebird\QA\fbt-repo\tmp\Министерство_иностранных_дел';

select 'literal string' as source, 'Министерство_иностранных_дел' as non_ascii_name from rdb$database
union all
select 'mon$database_name', mon$database_name from mon$database
union all
select 'mon$attachment_name', mon$attachment_name from mon$attachments where mon$attachment_id = current_connection
;
commit;
drop database;