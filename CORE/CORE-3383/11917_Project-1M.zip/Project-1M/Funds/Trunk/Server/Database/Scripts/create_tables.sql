INPUT 'tables\dict_type.sql';
INPUT 'tables\dict_data.sql';
