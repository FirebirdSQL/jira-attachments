INPUT 'domains\logical.sql';
