INPUT 'data\dict_type.dat';
INPUT 'data\dict_data.dat';
