INPUT 'generators\gen_dict_type.sql';
INPUT 'generators\gen_dict_data.sql';
