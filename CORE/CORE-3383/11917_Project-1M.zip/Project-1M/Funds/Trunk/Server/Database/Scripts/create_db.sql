SET SQL DIALECT 3;

CREATE DATABASE '..\p1m_funds.fdb' PAGE_SIZE 8192 USER 'SYSDBA' PASSWORD 'masterkey';

INPUT 'create_exceptions.sql';
INPUT 'create_generators.sql';
INPUT 'create_domains.sql';
INPUT 'create_tables.sql';
INPUT 'create_procedures.sql';
INPUT 'create_data.sql';

EXIT;

