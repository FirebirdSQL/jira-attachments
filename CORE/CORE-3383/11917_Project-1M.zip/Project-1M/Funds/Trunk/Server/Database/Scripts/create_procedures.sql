INPUT 'procedures\get_dict_type_id.sql';
INPUT 'procedures\load_err_msg.sql';
INPUT 'procedures\raise_null_expection.sql';
INPUT 'procedures\dict_type_insert.sql';
INPUT 'procedures\dict_data_insert.sql';
