package testFBbug;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class db {

  private static Connection con;
   
  private static final String DRIVER = "org.firebirdsql.jdbc.FBDriver";

  private static String URL = "jdbc:firebirdsql:embedded:db/parcelle.fdb"; 

  //private static String URL = "jdbc:firebirdsql:localhost:parcelle"; 

  private static final String USER = "SYSDBA";

  private static final String PWD = "masterkey";

  public static void init() {

    try {
      
      Class.forName(DRIVER);
      
      try {

        con = DriverManager.getConnection(URL, USER, PWD);

        con.setAutoCommit(false);
        
        con.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
      
      } catch (Exception e) {
      
        if (con != null) {
        
          try {
          
            if (!con.isClosed()) con.close();
          
          } catch (Exception ignore) {
            
            System.out.println ("Eccezione ignorata" + ignore.getMessage());
            
          }
        }
        throw e;
      }
    } catch (Exception e) {
      
      System.out.println ("Errore inizializzazione driver " + e.getMessage());
      
    }
  }

  public db() {

    init();
    
  }

  public static String getDriver() {
    
    return DRIVER;
    
  }
  
  public static String getConnectionString() {
    
    return URL;
    
  }
  
  public static Connection getConn() {
    return con;
  }  

  public static Statement getStatement() {
    
    try {
     
      Statement stm = getConn().createStatement();
      
      return stm;
    
    } catch(Exception e) {
      
      System.out.println(e.getMessage());
      
      return null;
      
    }  
    
  }

  
}

