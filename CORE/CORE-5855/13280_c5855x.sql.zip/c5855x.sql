shell del C:\MIX\firebird\QA\fbt-repo\tmp\c5855.fdb 2>nul;
set names utf8;
set list on;
set count on;
set bail on;
create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\c5855.fdb' default character set utf8;
set echo on;
create sequence "" start with -1;
create sequence "" start with  2;
create sequence "" start with  3;
create sequence "" start with  4;
create sequence "" start with  5;
create sequence "" start with  6;
create sequence "" start with  7;
create sequence "" start with  8;
create sequence "	" start with  9;
create sequence "
" start with 10;
create sequence "" start with 11;
create sequence "" start with 12;
create sequence "" start with 13;
create sequence "" start with 14;
create sequence "" start with 15;
create sequence "" start with 16;
create sequence "" start with 17;
create sequence "" start with 18;
create sequence "" start with 19;
create sequence "" start with 20;
create sequence "" start with 21;
create sequence "" start with 22;
create sequence "" start with 23;
create sequence "" start with 24;
create sequence "" start with 25;
--create sequence ASCII_CHAR(26) start with 26; -- Expected end of statement, encountered EOF
create sequence "" start with 27;
create sequence "" start with 28;
create sequence "" start with 29;
create sequence "" start with 30;
create sequence "" start with 31;
create sequence " " start with 32;
commit;

select 
    '>' || trim( rdb$generator_name ) || '<' as gen_name
    ,iif(  trim(rdb$generator_name)='', 32, ascii_val( right(trim(rdb$generator_name),1) )) as gen_ascii_val
    ,rdb$initial_value as gen_initial_value
from rdb$generators 
where rdb$system_flag is distinct from 1;
