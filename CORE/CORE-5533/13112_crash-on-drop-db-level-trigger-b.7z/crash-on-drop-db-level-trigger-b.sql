shell rm -f /var/tmp/trgtest.fdb;
create database 'localhost:/var/tmp/trgtest.fdb' user 'SYSDBA' password 'masterkey';
show version;

set bail on;
set list on;
set term ^;
execute block as
begin
    begin
        rdb$set_context('USER_SESSION','POINT_1','1');
        execute statement 'drop trigger trg_tx_start';
    when any do begin end
    end
    rdb$set_context('USER_SESSION','POINT_1','2');

end
^
set term ;^
commit;

recreate table tlog (id int default current_transaction, msg varchar(30));

set term ^;
create trigger trg_tx_start inactive on TRANSACTION START as
begin
  execute statement ('insert into tlog(msg) values(?)') ('Tx start');
end
^
set term ;^
commit;

alter trigger trg_tx_start active;
commit;

set autoddl off;

set echo on;

select * from tlog; ---------------- 1
rollback;
quit;
