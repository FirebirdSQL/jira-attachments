shell rm -f /var/tmp/trgtest.fdb;
create database 'localhost:/var/tmp/trgtest.fdb' user 'SYSDBA' password 'masterkey';
show version;

set bail on;
set list on;
set echo on;
set term ^;
execute block as
begin
    begin
        --rdb$set_context('USER_SESSION','POINT_1','1');
        execute statement 'drop trigger trg_tx_start';
    when any do begin end
    end
    --rdb$set_context('USER_SESSION','POINT_1','2');

end
^
set term ;^
commit;

recreate table tlog (ID integer, MSG varchar(100));

set term ^;
create trigger trg_tx_start on TRANSACTION START position 0
as
begin
  execute statement ('insert into tlog(msg) values(?)') ('Tx start');
end
^
set term ;^
commit;

connect 'localhost:/var/tmp/trgtest.fdb' user 'SYSDBA' password 'masterkey';

set term ^;
execute block as
    declare c int;
begin
    begin
        --rdb$set_context('USER_SESSION','POINT_1','3');
        --select count(*) from rdb$types,rdb$types,rdb$types into c;
        execute statement 'drop trigger trg_tx_start';
    when any do begin end
    end
    --rdb$set_context('USER_SESSION','POINT_1','4');

end
^
set term ;^
commit;
quit;
