test_db_client_fb_1.exe it is 32bit application, compiled by VS2019. Uses dynamic CRT.

1. Copy firebird\security3.fdb and firebird\firebird.conf to FB-folder
2. Copy ibp_test_fb30_d3.gdb to database folder
3. Correct run.bat
   - REPLACE "HOME4" to "LOCALHOST" or other name
   - CORRECT path to database file - "d:\database\ram\ibp_test_fb30_d3.gdb"
4. Execute run.bat
