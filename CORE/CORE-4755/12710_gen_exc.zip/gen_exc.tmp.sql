recreate exception ex_surprised 'OMG... Look what I''ve got:
@1
@2
@3
@4
@5
@6
@7
@8
@9
@10
@11
@12
@13
@14
@15
@16
@17
@18
@19
@20
@21
@22
@23
@24
@25
@26
@27
@28
@29
@30
@31
@32
@33
@34
@35
@36
@37
@38
@39
@40
@41
@42
@43
@44
@45
@46
@47
@48
@49
@50
@51
@52
@53
@54
@55
@56
@57
@58
@59
@60
@61
@62
@63
@64
@65
@66
@67
@68
@69
@70
@71
@72
@73
@74
@75
@76
@77
@78
@79
@80
@81
@82
@83
@84
@85
@86
@87
@88
@89
@90
@91
@92
@93
@94
@95
@96
@97
@98
@99
@100
@101
@102
@103
@104
@105
@106
@107
@108
@109
@110
@111
@112
@113
@114
@115
@116
@117
@118
@119
@120
@121
@122
@123
@124
@125
@126
@127
@128
@129
@130
@131
@132
@133
@134
@135
@136
@137
@138
@139
@140
@141
@142
@143
@144
@145
@146
@147
@148
@149
@150
@151
@152
@153
@154
@155
@156
@157
@158
@159
@160
@161
@162
@163
@164
@165
';
commit;
set term ^;
execute block as
  declare v_1 int = 12346;
  declare v_2 int = 12347;
  declare v_3 int = 12348;
  declare v_4 int = 12349;
  declare v_5 int = 12350;
  declare v_6 int = 12351;
  declare v_7 int = 12352;
  declare v_8 int = 12353;
  declare v_9 int = 12354;
  declare v_10 int = 12355;
  declare v_11 int = 12356;
  declare v_12 int = 12357;
  declare v_13 int = 12358;
  declare v_14 int = 12359;
  declare v_15 int = 12360;
  declare v_16 int = 12361;
  declare v_17 int = 12362;
  declare v_18 int = 12363;
  declare v_19 int = 12364;
  declare v_20 int = 12365;
  declare v_21 int = 12366;
  declare v_22 int = 12367;
  declare v_23 int = 12368;
  declare v_24 int = 12369;
  declare v_25 int = 12370;
  declare v_26 int = 12371;
  declare v_27 int = 12372;
  declare v_28 int = 12373;
  declare v_29 int = 12374;
  declare v_30 int = 12375;
  declare v_31 int = 12376;
  declare v_32 int = 12377;
  declare v_33 int = 12378;
  declare v_34 int = 12379;
  declare v_35 int = 12380;
  declare v_36 int = 12381;
  declare v_37 int = 12382;
  declare v_38 int = 12383;
  declare v_39 int = 12384;
  declare v_40 int = 12385;
  declare v_41 int = 12386;
  declare v_42 int = 12387;
  declare v_43 int = 12388;
  declare v_44 int = 12389;
  declare v_45 int = 12390;
  declare v_46 int = 12391;
  declare v_47 int = 12392;
  declare v_48 int = 12393;
  declare v_49 int = 12394;
  declare v_50 int = 12395;
  declare v_51 int = 12396;
  declare v_52 int = 12397;
  declare v_53 int = 12398;
  declare v_54 int = 12399;
  declare v_55 int = 12400;
  declare v_56 int = 12401;
  declare v_57 int = 12402;
  declare v_58 int = 12403;
  declare v_59 int = 12404;
  declare v_60 int = 12405;
  declare v_61 int = 12406;
  declare v_62 int = 12407;
  declare v_63 int = 12408;
  declare v_64 int = 12409;
  declare v_65 int = 12410;
  declare v_66 int = 12411;
  declare v_67 int = 12412;
  declare v_68 int = 12413;
  declare v_69 int = 12414;
  declare v_70 int = 12415;
  declare v_71 int = 12416;
  declare v_72 int = 12417;
  declare v_73 int = 12418;
  declare v_74 int = 12419;
  declare v_75 int = 12420;
  declare v_76 int = 12421;
  declare v_77 int = 12422;
  declare v_78 int = 12423;
  declare v_79 int = 12424;
  declare v_80 int = 12425;
  declare v_81 int = 12426;
  declare v_82 int = 12427;
  declare v_83 int = 12428;
  declare v_84 int = 12429;
  declare v_85 int = 12430;
  declare v_86 int = 12431;
  declare v_87 int = 12432;
  declare v_88 int = 12433;
  declare v_89 int = 12434;
  declare v_90 int = 12435;
  declare v_91 int = 12436;
  declare v_92 int = 12437;
  declare v_93 int = 12438;
  declare v_94 int = 12439;
  declare v_95 int = 12440;
  declare v_96 int = 12441;
  declare v_97 int = 12442;
  declare v_98 int = 12443;
  declare v_99 int = 12444;
  declare v_100 int = 12445;
  declare v_101 int = 12446;
  declare v_102 int = 12447;
  declare v_103 int = 12448;
  declare v_104 int = 12449;
  declare v_105 int = 12450;
  declare v_106 int = 12451;
  declare v_107 int = 12452;
  declare v_108 int = 12453;
  declare v_109 int = 12454;
  declare v_110 int = 12455;
  declare v_111 int = 12456;
  declare v_112 int = 12457;
  declare v_113 int = 12458;
  declare v_114 int = 12459;
  declare v_115 int = 12460;
  declare v_116 int = 12461;
  declare v_117 int = 12462;
  declare v_118 int = 12463;
  declare v_119 int = 12464;
  declare v_120 int = 12465;
  declare v_121 int = 12466;
  declare v_122 int = 12467;
  declare v_123 int = 12468;
  declare v_124 int = 12469;
  declare v_125 int = 12470;
  declare v_126 int = 12471;
  declare v_127 int = 12472;
  declare v_128 int = 12473;
  declare v_129 int = 12474;
  declare v_130 int = 12475;
  declare v_131 int = 12476;
  declare v_132 int = 12477;
  declare v_133 int = 12478;
  declare v_134 int = 12479;
  declare v_135 int = 12480;
  declare v_136 int = 12481;
  declare v_137 int = 12482;
  declare v_138 int = 12483;
  declare v_139 int = 12484;
  declare v_140 int = 12485;
  declare v_141 int = 12486;
  declare v_142 int = 12487;
  declare v_143 int = 12488;
  declare v_144 int = 12489;
  declare v_145 int = 12490;
  declare v_146 int = 12491;
  declare v_147 int = 12492;
  declare v_148 int = 12493;
  declare v_149 int = 12494;
  declare v_150 int = 12495;
  declare v_151 int = 12496;
  declare v_152 int = 12497;
  declare v_153 int = 12498;
  declare v_154 int = 12499;
  declare v_155 int = 12500;
  declare v_156 int = 12501;
  declare v_157 int = 12502;
  declare v_158 int = 12503;
  declare v_159 int = 12504;
  declare v_160 int = 12505;
  declare v_161 int = 12506;
  declare v_162 int = 12507;
  declare v_163 int = 12508;
  declare v_164 int = 12509;
  declare v_165 int = 12510;
begin
   exception ex_surprised using(
      v_1
     ,v_2
     ,v_3
     ,v_4
     ,v_5
     ,v_6
     ,v_7
     ,v_8
     ,v_9
     ,v_10
     ,v_11
     ,v_12
     ,v_13
     ,v_14
     ,v_15
     ,v_16
     ,v_17
     ,v_18
     ,v_19
     ,v_20
     ,v_21
     ,v_22
     ,v_23
     ,v_24
     ,v_25
     ,v_26
     ,v_27
     ,v_28
     ,v_29
     ,v_30
     ,v_31
     ,v_32
     ,v_33
     ,v_34
     ,v_35
     ,v_36
     ,v_37
     ,v_38
     ,v_39
     ,v_40
     ,v_41
     ,v_42
     ,v_43
     ,v_44
     ,v_45
     ,v_46
     ,v_47
     ,v_48
     ,v_49
     ,v_50
     ,v_51
     ,v_52
     ,v_53
     ,v_54
     ,v_55
     ,v_56
     ,v_57
     ,v_58
     ,v_59
     ,v_60
     ,v_61
     ,v_62
     ,v_63
     ,v_64
     ,v_65
     ,v_66
     ,v_67
     ,v_68
     ,v_69
     ,v_70
     ,v_71
     ,v_72
     ,v_73
     ,v_74
     ,v_75
     ,v_76
     ,v_77
     ,v_78
     ,v_79
     ,v_80
     ,v_81
     ,v_82
     ,v_83
     ,v_84
     ,v_85
     ,v_86
     ,v_87
     ,v_88
     ,v_89
     ,v_90
     ,v_91
     ,v_92
     ,v_93
     ,v_94
     ,v_95
     ,v_96
     ,v_97
     ,v_98
     ,v_99
     ,v_100
     ,v_101
     ,v_102
     ,v_103
     ,v_104
     ,v_105
     ,v_106
     ,v_107
     ,v_108
     ,v_109
     ,v_110
     ,v_111
     ,v_112
     ,v_113
     ,v_114
     ,v_115
     ,v_116
     ,v_117
     ,v_118
     ,v_119
     ,v_120
     ,v_121
     ,v_122
     ,v_123
     ,v_124
     ,v_125
     ,v_126
     ,v_127
     ,v_128
     ,v_129
     ,v_130
     ,v_131
     ,v_132
     ,v_133
     ,v_134
     ,v_135
     ,v_136
     ,v_137
     ,v_138
     ,v_139
     ,v_140
     ,v_141
     ,v_142
     ,v_143
     ,v_144
     ,v_145
     ,v_146
     ,v_147
     ,v_148
     ,v_149
     ,v_150
     ,v_151
     ,v_152
     ,v_153
     ,v_154
     ,v_155
     ,v_156
     ,v_157
     ,v_158
     ,v_159
     ,v_160
     ,v_161
     ,v_162
     ,v_163
     ,v_164
     ,v_165
  );
end
^
set term ;^
