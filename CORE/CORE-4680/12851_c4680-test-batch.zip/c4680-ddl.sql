    set term ^;
/*
    create or alter trigger trg_conn active on connect position 0 as
    begin
        post_event 'foo';
    end
    ^
*/
    create or alter trigger trg_disc active on disconnect position 0 as
    begin
        post_event 'bar';
    end 
    ^
create or alter procedure sys_get_fb_arch (
     a_connect_with_usr varchar(31) default 'SYSDBA'
    ,a_connect_with_pwd varchar(31) default 'masterkey'
) returns(
    fb_arch varchar(50)
) as
    declare cur_server_pid int;
    declare ext_server_pid int;
    declare att_protocol varchar(255);
    declare v_test_sttm varchar(255);
    declare v_fetches_beg bigint;
    declare v_fetches_end bigint;
begin
    
    -- Aux SP for detect FB architecture.

    select a.mon$server_pid, a.mon$remote_protocol
    from mon$attachments a
    where a.mon$attachment_id = current_connection
    into cur_server_pid, att_protocol;

    if ( att_protocol is null ) then
        fb_arch = 'Embedded';
    else if ( upper(current_user) = upper('SYSDBA')
              and rdb$get_context('SYSTEM','ENGINE_VERSION') NOT starting with '2.5' 
              and exists(select * from mon$attachments a 
                         where a.mon$remote_protocol is null
                               and upper(a.mon$user) in ( upper('Cache Writer'), upper('Garbage Collector'))
                        ) 
            ) then
        fb_arch = 'SuperServer';
    else
        begin
            v_test_sttm =
                'select a.mon$server_pid + 0*(select 1 from rdb$database)'
                ||' from mon$attachments a '
                ||' where a.mon$attachment_id = current_connection';

            select i.mon$page_fetches
            from mon$io_stats i
            where i.mon$stat_group = 0  -- db_level
            into v_fetches_beg;
        
            execute statement v_test_sttm
            on external
                 'localhost:' || rdb$get_context('SYSTEM', 'DB_NAME')
            as
                 user a_connect_with_usr
                 password a_connect_with_pwd
                 role left('R' || replace(uuid_to_char(gen_uuid()),'-',''),31)
            into ext_server_pid;
        
            in autonomous transaction do
            select i.mon$page_fetches
            from mon$io_stats i
            where i.mon$stat_group = 0  -- db_level
            into v_fetches_end;
        
            fb_arch = iif( cur_server_pid is distinct from ext_server_pid, 
                           'Classic', 
                           iif( v_fetches_beg is not distinct from v_fetches_end, 
                                'SuperClassic', 
                                'SuperServer'
                              ) 
                         );
        end

    fb_arch = fb_arch || ' ' || rdb$get_context('SYSTEM','ENGINE_VERSION');

    suspend;

end 

^ -- sys_get_fb_arch

    set term ;^
    commit;

    show trigger trg_disc;

