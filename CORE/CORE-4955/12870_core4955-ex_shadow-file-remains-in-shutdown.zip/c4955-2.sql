set list on;

set term ^;
execute block returns(msg varchar(255)) as
    declare curr_g int;
begin
    msg='Attach_2. Check state of Attach_1: ';
    curr_g=gen_id(g,0);
    if ( curr_g > 0 and curr_g < 99000 ) then 
        msg = msg || 'OK. It works, gen_id='||curr_g;
    else
        msg = msg || 'BAD. Either not started or already finished, gen_id='||curr_g;
    suspend;
end
^
set term ;^
commit;

create shadow 1 'C:\MIX\firebird\QA\fbt-repo\tmp\c4955.shd';

select 'Attach-2. RDB$FILES before dropping shadow' as msg, v.*  from v_shadow_info v;
commit;

set echo on;
drop shadow 1 preserve file;
commit;
connect '/3333:C:\MIX\firebird\QA\fbt-repo\tmp\c4955.fdb' user 'SYSDBA' password 'masterke';
set echo off;

select 'Attach_2. RDB$FILES after dropping shadow' as msg, v.*  from v_shadow_info v;
commit;
