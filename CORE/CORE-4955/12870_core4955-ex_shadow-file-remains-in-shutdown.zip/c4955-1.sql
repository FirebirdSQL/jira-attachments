shell del C:\MIX\firebird\QA\fbt-repo\tmp\c4955.fdb 2>nul;
shell del C:\MIX\firebird\QA\fbt-repo\tmp\c4955.shd 2>nul;

create database '/3333:C:\MIX\firebird\QA\fbt-repo\tmp\c4955.fdb' user 'SYSDBA' password 'masterkey';

show version;
show database;

recreate sequence g;
recreate table test(id int, s varchar(100) unique using index test_s_unq);
commit; 
create or alter view v_shadow_info as
select 
    p.rdb$file_name as file_name
   ,p.rdb$file_sequence as file_seq
   ,p.rdb$file_start as file_start
   ,p.rdb$file_length as file_length
   ,p.rdb$file_flags as file_flags
   ,p.rdb$shadow_number as shd_number
from rdb$database r 
left join rdb$files p on 1=1;
commit;

set bail on;
set list on;
select 'Attach_1. Starting "heavy DML"...' as msg from rdb$database;
commit;
set transaction read committed;
set term ^;
execute block as
  declare n int = 100000;
  declare k int = 1000;
  declare i int;
begin
    while ( 1=1 ) do
    begin
        i = 0;
        in autonomous transaction do
           while (i < k and n > 0) do
           begin
               insert into test(id, s) values( gen_id(g,1), rpad('', 100, uuid_to_char(gen_uuid())) );
               i = i + 1;
               n = n - 1;
           end
    end
end
^
set term ;^
select 'Attach_1. Finished "heavy DML".' as msg from rdb$database;
commit;

