set term ^;
execute block as
   declare n int;
begin
     select 1 from mon$io_stats where mon$stat_group = 0 into n;
end
^
set term ;^
