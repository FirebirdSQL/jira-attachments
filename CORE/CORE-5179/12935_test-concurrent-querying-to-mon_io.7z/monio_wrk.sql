set list on;
select current_connection, rdb$get_context('SYSTEM','ENGINE_VERSION') as engine from rdb$database;
set term ^;
--execute block returns(att bigint, sid bigint, pr bigint, pw bigint, pf bigint, pm bigint)
execute block 
as
   declare n int;
begin
    select 1 from mon$io_stats where mon$stat_group = 0 into n;
    /*
    select
         current_connection
        ,mon$stat_id
        ,mon$page_reads
        ,mon$page_writes
        ,mon$page_fetches
        ,mon$page_marks
    from mon$io_stats 
    where mon$stat_group = 0 
    into att, sid, pr, pw, pf, pm;
    suspend;
    */
end
^
set term ;^
