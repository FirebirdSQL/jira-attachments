-- 2015/08/06-14:32
--drop procedure loan_payment;
--drop procedure loan_balance;
--alter table loan drop constraint pk_loan;
--alter table loan drop constraint fk_loan_cr;
--alter table loan drop constraint fk_loan_db;

recreate table loan(
 id        smallint not null,
 frequency smallint not null,
 duration  smallint not null,
 cred_ac   smallint not null,
 deb_ac    smallint not null,
 amount D_MONEY,
 balance  D_MONEY,
 rate decimal(5,3) not null,
 payment D_MONEY,
 interest D_MONEY,
 nextdue  date not null,
 description varchar(40),
 constraint pk_loan primary key  (id),
 constraint fk_loan_cr foreign key(cred_ac) references account(ac),
 constraint fk_loan_db foreign key(deb_ac)  references account(ac)
);

commit;

set term ^;
recreate procedure loan_payment (id smallint)
  as
 declare frequency smallint;
 declare amount D_MONEY;
 declare balance  D_MONEY;
 declare rate decimal(5,3);
 declare payment D_MONEY;
 declare nextdue  date;
 declare newdue  date;
 declare description varchar(40);
 declare interest D_MONEY;
 declare yr smallint;
 declare nr smallint;
 declare cr smallint;
 declare dr smallint;
begin
  balance = 0;
  select frequency,amount,balance,rate,payment,nextdue,trim(description),cred_ac,deb_ac
    from loan
    where id = :id
      and nextdue <= cast('today' as date)
    into :frequency,:amount,:balance,:rate,:payment,:nextdue,:description,:cr,:dr;

  if (balance <=0) then exit;

  yr  = extract(year from :nextdue);
  nr  = extract(month from :nextdue);
  interest = (balance * rate  * frequency) / 12;

  if (payment > (balance + interest))
    then payment = balance + interest;
  balance = balance - payment + interest;
-- transfer from bank to loan accout
  execute procedure inter_account_transfer(:dr,:cr,:nextdue,:payment);

  insert into mvt(ac,tdate,amount,type,refyr, refnr,Category,desc)
    values (:cr,:nextdue,(0 - :interest),'M',:yr,:nr,65005,'Interest:' || :description);

  nextdue = dateadd( :frequency month to :nextdue);

  update loan set balance = :balance, nextdue = :nextdue, interest = interest + :interest
   where id = :id;
end^

recreate procedure loan_balance(id smallint)
  as
 declare frequency smallint;
 declare balance  D_MONEY;
 declare interest D_MONEY;
 declare nextdue  date;
 declare lid smallint;
begin
  select id,frequency from loan 
    where cred_ac = :id
    into :lid,:frequency;

  select sum(amount), max(tdate) from mvt 
    where ac=:id
    into :balance,:nextdue;

  select sum(amount) from mvt 
    where ac=:id
     and Category= 65005 --loan interest
    into :interest;

  nextdue = dateadd( :frequency month to :nextdue);

  update loan set balance = 0 -:balance, nextdue = :nextdue, interest = 0 - :interest
   where id= :lid;

end^

set term ;^
commit;

insert into loan 
  values(1,1,36,22,13,15000,15000, 0.054, 450.42,0, '2011-01-07', 'Kuga car loan');

-- calc current state of loan
execute procedure loan_balance(22);
execute procedure loan_payment (1);
-- check results
select id,balance,interest,nextdue from loan;
select ac,Category,tdate,amount from mvt where ac = 22;
commit;
