-- 2015/08/06-14:32

set term ^;
-- must maintain account balance
recreate trigger tai_mvt
 active after insert or update position 1
 on mvt
 as
 begin
  update account a set a.balance = a.balance + new.amount
   where a.id = new.ac;
 end^

recreate trigger tbd_mvt
 before delete  or update position 1
 on mvt
 as
 begin
  update account a set a.balance = a.balance - old.amount
   where a.id = old.ac;
 end^
set term ;^
commit;

set term ^;
recreate trigger tbi_mvt_dt
 active before insert or update position 2
 on mvt
 as
 begin
   if (new.tdate is null) then
     new.tdate = 'today';
   new.yr = extract(year from new.tdate);
   new.qtr = (extract(month from new.tdate) +2)/3;
 end^
set term ;^

-- cash flow per yr
recreate view cash_flow as
select curr, ac,yr,sum(amount) total
  from mvt 
  group by curr,ac,yr;

commit;




set term ^;

-- update amount realised for recent disposals
recreate procedure update_realised(yr smallint)
as
 declare variable realised d_money;
 declare variable dispasset smallint;
begin
  for select cast(rate * qty as d_money), asset from disposal d
        inner join item i
          on d.sale = i.id
    where extract(year from tdate) = :yr
      and d.sale is not null
    into  :realised,:dispasset
   do
   begin
     update assets set realised = :realised, residual =0
       where id = :dispasset;
   end
end^

recreate procedure depreciate(yr smallint)
as
 declare variable id smallint;
 declare variable curr d_curr;
 declare variable amount d_money;
 declare variable resid d_money;
 declare variable tgt integer;
 declare variable dyr smallint;

begin
-- check for any recent disposals involving sales
  execute procedure update_realised(:yr);

-- now do the depreciation for assets which have not been sold
  for select a.id,a.curr,a.cost / s.life,residual,target
   from assets a
   inner join schedule s
    on a.Category = s.category
   where a.residual>0
    and a.yr <= :yr
    and a.realised = 0
   into :id,:curr,:amount,:resid,:tgt
   do begin
     if (amount > resid) then
       begin
         amount = resid;
       end
     resid = resid - amount;
     if (:resid < 1) then
       begin
       amount = amount + resid;
       resid = 0;
       end
     update assets set residual = :resid where id = :id;
     insert into depreciation values(:id,:yr,:amount,:curr,:tgt);
     end
end^

recreate procedure dep_all_years(f smallint, l smallint)
as
declare variable yr smallint;
declare variable cyr smallint;
begin
  yr = f;
  while ( yr <= l)
  do begin
     execute procedure depreciate(:yr);
     yr = yr +1;
     end
end^

recreate procedure inter_account_transfer(fr_acct d_id,to_acct d_id,twhen date,fr_amount d_money)
as
 declare variable xr d_xrate;
 declare variable to_amount d_money;
 declare variable to_curr d_curr;
 declare variable fr_curr d_curr;
 declare variable fr_Category integer;
 declare variable to_Category integer;
 declare variable fr_desc D_DESC;
 declare variable to_desc D_DESC;
 declare variable refyr smallint;
 declare variable refnr smallint;
 declare variable id d_id;
begin
-- calc refnr
 refyr = extract(year from :twhen);
 refnr = extract(month from :twhen);
-- check for currency conversion
  select curr,Category,trim(num) from account where id = :fr_acct into :fr_curr,:fr_category,:fr_desc;
  select curr,Category,trim(num) from account where id = :to_acct into :to_curr,:to_category,:to_desc;
  if ( fr_curr = to_curr ) then 
    xr = 1;
  else
    select rate from xrate
      where source = :fr_curr
       and  target = :to_curr
       and todate >= :twhen
       and fromdate <= :twhen
    union
    select (1.0 / rate) as inverse from xrate
      where source = :to_curr
       and  target = :fr_curr
       and todate >= :twhen
       and fromdate <= :twhen
      into :xr;
-- calc converted amount
  to_amount = xr * fr_amount;
  insert into mvt(ac,tdate,amount,curr,Category,desc,type,refyr,refnr)
     values (:to_acct,:twhen,:to_amount,:to_curr,:fr_Category,'from: ' || :fr_desc,'M',
             :refyr,:refnr);
  insert into mvt(ac,tdate,amount,curr,Category,desc,type,refyr,refnr)
     values (:fr_acct,:twhen,0 - :fr_amount,:fr_curr,:to_Category,'to: ' || :to_desc,'M',
             :refyr,:refnr);
end^
set term ;^

recreate view disposal_details as
 select a.Category category ,d.tdate tdate, d.asset asset,a.curr curr,a.cost cost, a.residual residual,
        a.realised, i.curr currx,d.sale sale, e.desc desc
 from disposal d
 inner join expitem e
  on d.asset = e.id
 inner join assets a
  on d.asset = a.id
 inner join item it
  on d.sale = it.id
 inner join invoice i
  on it.inv = i.id
 where d.sale is not null;

set term ^;
-- must maintain net amount for invoices
recreate trigger tai_item
 active after insert or update position 2
 on item
 as
 begin
  update invoice set net = net + new.qty * new.rate
   where id = new.inv;
 end^

recreate trigger tbd_item
 active before delete or update position 2
 on item
 as
 begin
  update invoice set net = net - old.qty * old.rate
   where id = old.inv;
 end^

recreate trigger tbi_inv
 active before insert or update position 3
 on invoice
 as   
 begin
   if (new.type = 'I') then
     new.vat = new.net * new.vrate / 100.0;
 end^

recreate trigger tbi_inv_dt
 active before insert or update position 2
 on invoice
 as
 begin
   if (new.sent is null) then
     new.sent = 'today';
   new.yr = extract(year from new.sent);
   new.qtr = (extract(month from new.sent) + 2) / 3;
 end^

-- must record when a doc has been paid
recreate trigger tai_mvt_paid
 active after insert or update position 2
 on mvt
 as
 begin
  if (new.ref is not null) then
    if (new.type in ('E','I','C','D'))  then
      update invoice set paid = new.tdate where id = new.ref;
 end^

recreate trigger tai_exp_asset
 active after insert  position 3
 on expitem
 as
 begin
  if ( (new.Category / 1000 ) in (23,24) ) then
   insert into assets(id,Category,curr,cost) 
    values(new.id,new.Category,new.curr,new.amount);
 end^

recreate trigger tbd_mvt_paid
 active before delete or update position 2
 on mvt
 as
 begin
  if (old.ref is not null) then
    if (old.type in ('I','C','D'))  then
      update invoice set paid = null where id = old.ref;
 end^

set term ;^

commit;
-- invoices per qtr
recreate view invoices_per_qtr as
 select yr, qtr, doc.id,curr, net,vat,org.name
   from invoice doc
   inner join org
     on org.id = doc.orgid
   order by yr,qtr,curr,id;

-- expenses per qtr
recreate view expenses_per_qtr as
 select yr, qtr, doc.id,curr, net,vat,org.name
   from expense doc
   inner join org
     on org.id = doc.orgid
   order by yr,qtr,curr,id;

-- vat in
recreate view vat_in as
 select yr, qtr, e.curr, e.Category, sum(e.amount) amount, x.desc
   from expense d
   inner join expitem e
     on e.doc_id = d.id
   inner join explain x
     on e.Category = x.id
   group by yr,qtr,e.curr,e.Category,x.desc;

--- vat out
recreate view vat_out as
 select yr,  qtr, curr, sum(net) net,sum(vat) vat,vrate
   from invoice
   group by yr,qtr,curr,vrate;
commit;

--current assets
recreate view current_assets as
  select a.category,a.id,a.yr,a.cost, a.residual, e.desc from assets a 
   inner join expitem e 
     on a.id=e.id
   where a.id not in (select asset from disposal);

--old_assets
recreate view old_assets as
  select a.category,a.curr,a.yr,a.id,a.cost, a.residual,a.realised, e.desc from assets a
   inner join expitem e  
     on a.id=e.id
   where a.id in (select asset from disposal);

