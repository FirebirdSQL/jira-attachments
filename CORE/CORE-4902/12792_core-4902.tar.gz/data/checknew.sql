-- queries to be run after database restructure
-- 
select id,curr,balance from account;
select curr,ac,count(*) cnt,sum(amount) amount from mvt group by curr,ac;

select curr, yr,count(*) cnt,sum(net) net, sum(vat) vat 
  from invoice   --invoice/credit note/debit note
  group by curr,yr;
-- expenses
select curr, yr,count(*) cnt,sum(net) net, sum(vat) vat 
  from expense
  group by curr,yr;


-- report disposals
select count (asset) from disposal where sale is not null;
select i.desc from item i
 inner join disposal d
   on i.id = d.sale 
 where d.sale is not null;

-- check whether disposals converted correctly
select tdate,why from disposal where reason is null;
select id, net,vat,curr,tdate,orgid from expense
  where id in(select asset from disposal where reason is null);
select id,Category,amount,desc from expitem
  where id in (select asset from disposal where reason is null);

