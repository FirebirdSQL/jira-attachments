
output migrate-log1;
input ddl.sql;
input alter0.sql;
input dml.sql;
set echo on;
-- initial import complete
output money-log;
--input vfy.sql;
output migrate-log2;
input checkold.sql;
input alter1.sql;
input alter2.sql;
input alter3.sql;
input alter4.sql;
input alter5.sql;
--input fixbal.sql;
input checknew.sql;
-- verification complete
output migrate-log3;
-- handle assets and depreciation
--input alter6.sql;
input alter7.sql;
input alter9.sql;
-- doc handling
input blddoc.sql;
-- simplify creation of eec invoices
input eecdoc.sql;
--input loan.sql;
output;
-- migration complete
set echo off;
