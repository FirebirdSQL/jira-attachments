-- 2015/08/06-14:32
input company.dml;
input currency.dml;
input country.dml;
input exempt.dml;
input explain.dml;
input customer.dml;
input invoice.dml;
input item.dml;
input supplier.dml;
input expense.dml;
input expitem.dml;
input disposal.dml;
input account.dml;
input mvt.dml;
input cash.dml;
commit;
