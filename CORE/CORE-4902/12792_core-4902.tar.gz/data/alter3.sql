-- 2015/08/06-14:32
-- find all historic rates used

insert into xrate(target,rate,fromDate,todate)
  select CURR,xrate,min(SENT),max(SENT) from invoice 
    where CURR <> 'EUR'
    group by CURR,xrate;

insert into xrate(target,rate,fromDate) 
 select c.id, EXCHANGERATE , 
   coalesce((select max(todate)+1 from xrate x where x.TARGET =c.id), '2000-01-01') from currency c;
commit;  




-- link items to invoice

update item a set a.inv = (select b.id from invoice b
  where a.yr = b.yr
    and a.nr = b.nr);
commit;

--create index ix_inv_qtr on invoice(yr,qtr);
create index ix_org_cust on org(oldcust);
create index ix_org_supp on org(oldsupp);
commit;
update invoice set qtr=(extract(month from sent)+2)/3;
update expense set qtr=(extract(month from tdate)+2)/3;
commit;


-- combine customers & suppliers into organisations
-- use common document Category for invoice/expense/money

-- fix customer postcodes
update customer set postid=substring(postid from 4) 
 where postid like  'BE-%';
update customer set postid=substring(postid from 4) 
 where postid like  'CH-%';
update customer set postid=substring(postid from 4) 
 where postid like  'NL-%';
update customer set postid=substring(postid from 3) 
 where postid like  'D-%';
update customer set postid=substring(postid from 3) 
 where postid like  'L-%';

-- populate org with customer and supplier
insert into org (oldcust,name,contact,dept,vatnr,country,city,street,postcode,phone,fax,email) 
 select id,Cname,Contact,Floor,VatNr,VatCountry,City,Street,PostId,phone,fax,email
  from customer;

-- there are several which are common to customer/supplier
update org o set o.oldsupp = (select s.id from supplier s where o.name=s.sname);
-- report duplicate names
select name from org where oldsupp is not null and oldcust  is not null;

--- fix post codes for suppliers
update supplier set postid=substring(city from 1 for 4),city=substring(city from 6) 
 where substring(city from 5 for 1) = ' ';
update supplier set postid=substring(city from 3 for 4),city=substring(city from 7) 
 where city like 'B-%';
update supplier set postid=substring(city from 3 for 4),city=substring(city from 7) 
 where city like 'L-%';


insert into org (oldsupp,name,vatnr,country,street,city,postcode)
 select id,sname,VatNr,Country,Street,City,PostId from supplier
  where sname not in (select name from org);
-- org = company + customer + supplier - 4
select count(*) cnt from org;
commit;

-- link invoice to org

update invoice i set i.orgid =
  (select o.id from org o where i.cust = o.oldcust);
--select count(*) from invoice where orgid is null;
commit;

-- link expense to org

update expense e set e.orgid =
  (select o.id from org o where e.sup = o.oldsupp);
--select count(*) from expense where orgid is null;
commit;

update disposal d set d.sale = 
  (select i.id from item i where d.invyr = i.yr and d.invnr =i.nr and d.invline = i.line)
  where d.invyr is not null;
update disposal d set d.tdate =
  (select tdate from invoice doc
    inner join item
      on doc.id = item.inv
    where item.id = d.sale) 
    where d.sale is not null;
commit;


-- add currency to mvt
update mvt m set m.curr =(select a.curr from account a where a.id = m.ac);
-- link mvt to referenced expense
update mvt a set ref =( select b.ID from expense b where a.refyr = b.yr and a.refnr = b.nr )
 where a.type = 'E';

-- merge cash => mvt
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_eur;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_bef;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_dem;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_fim;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_frf;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_gbp;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_grd;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_nlg;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_pte;
insert into mvt(ac,curr,tdate,Category,amount,desc,type) select * from pc_usd;

--link mvt to referenced invoice
update mvt a set ref =( select b.ID from invoice b where a.refyr = b.yr and a.refnr = b.nr ) 
 where a.type = 'I';

-- set yr, qtr in mvt
update mvt set yr = extract(year from tdate),
 qtr = (extract(month from tdate) +2)/3;
commit;
create index ix_mvt_qtr on mvt(yr,qtr,type);
commit;

-- money
-- avoid null amounts
update account a set a.balance
 = (select coalesce(sum(m.amount),0) from mvt m where a.id = m.ac);

-- expand company data
update company set bic='CTBKBEBX', iban='BE06 9530 5359 7822';

--  delete from mvt where yr < 2002;
--  delete from account where id not in
--   (select distinct ac from mvt);
commit;
