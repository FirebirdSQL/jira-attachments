-- 2015/08/06-14:32
-- convert old BEF balances to EUR
execute procedure inter_account_transfer(8,12,'2001-12-31',69890);  -- loan
execute procedure inter_account_transfer(2,11,'2001-12-31',-24806); -- cash
execute procedure inter_account_transfer(3,9,'2001-12-31',-54983);  -- amex
execute procedure inter_account_transfer(5,10,'2001-12-31',1401);   -- visa
-- transfer balances from amex/visa/loan => cash
execute procedure inter_account_transfer(9,11,'2010-08-01',-5427.71);  -- amex -> cash
execute procedure inter_account_transfer(10,11,'2010-08-01',-1741.29); -- visa -> cash
execute procedure inter_account_transfer(12,11,'2010-08-01',1732.57);  -- loan -> cash

-- transfers to loan account use different Category for EUR
update mvt set Category=57019 where category = 57005 and tdate >= '2002-01-01';

commit;
--  delete old data

alter trigger TBD_MVT inactive;
commit;
delete from mvt where extract(year from tdate) <2002;
delete from journal where extract(year from tdate) <2002;
delete from account where id not in (select distinct ac from mvt);
commit;
alter trigger TBD_MVT active;
commit;



