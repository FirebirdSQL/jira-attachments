-- 2015/08/06-14:32
-- procedures & triggers to maintain total of line amounts in docs

/*
drop procedure add_inv_line;
drop procedure add_exp_line;
drop procedure bldinv;
drop procedure bldexp;
drop procedure blddoc;
*/

set term ^;
-- triggers to maintain totals on expense documents
recreate trigger tai_expitem
 active after insert or update position 2
 on expitem
 as
 begin
  if (new.Category in (41110,64012,45130) ) then --vat
    update expense set vat = vat + new.amount where id = new.doc_id;
  else
    update expense set net = net + new.amount where id = new.doc_id;
 end^

recreate trigger tbd_expitem
 active before delete or update position 2
 on expitem
 as
 begin
  if (new.Category in (41110,64012,45130) ) then --vat
    update expense set vat = vat - old.amount where id = old.doc_id;
  else
    update expense set vat = vat + new.amount where id = old.doc_id;
 end^

-- invoices
recreate procedure bldinv(curr D_curr, rate d_percent,org smallint)
  returns (id smallint)
as
begin
   insert into invoice(type,sent,net,vat,orgid,curr,vrate)
        values('I','today',0,0,:org,:curr,:rate)
        returning id into :id;

-- execute procedure blddoc('I','today',0,0,curr,rate,org) returning_values id;
end^    

recreate procedure add_inv_line(inv smallint,qty d_qty,what char(5),rate d_money,desc char(40) )
as
begin
  insert into item(inv,qty,rate,units,desc) values (:inv,:qty,:rate,:what,:desc);
end^

-- expenses
recreate procedure bldexp(curr D_curr,org smallint)
  returns (id smallint)
as
begin
    insert into expense(tdate,net,vat,orgid,curr)
        values('today',0,0,:org,:curr) 
        returning id into :id;

-- execute procedure blddoc('E','today',0,0,curr,0,org) returning_values id;
end^    

recreate procedure add_exp_line(exp smallint,Category integer,amount d_money,curr d_curr,desc char(40) )
as
begin
  insert into expitem(doc_id,Category,amount,curr,desc) values (:exp,:category,:amount,:curr,:desc);
end^

----------------------------------------------
recreate procedure add_cash_mvt ( amount d_money,curr d_curr,Category integer,desc char(40))
as
 declare ac smallint;
begin
 ac = case curr
  when 'EUR' then 11
  when 'GBP' then 18
  end;
-- select id from account where curr=:curr and locked = 'F' and Category <> 55002 into ac;
 insert into mvt(ac,tdate,curr,amount,type,Category,desc) 
    values (:ac,'today',:curr,:amount,'M',:Category,:desc);
end^
----------------------------------------------
recreate procedure add_bank_mvt
   (tdate date,
    amount d_money,
    Category integer,
    type char(1),
    ref smallint,
    what D_DESC)
  returns ( desc D_DESC )
as
 declare ac smallint =13;
 declare cls integer;
begin
  desc = null;
  cls = case type
     when 'E' then 44000
     when 'I' then 40000
     else Category
    end;

  if (what = '') then
    select desc from explain where id=:cls into :desc;
  else desc = what;
 
 if (desc is null) then begin
   desc='unknown Category:' || cast(:cls as char(5));
   exit;
  end

  if (type in ('E')) then begin
    desc = null;
    select name from org 
      inner join expense
        on org.id = orgid
      where expense.id = :ref
      into :desc;
    end

  if (type in ('I')) then begin
    desc = null;
    select name from org 
      inner join invoice
        on org.id = orgid
      where invoice.id = :ref
      into :desc;
    end

  if (desc is null) then begin
   desc='unknown reference:' || cast(:ref as char(5));
   exit;
  end
 
 insert into mvt(ac,tdate,amount,type,ref,Category,desc) 
    values (:ac,:tdate,:amount,:type,:ref,:cls,:desc);
end^

set term ;^
