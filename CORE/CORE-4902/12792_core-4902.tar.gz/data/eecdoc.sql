-- 2015/08/06-14:32
-- simplify creation of EU invoices for translation order forms
set term ^;
recreate procedure bld_eu_inv (off char(1),subject char(1),pg d_qty, rate d_money,yr smallint,ref smallint)
as
 declare inv smallint;
 declare org smallint;
 declare contract char(20);
 declare txt char(40);
begin
 if (off = 'B') then org = 22; -- bxl
 else org = 34; -- lu

 contract = case subject
    when 'L' then '18270/LEG08-EN'
    when 'E' then '18270/ECONxxxx'
    when 'A' then  '18270/TECH2-20EN'
    when 'T' then  '18270/TECH2-20EN'
   end;
 txt = 'Translation ' || trim(contract) || ' ' || cast(yr as char(4)) || '/' || cast(ref as char(5));
 execute procedure bldinv('EUR',0,org) returning_values inv;
 execute procedure add_inv_line(inv,pg,'pages',rate,txt);
end^

set term ;^
commit;
