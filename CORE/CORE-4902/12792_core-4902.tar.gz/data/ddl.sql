-- 2015/08/06-14:32
CREATE DATABASE 'accounts' user 'treeve' default character set utf8;
-- domains
/*      Global Field Definitions        */

create domain D_ADDR     varchar (40);
create domain D_BANK_ACT varchar (14);

create domain D_BOOL char default 'F' not null
  check (value in ('T','F'));

create domain D_CTY  char (2) not null;
create domain D_CURR char (3) default 'EUR' not null;
create domain D_ID smallint default 0 not null;

create domain D_DOC_TYP char (1)
  check (value in ('E','I','S','D','C','X','M','P','U','V','T') );
-- C credit note
-- D debit note
-- E expense
-- I invoice
-- M miscellaneous
-- P pension
-- S statement
-- T tax
-- U undefined
-- V vat
-- X disposal

create domain D_LANG char (2)
  check(value in ('EN','FR','NL','DE'));

create domain D_MONEY decimal(10,2) default 0 not null;
create domain D_NAME varchar (40) not null;
create domain D_PERCENT decimal(4,2) not null;
create domain D_POST_CODE varchar (10);
create domain D_QTY  decimal(7,2) not null;

create domain d_reason char(1)
   check (value in('B','O','R','S','X'));
-- 'B' - broken
-- 'O' - obsolete
-- 'R' - redundant
-- 'S' - sold
-- 'X' - stolen

create domain D_TEL varchar (17);
create domain D_VATNR varchar (15);
create domain D_XRATE decimal(10,5);

create domain D_AC smallint not null;
create domain D_DESC varchar(40);
input company.ddl;
input currency.ddl;
input country.ddl;
input exempt.ddl;
input explain.ddl;
input customer.ddl;
input invoice.ddl;
input item.ddl;
input supplier.ddl;
input expense.ddl;
input expitem.ddl;
input disposal.ddl;
input account.ddl;
input mvt.ddl;
input cash.ddl;
commit;
show database;
show tables;
