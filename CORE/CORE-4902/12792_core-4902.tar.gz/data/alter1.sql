-- 2015/08/06-14:32

alter table company
  add bic char(8),
  add iban char(19);


-- link invoice to org
alter table invoice
  add orgid smallint,
  add qtr smallint,
  alter percentvat to vrate,
  alter exchangerate to xrate,
  alter datesent to sent,
  alter datepaid  to paid,
  drop note,
  drop originator,
  drop ref,
  drop payto;

-- link items to invoice
alter table item 
  alter DESCRIPTION to desc,
  alter desc type D_DESC,
  alter qty set default 0,
  alter units set default 'pages',
  add inv smallint;

-- link expense to org
alter table expense
  add orgid smallint,
  add qtr smallint;
;

alter table expitem
 add curr d_curr,
 add doc_id d_id,
 alter Category set default 41110, -- deductible vat
  add constraint fk_expi_Category foreign key(category) references explain(id);

-- link disposal to invoice and purchase doc
alter table disposal
  add asset d_id,
  add sale smallint,
  add reason d_reason;


-- handle money
alter table account
  add balance d_money default 0 not null;
alter table mvt
  drop constraint U_MVT, 
  drop line,
  alter desc type D_DESC,
  add curr d_curr not null,
  add ref smallint;
-- try to create salary/vat docs from mvt
recreate view salary as select Category,curr,0-amount amount,tdate,refyr yr,refnr nr from mvt 
   where type ='S';
recreate view vat as select Category,curr,0-amount amount,tdate,refyr yr,refnr nr from mvt where type ='V';

-- misc movements
recreate view misc as select Category,curr,amount,tdate,refyr yr,refnr nr from mvt where type ='M';

-- pension ( years 2002-2006 in mvt, others in expitem)

-- what about petty cash?
recreate view pc_eur as select 11 ac,curr,tdate,Category,amount,desc,'M' type
  from cash where curr = 'EUR';
recreate view pc_bef as select 2 ac,curr,tdate,Category,amount,desc,'M' type
 from cash where curr = 'BEF';
recreate view pc_dem as select 15 ac,curr,tdate,Category,amount,desc,'M' type 
 from cash where curr = 'DEM';
recreate view pc_fim as select 14 ac,curr,tdate,Category,amount,desc,'M' type 
 from cash where curr = 'FIM';
recreate view pc_frf as select 16 ac,curr,tdate,Category,amount,desc,'M' type 
 from cash where curr = 'FRF';
recreate view pc_gbp as select 18 ac,curr,tdate,Category,amount,desc,'M' type 
 from cash where curr = 'GBP';
recreate view pc_grd as select 17 ac,curr,tdate,Category,amount,desc,'M' type 
 from cash where curr = 'GRD';
recreate view pc_nlg as select 20 ac,curr,tdate,Category,amount,desc,'M' type 
 from cash where curr = 'NLG';
recreate view pc_pte as select 21 ac,curr,tdate,Category,amount,desc,'M' type 
 from cash where curr = 'PTE';
recreate view pc_usd as select 19 ac,curr,tdate,Category,amount,desc,'M' type 
 from cash where curr = 'USD';

recreate view unpaid as
  select sent,type,doc.yr,doc.nr,doc.id,curr,net,vat, org.name from invoice doc
    inner join org
      on org.id = doc.orgid
    where paid is null order by sent,type;

commit;
