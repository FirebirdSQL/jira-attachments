-- 2015/08/06-14:32
--delete from expitem where expyr <2002;
--delete from expense where yr <2002;
--commit;


alter table mvt
  add yr smallint,
  add qtr smallint;
commit;
create index ix_mvt_ac_date on mvt(ac,type,tdate);
create index ix_mvt_ref on mvt(type,ref);
commit;


-- define table for assets and depreciation
recreate table assets(
id smallint not null,
yr smallint not null,
cost d_money not null,
curr d_curr not null,
residual d_money not null,
Category integer not null,
realised d_money default 0,
constraint pk_asset primary key(id)
);

recreate table depreciation(
id smallint not null,
yr smallint not null,
amount d_money not null,
curr d_curr not null,
target integer not null,
constraint pk_dep primary key(id,yr)
);

-- depreciation schedule
recreate table schedule(  
Category integer not null,
life smallint default 5 not null,
target integer not null,
constraint pk_sched primary key(Category),
constraint u_life check(life >0 and life <=10)
);
commit;
-- create depreciation rates
insert into schedule values(23200,5,63010);
insert into schedule values(23210,3,63020);
insert into schedule values(23211,3,63020);
insert into schedule values(23212,2,63020);
insert into schedule values(24000,10,63030);
insert into schedule values(24001,10,63030);
insert into schedule values(24100,5,63040);
insert into schedule values(24101,3,63040);

-- link expitem to expense
update expitem a
 set a.DOC_ID =
( select b.ID from expense b where a.expyr = b.yr and a.expnr = b.nr );
commit;

update expitem a
 set a.curr = (select e.curr from expense e where a.DOC_ID = e.ID);
commit;

-- create asset entries
insert into assets
 select id, expyr,amount,curr,amount,Category,0
  from expitem
  where Category between 23000 and 24999;

commit;

-- disposals
update disposal a set a.asset = 
  ( select b.ID from expitem b where a.yr = b.expyr and a.nr = b.expnr and a.line =b.line); 
-- remove very old assets
delete from assets
 where id in (select asset from disposal where (extract(year from tdate) < 2002));
-- fix bad  disposals
delete from disposal
  where asset not in (select id from assets);

update disposal set  reason = 'S', why='' where sale is not null;
update disposal set  reason = 'B', why='' where why like 'broken%';
update disposal set  reason = 'B', why='' where why like 'damaged%';
update disposal set  reason = 'O', why='' where why like 'obs%';
update disposal set  reason = 'O', why='' where why like 'left behind%';
update disposal set  reason = 'R', why='' where why like 'redundant%';
update disposal set  reason = 'R', why='' where why like 'irrelevant%';
update disposal set  reason = 'X', why='' where why like 'stolen%';


--delete from disposal where extract(year from tdate) <2002;

  delete from expitem where expyr < 2002 
    and id not in (select id from assets);
  delete from expense where id not in (select distinct doc_id from expitem);

  delete from item where yr < 2002;
  delete from invoice where yr < 2002;

  delete from customer where id not in 
   (select distinct cust from invoice);
  delete from supplier where id not in 
   (select distinct sup from expense) 
    and not (sname like 'AXA%' or sname like 'TVA%' or sname like 'Salar%');
commit;
