-- 2015/08/06-14:32
update assets set realised = 0;

-- perform historic depreciation =>2001
execute procedure dep_all_years(1989,2001);
-- convert asset values to EUR on 2002-01-01

update assets set curr = 'EUR', cost = cost / 40.3399,
  residual = residual / 40.3399, realised = realised / 40.3399
  where curr = 'BEF';
--execute procedure currency_conversion('BEF');
--execute procedure currency_conversion('GBP');
-- perform historic depreciation 2002=>now
execute procedure dep_all_years(2002,extract(year from cast('today' as date))-1);

-- update value of recent disposals
execute procedure update_realised(extract(year from cast('today' as date)));

commit;
