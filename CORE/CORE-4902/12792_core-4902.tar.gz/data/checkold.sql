-- queries to be run after initial import to original tables
-- check queries to be run on old and new databases
select vatcountry,count(*) cnt from customer group by vatcountry;
select country,count(*) cnt from supplier group by country;


select ac,count(*) cnt,sum(amount) amount from mvt group by ac;
select curr,count(*) cnt,sum(amount) amount from cash group by curr;

-- following syntax valid on old database
select curr,count(*) cnt,sum(net) net, sum(vat) vat from invoice 
  group by curr;
select curr,yr,count(*) cnt,sum(net) net, sum(vat) vat from invoice 
 group by curr,yr;

select curr,count(*) cnt,sum(net) net, sum(vat) vat from expense
  group by curr;
select curr,yr,count(*) cnt,sum(net) net, sum(vat) vat from expense 
 group by curr,yr;
