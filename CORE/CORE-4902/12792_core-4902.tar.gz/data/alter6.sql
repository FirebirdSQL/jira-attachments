-- 2013/04/26-09:07

-- set payment dates for expenses
execute procedure payment_history;

commit;
