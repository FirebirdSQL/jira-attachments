-- 2015/08/06-14:32
alter table invoice
  add constraint fk_inv_curr foreign key(curr) references currency(id),
  add constraint fk_inv_org  foreign key(orgid) references org(id);

alter table expense
  add constraint fk_exp_curr foreign key(curr) references currency(id),
  add constraint fk_exp_org  foreign key(orgid) references org(id);

alter table expitem
  drop constraint  U_EXPITEM,
  drop expyr, drop expnr,drop line,
  add constraint fk_expi_doc  foreign key(DOC_ID) references expense(id);


alter table assets
  add constraint fk_asset_exp foreign key(id) references expitem(id),
  add constraint fk_asset_cls foreign key(Category) references explain(id); 

-- drop redundant fields
alter table disposal
  drop constraint U_DISPOSAL,
  drop CONSTRAINT PK_DISPOSAL,
  drop yr, drop nr, drop line,
  drop INVYR,
  drop invnr,  
  drop invline,
  drop id,
  drop why,
  alter tdate set default 'today',
  add constraint pk_dispose_asset primary key(asset),
  add constraint fk_dispose_asset foreign key(asset) references assets(id);

alter table item
  drop CONSTRAINT U_ITEM,
  drop yr,
  drop nr,
  drop line,
  add constraint fk_item_doc foreign key(inv) references invoice(id);
/* still used by salary
alter table mvt
  drop refyr,
  drop refnr;
*/
drop index ix_org_cust;
drop index ix_org_supp;
alter table org
  drop oldcust,
  drop oldsupp;

alter table depreciation
  add constraint fk_dep_asset foreign key(id) references assets(id);

alter table mvt
  add constraint fk_mvt_acct foreign key (ac) references account(id),
  add constraint fk_mvt_curr foreign key(curr) references currency(id),
  add constraint fk_mvt_cls foreign key(Category) references explain(id);

alter table schedule
  add constraint fk_sched_Category foreign key(category) references explain(id);

alter table account
  drop locked;

-- drop obsolete tables
drop table CUSTOMER;
drop table  SUPPLIER;

--drop table verify;

drop view PC_BEF;
drop view PC_DEM;
drop view PC_EUR;
drop view PC_FIM;
drop view PC_FRF;
drop view PC_GBP;
drop view PC_GRD;
drop view PC_NLG;
drop view PC_PTE;
drop view PC_USD;
drop table cash;
drop procedure dep_all_years;


--drop domain d_bool;

commit;

