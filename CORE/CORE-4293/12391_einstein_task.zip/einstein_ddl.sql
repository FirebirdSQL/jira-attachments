recreate table animal (animal varchar(10) primary key);
recreate table color (color varchar(10) primary key);
recreate table drink (drink varchar(10) primary key);
recreate table nation (nation varchar(10) primary key);
recreate table smoke (smoke varchar(10) primary key);

insert into animal (animal) values ('cat'); 
insert into animal (animal) values ('fish'); 
insert into animal (animal) values ('dog'); 
insert into animal (animal) values ('horse'); 
insert into animal (animal) values ('bird'); 

insert into color (color) values ('white'); 
insert into color (color) values ('yellow'); 
insert into color (color) values ('red'); 
insert into color (color) values ('blue'); 
insert into color (color) values ('green'); 

insert into drink (drink) values ('cofee'); 
insert into drink (drink) values ('milk'); 
insert into drink (drink) values ('water'); 
insert into drink (drink) values ('beer'); 
insert into drink (drink) values ('tee'); 

insert into nation (nation) values ('eng');
insert into nation (nation) values ('swe'); 
insert into nation (nation) values ('deu'); 
insert into nation (nation) values ('den'); 
insert into nation (nation) values ('nor'); 

insert into smoke (smoke) values ('pall mall');
insert into smoke (smoke) values ('marlboro'); 
insert into smoke (smoke) values ('rothmans'); 
insert into smoke (smoke) values ('winfield'); 
insert into smoke (smoke) values ('dunhill'); 

commit;

