--set planonly;
set plan on;
set list on;
set stat on;
select 
    a1.animal as h1animal, 
    d1.drink as h1drink, 
    n1.nation as h1nation, 
    s1.smoke as h1smoke, 
    c1.color as h1color, 
    
    a2.animal as h2animal, 
    d2.drink as h2drink, 
    n2.nation as h2nation, 
    s2.smoke as h2smoke, 
    c2.color as h2color, 
    
    a3.animal as h3animal, 
    d3.drink as h3drink, 
    n3.nation as h3nation, 
    s3.smoke as h3smoke, 
    c3.color as h3color, 
    
    a4.animal as h4animal, 
    d4.drink as h4drink, 
    n4.nation as h4nation, 
    s4.smoke as h4smoke, 
    c4.color as h4color, 
    
    a5.animal as h5animal, 
    d5.drink as h5drink, 
    n5.nation as h5nation, 
    s5.smoke as h5smoke, 
    c5.color as h5color 
from
    animal a1,
    drink d1, 
    nation n1, 
    smoke s1, 
    color c1, 
    
    animal a2, 
    drink d2, 
    nation n2, 
    smoke s2, 
    color c2, 
    
    animal a3, 
    drink d3, 
    nation n3, 
    smoke s3, 
    color c3, 
    
    animal a4, 
    drink d4, 
    nation n4, 
    smoke s4, 
    color c4, 
    
    animal a5, 
    drink d5, 
    nation n5, 
    smoke s5, 
    color c5 
where 
        a1.animal <> a2.animal and 
        a1.animal <> a3.animal and 
        a1.animal <> a4.animal and 
        a1.animal <> a5.animal and 
        a2.animal <> a3.animal and 
        a2.animal <> a4.animal and 
        a2.animal <> a5.animal and 
        a3.animal <> a4.animal and 
        a3.animal <> a5.animal and 
        a4.animal <> a5.animal 
    and 
        c1.color <> c2.color and 
        c1.color <> c3.color and 
        c1.color <> c4.color and 
        c1.color <> c5.color and 
        c2.color <> c3.color and 
        c2.color <> c4.color and 
        c2.color <> c5.color and 
        c3.color <> c4.color and 
        c3.color <> c5.color and 
        c4.color <> c5.color 
    and 
        d1.drink <> d2.drink and 
        d1.drink <> d3.drink and 
        d1.drink <> d4.drink and 
        d1.drink <> d5.drink and 
        d2.drink <> d3.drink and 
        d2.drink <> d4.drink and 
        d2.drink <> d5.drink and 
        d3.drink <> d4.drink and 
        d3.drink <> d5.drink and 
        d4.drink <> d5.drink 
    and 
        n1.nation <> n2.nation and 
        n1.nation <> n3.nation and 
        n1.nation <> n4.nation and 
        n1.nation <> n5.nation and 
        n2.nation <> n3.nation and 
        n2.nation <> n4.nation and 
        n2.nation <> n5.nation and 
        n3.nation <> n4.nation and 
        n3.nation <> n5.nation and 
        n4.nation <> n5.nation 
    and 
        s1.smoke <> s2.smoke and 
        s1.smoke <> s3.smoke and 
        s1.smoke <> s4.smoke and 
        s1.smoke <> s5.smoke and 
        s2.smoke <> s3.smoke and 
        s2.smoke <> s4.smoke and 
        s2.smoke <> s5.smoke and 
        s3.smoke <> s4.smoke and 
        s3.smoke <> s5.smoke and 
        s4.smoke <> s5.smoke 
    and 
    -- 1 
    (
        (n1.nation = 'eng' and c1.color = 'red') or 
        (n2.nation = 'eng' and c2.color = 'red') or 
        (n3.nation = 'eng' and c3.color = 'red') or 
        (n4.nation = 'eng' and c4.color = 'red') or 
        (n5.nation = 'eng' and c5.color = 'red')
    ) 
    and 
    -- 2 
    (
        (n1.nation = 'swe' and a1.animal = 'dog') or 
        (n2.nation = 'swe' and a2.animal = 'dog') or 
        (n3.nation = 'swe' and a3.animal = 'dog') or 
        (n4.nation = 'swe' and a4.animal = 'dog') or 
        (n5.nation = 'swe' and a5.animal = 'dog')
    ) 
    and 
    -- 3 
    (
        (n1.nation = 'den' and d1.drink = 'tee') or 
        (n2.nation = 'den' and d2.drink = 'tee') or 
        (n3.nation = 'den' and d3.drink = 'tee') or 
        (n4.nation = 'den' and d4.drink = 'tee') or 
        (n5.nation = 'den' and d5.drink = 'tee')
    ) 
    and 
    -- 4 
    (
        (c1.color = 'green' and c2.color = 'white') or 
        (c2.color = 'green' and c3.color = 'white') or 
        (c3.color = 'green' and c4.color = 'white') or 
        (c4.color = 'green' and c5.color = 'white')
    ) 
    and 
    -- 5 
    (
        (c1.color = 'green' and d1.drink = 'coffee') or 
        (c2.color = 'green' and d2.drink = 'coffee') or 
        (c3.color = 'green' and d3.drink = 'coffee') or 
        (c4.color = 'green' and d4.drink = 'coffee') or 
        (c5.color = 'green' and d5.drink = 'coffee')
    ) 
    and 
    -- 6 
    (
        (s1.smoke = 'pall mall' and a1.animal = 'bird') or 
        (s2.smoke = 'pall mall' and a2.animal = 'bird') or 
        (s3.smoke = 'pall mall' and a3.animal = 'bird') or 
        (s4.smoke = 'pall mall' and a4.animal = 'bird') or 
        (s5.smoke = 'pall mall' and a5.animal = 'bird')
    ) 
    and 
    -- 7 
    (d3.drink = 'milk') 
    and 
    -- 8 
    (
        (s1.smoke = 'dunhill' and c1.color = 'yellow') or 
        (s2.smoke = 'dunhill' and c2.color = 'yellow') or 
        (s3.smoke = 'dunhill' and c3.color = 'yellow') or 
        (s4.smoke = 'dunhill' and c4.color = 'yellow') or 
        (s5.smoke = 'dunhill' and c5.color = 'yellow')
    ) 
    and 
    -- 9 
    (n1.nation = 'nor') 
    and 
    -- 10 
    (
        (s1.smoke = 'marlboro' and a2.animal = 'cat') or 
        (s2.smoke = 'marlboro' and 'cat' in (a1.animal, a3.animal)) or 
        (s3.smoke = 'marlboro' and 'cat' in (a2.animal, a4.animal)) or 
        (s4.smoke = 'marlboro' and 'cat' in (a3.animal, a5.animal)) or 
        (s5.smoke = 'marlboro' and a4.animal = 'cat')
    ) 
    and 
    -- 11 
    (
        (s1.smoke = 'dunhill' and a2.animal = 'horse') or 
        (s2.smoke = 'dunhill' and 'cat' in (a1.animal, a3.animal)) or 
        (s3.smoke = 'dunhill' and 'cat' in (a2.animal, a4.animal)) or 
        (s4.smoke = 'dunhill' and 'cat' in (a3.animal, a5.animal)) or 
        (s5.smoke = 'dunhill' and a4.animal = 'horse')
    ) 
    and 
    -- 12 
    (
        (s1.smoke = 'winfield' and d1.drink = 'beer') or 
        (s2.smoke = 'winfield' and d2.drink = 'beer') or 
        (s3.smoke = 'winfield' and d3.drink = 'beer') or 
        (s4.smoke = 'winfield' and d4.drink = 'beer') or 
        (s5.smoke = 'winfield' and d5.drink = 'beer')
    ) 
    and 
    -- 13 
    (
        (n1.nation = 'nor' and c2.color = 'blue') or 
        (n2.nation = 'nor' and 'blue' in (c1.color, c3.color)) or 
        (n3.nation = 'nor' and 'blue' in (c2.color, c4.color)) or 
        (n4.nation = 'nor' and 'blue' in (c3.color, c5.color)) or 
        (n5.nation = 'nor' and c4.color = 'blue')
    ) 
    and 
    -- 14 
    (
        (s1.smoke = 'rothmans' and n1.nation = 'deu') or 
        (s2.smoke = 'rothmans' and n2.nation = 'deu') or 
        (s3.smoke = 'rothmans' and n3.nation = 'deu') or 
        (s4.smoke = 'rothmans' and n4.nation = 'deu') or 
        (s5.smoke = 'rothmans' and n5.nation = 'deu')
    ) 
    and 
    -- 15 
    (
        (s1.smoke = 'marlboro' and d2.drink = 'water') or 
        (s2.smoke = 'marlboro' and 'water' in (d1.drink, d3.drink)) or 
        (s3.smoke = 'marlboro' and 'water' in (d2.drink, d4.drink)) or 
        (s4.smoke = 'marlboro' and 'water' in (d3.drink, d5.drink)) or 
        (s5.smoke = 'marlboro' and d4.drink = 'water')
    ) 
;
--set planonly;

