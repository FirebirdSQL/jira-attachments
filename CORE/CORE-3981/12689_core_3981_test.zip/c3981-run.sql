set count on;
------------------ derived table-1 ---------------
select *
from (
    select m.rname, m.id
    from trel m natural left join tfld d
)
where id = 0;

------------------ derived table-2 ---------------
select *
from (
    select m.rname, abs(m.id) as id
    from trel m natural left join tfld d
)
where id = 0;

------------------ derived table-3 ---------------
select *
from (
    select m.rname, m.id + 0 as id
    from trel m natural left join tfld d
)
where id = 0;

------------------ view-1 -----------------
select * from vtest1 where id = 0;

------------------ view-2 -----------------
select * from vtest2 where id = 0;

------------------ view-3 -----------------
select * from vtest3 where id = 0;
