package nl.lawinegevaar.fb.event;

import org.firebirdsql.event.EventListener;
import org.firebirdsql.event.FBEventManager;
import org.firebirdsql.gds.impl.GDSType;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Class to reproduce <a href="">CORE-4756</a>.
 *
 * @author <a href="mailto:mrotteveel@users.sourceforge.net">Mark Rotteveel</a>
 */
public class CORE4756 {

    private static final String HOST_NAME = "localhost";
    private static final int PORT = 3050;
    private static final String DATABASE = "D:/data/db/fb3/fb3testdatabase.fdb";
    private static final String USERNAME = "sysdba";
    private static final String PASSWORD = "masterkey";

    //@formatter:off
    public static final String POST_EVENTS =
            "EXECUTE BLOCK " +
            "AS BEGIN " +
            "     POST_EVENT 'TEST_EVENT_B';" +
            "END";
    //@formatter:on

    // Delay to wait after registering an event listener before testing
    static final int DELAY = 500;

    public static void main(String[] args) throws Exception {
        // Explicitly load driver so driver init has been done before event manager
        Class.forName("org.firebirdsql.jdbc.FBDriver");
        String database = args.length == 0 ? DATABASE : args[0];

        FBEventManager events = new FBEventManager(GDSType.getType("NATIVE"));
        events.setHost(HOST_NAME);
        events.setPort(PORT);
        events.setDatabase(database);
        events.setUser(USERNAME);
        events.setPassword(PASSWORD);
        events.connect();

        AtomicInteger count = new AtomicInteger();
        EventListener eventListener = event -> count.addAndGet(event.getEventCount());
        events.addEventListener("TEST_EVENT_B", eventListener);

        Thread.sleep(DELAY);

        try (Connection connection = DriverManager.getConnection(
                String.format("jdbc:firebirdsql://%s:%d/%s", HOST_NAME, PORT, database), USERNAME, PASSWORD)) {
            try (Statement stmt = connection.createStatement()) {
                stmt.execute(POST_EVENTS);
            }
        }

        Thread.sleep(DELAY);
        events.removeEventListener("TEST_EVENT_B", eventListener);

        System.out.printf("Count: %d (should be 1)%n", count.get());
    }
}
