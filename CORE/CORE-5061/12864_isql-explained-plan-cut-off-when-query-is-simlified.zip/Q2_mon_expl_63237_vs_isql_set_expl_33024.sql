    set list on;
    set explain on;
    --set planonly;
    set blob all;
    with recursive
    r1 as (
      select 1 as i from rdb$database
      union all
      select r.i+1 from r1 r where r.i < 2
    )
    --select count(*) from r1;

    ,r2 as (
      select first 1 row_number() over() i 
      from r1 ra
      full join r1 rb on rb.i=ra.i 
      group by ra.i 
      having count(*)>0 

      union all

      select rx.i+1 from r2 rx
      where rx.i+1 <= 2
    )
    --select count(*) from r2
    ,r3 as (
      select first 1 row_number() over() i 
      from r2 ra
      full join r2 rb on rb.i=ra.i 
      group by ra.i 
      having count(*)>0 

      union all

      select rx.i+1 from r3 rx
      where rx.i+1 <= 2
    )
    --select count(*) from r3
    ,r4 as (
      select first 1 row_number() over() i 
      from r3 ra
      full join r3 rb on rb.i=ra.i 
      group by ra.i 
      having count(*)>0 

      union all

      select rx.i+1 from r4 rx
      where rx.i+1 <= 2
    )
    ,rn as (
      select row_number() over() i 
      from rdb$database r full join rdb$database r2 on r2.rdb$relation_id=r.rdb$relation_id 
      group by r.rdb$relation_id 
      having count(*)>0 
      order by r.rdb$relation_id 
      rows 1 to 1
    )
    select 
        char_length(mon$explained_plan)
       ,(select count(*) from r4)
       ,(select count(*) from rn)
       --,(select count(*) from rn)
    from mon$statements
    ;

