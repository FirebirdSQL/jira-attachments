/*
 * $Header: /usr/local/src/interbase/single_query/RCS/single_query.c,v 1.1 2008/01/07 08:31:43 bnelson Exp bnelson $
 *
 * MODULE NAME: single_query.c
 *
 * AUTHOR: Bob Nelson <bnelson@onairusa.com>
 *
 * DATE: 03 January 2008
 *
 * DESCRIPTION: Stripped down, simple program illustrating the ``stuck
 * transaction'' problem, now a thread topic at this URL:
 *
 *      http://tech.groups.yahoo.com/group/firebird-support/messages/90533
 *
 * Doing just a single query within a transaction increments ONLY the
 * ``Next transaction''. The other counters remain static. This also happens 
 * with the code in ``examples/api/api3.c'' but doesn't occur when using 
 * ``isql'' packaged with Firedbird 2.0.3.
 *
 * USAGE AND NOTES:
 *
 * 1). export ISC_USER=sysdba
 *     export ISC_PASSWORD=masterkey
 *
 *    while true; do
 *      ./a.out
 *      sleep 1
 *    done
 *
 * 2). As this is running, issue this command from another terminal:
 *
 *      /opt/firebird/bin/gstat -h -user sysdba -pass masterkey \
 *          /opt/firebird/data/employee.fdb | egrep 'Oldest|Next transaction'
 *
 * 3). The ``employee.fdb'' database is expected to pre-exist and to
 *     have a few entries in the ``COUNTRY'' table.
 *
 * 4). The code is deliberately under-commented and variable names are short
 *     so that this can be posted to the Firebird Yahoo support forum.
 *
 */

#include <assert.h>
#include <ibase.h>
#include <stdio.h>
#include <stdlib.h>

#define CHECK_RESULT() do { isc_print_status(status); \
                            if(result) exit(result); } while(0)

int main(void)
{
    const char *dbname = "localhost:employee";
    const char *query = "SELECT count(*) FROM country";
    ISC_STATUS_ARRAY status;
    ISC_STATUS result;
    isc_db_handle db = NULL;
    isc_tr_handle tr = NULL;
    isc_stmt_handle st = NULL;
    XSQLDA *da;
    long count;

    result = isc_attach_database(status, 0, dbname, &db, 0, NULL);
    CHECK_RESULT();

    result = isc_start_transaction(status, &tr, 1, &db, 0, NULL);
    CHECK_RESULT();

    result = isc_dsql_allocate_statement(status, &db, &st);
    CHECK_RESULT();

    da = malloc(XSQLDA_LENGTH(1));
    assert(da != NULL);

    da->version = SQLDA_VERSION1;
    da->sqln = 1;
    da->sqlvar[0].sqldata = (char *)&count;

    result = isc_dsql_prepare(status, &tr, &st, 0, query, 1, da);
    CHECK_RESULT();
    assert(da->sqld == 1);

    result = isc_dsql_execute(status, &tr, &st, 1, NULL);
    CHECK_RESULT();

    result = isc_dsql_fetch(status, &st, 1, da);
    CHECK_RESULT();
    assert((da->sqlvar[0].sqltype & ~1) == SQL_LONG);
    printf("COUNT: %ld\n", count);

    result = isc_dsql_free_statement(status, &st, DSQL_close);
    CHECK_RESULT();

    result = isc_dsql_free_statement(status, &st, DSQL_drop);
    CHECK_RESULT();

    result = isc_commit_transaction(status, &tr);
    CHECK_RESULT();

    result = isc_detach_database(status, &db);
    CHECK_RESULT();

    free(da);

    return EXIT_SUCCESS;
}
