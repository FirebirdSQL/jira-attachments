/*
 * $Id: single_query.java,v 1.1 2008/01/07 08:31:43 bnelson Exp bnelson $
 *
 * DESCRIPTION: Does a single select on ``COUNTRY'' from ``employee''.
 *
 * Make a point to observe the output of ``gtat -h'' when this program runs.
 *
 * Only the ``Next transaction'' counter increments, which violates the
 * principle of ``keep the OIT moving'' as stressed by Helen Borrie in ``The
 * Firebird Book''.
 */

import java.sql.*;

public class single_query {
    public static void main(String args[]) {
        try {
            Class.forName("org.firebirdsql.jdbc.FBDriver");

            Connection conn = DriverManager.getConnection(
                            "jdbc:firebirdsql:localhost:employee",
                                "sysdba", "masterke");

            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM country");

            while(rs.next())
                System.out.printf("%s\n", rs.getString(1));

            st.close();
            conn.close();
        }
        catch(ClassNotFoundException e) {
            System.err.println("Class not found exception: " + e.getMessage());
            System.exit(1);
        }
        catch(SQLException e) {
            System.err.println("SQL exception: " + e.getMessage());
            System.exit(1);
        }
    }
}
