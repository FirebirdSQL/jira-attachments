Demonstration of FB BUG [CORE-4983] "[AV] Server crashes during execution of unprepared statement"

test_db_client_fb_1.exe - Win32 (32bit) binary, compiled by VS2015.

Requires the VC CRT from VS2015 (32bit).
 https://www.microsoft.com/en-us/download/details.aspx?id=48145
 or
 http://www.ibprovider.com/tools/download.php?file=0ca94795dde919a5ff07a1456e426c7c&lang=1

Server: Firebird 2.5.5.26942 [SC, Win64].

Server client (fbclient.dll) not required.

USER ID: SYSDBA
PASSWORD: masterkey

You can use any Firebird database.

--------
Command line [run.bat]:
 test_db_client_fb_1.exe /thread_count 1 /test *220.err2.fbbug4983* /log_dir . /inet_host localhost /db d:\database\employee.fdb

Please correct path in "/db" parameter.

------------------------------------------------------------------------------------------------------------------

            NOTE: test_db_client_fb_1.exe can be used only for demonstration of CORE-4983.

------------------------------------------------------------------------------------------------------------------
                     [source code of test (russian comments)]
------------------------------------------------------------------------------------------------------------------

void WORK_Test_020__StmtFetch__v2_lazy_send::tag_impl::test_220__err2__fbbug4983
                                           (TTSO_GlobalContext* const pParams,
                                            context_type*       const pCtx,
                                            const TTSO_TestData_v2&   Data)
{
 assert(pParams);
 assert(pCtx);

 //-----------------------------------------
 TTSO_Tracer tracer(pCtx,L"test");

 tracer<<L"Hello from test!"<<send;

 //-----------------------------------------
 typedef TestServices  svc;

 //-----------------------------------------
 structure::wstr_formatter dbLocation(L"inet://[%1]/%2");

 dbLocation<<pParams->args().get(c_prog_arg__inet_host)->m_value
           <<pParams->args().get(c_prog_arg__db)->m_value;

 //-----------------------------------------
 svc::dbprops_type params;

 params[db_obj::dbprop_init__user_id]  =L"SYSDBA";
 params[db_obj::dbprop_init__password] =L"masterkey";

 Data.SetParams(params);

 //-----------------------------------------
 isc_base::t_isc_connection_settings cns;

 const svc::remote_fb_connector_ptr
  spConnector(svc::RemoteFB_Connector__ConnectToDatabase
                                           (tracer,
                                            dbLocation.str(),
                                            params,
                                            cns));

 //-----------------------------------------
 svc::remote_fb_tr_handle_type hTr(structure::null_ptr);

 svc::RemoteFB_Connector__StartTransaction(tracer,
                                           spConnector,
                                           &hTr);

 //-----------------------------------------
 svc::remote_fb_stmt_handle_type hStmt(structure::null_ptr);

 svc::RemoteFB_Connector__StmtAllocate(tracer,
                                       spConnector,
                                       &hStmt);

 _TSO_CHECK(hStmt);
 _TSO_CHECK(hStmt->m_ID.is_defer());

 svc::RemoteFB_Connector__StmtPrepare
  (tracer,
   spConnector,
   &hTr,
   &hStmt,
   static_cast<remote_fb::protocol::P_USHORT>(cns.db_dialect_Ex.value()),
    "execute block\n"
    "returns(X INTEGER)\n"
    "AS\n"
    "BEGIN\n"
    " x=-123; SUSPEND;\n"
    "END;");

 _TSO_CHECK(hStmt);
 _TSO_CHECK(hStmt->m_ID.has_value());

 //-----------------------------------------
 XSQLDA_V1_Wrapper xsqlda(/*n*/1);
 
 db_obj::t_dbvalue__i4   columnValue=-123;
 short                   columnInd=0;
 
 xsqlda->sqlvar[0].sqllen     =sizeof(columnValue);
 xsqlda->sqlvar[0].sqltype    =isc_api::ibp_isc_sql_long|1;
 xsqlda->sqlvar[0].sqlsubtype =0;
 xsqlda->sqlvar[0].sqlscale   =0;
 xsqlda->sqlvar[0].sqldata    =reinterpret_cast<char*>(&columnValue);
 xsqlda->sqlvar[0].sqlind     =&columnInd;
 
 xsqlda->sqld=1;
 
 //----------------------------------------
 svc::RemoteFB_Connector__StmtExecute(tracer,
                                      spConnector,
                                      &hTr,
                                      &hStmt,
                                      /*in*/structure::null_ptr,
                                      /*out*/structure::null_ptr);
 
 _TSO_CHECK(hStmt);
 _TSO_CHECK(hStmt->m_ID.has_value());
 _TSO_CHECK(hStmt->m_pParentTr==hTr);
 _TSO_CHECK(hStmt->m_EFlags.test(hStmt->EFLAG__EXECUTION_WAS_DEFERRED));
 _TSO_CHECK(!hStmt->m_spFetchResult);
 _TSO_CHECK(!hStmt->m_pClosingTr);

 //----------------------------------------
 svc::HACK__UnprepareStmt(tracer,
                          spConnector,
                          &hStmt);

 _TSO_CHECK(hStmt);
 _TSO_CHECK(hStmt->m_ID.has_value());
 _TSO_CHECK(hStmt->m_pParentTr==hTr);
 _TSO_CHECK(hStmt->m_EFlags.test(hStmt->EFLAG__EXECUTION_WAS_DEFERRED));
 _TSO_CHECK(!hStmt->m_spFetchResult);
 _TSO_CHECK(!hStmt->m_pClosingTr);

 //----------------------------------------
 for(;;)
 {
  try
  {
   svc::RemoteFB_Connector__StmtFetch_ToRow(tracer,
                                            spConnector,
                                            &hStmt,
                                            /*pOutXSQLDA*/xsqlda);
  }
  catch(ibp::t_ibp_error& exc)
  {
   typedef TestCheckErrors errSvc;

   errSvc::print_exception_ok(tracer,exc);

   // 1. error from execute
   // 2. error from fetch
   errSvc::check_err_count(exc,2);

   //! \todo
   //!  �������� �������� ������ ������

   break;
  }//catch

  throw std::runtime_error("We wait the exception!");
 }//for[ever]

 //������ ����� ��������� � �������� ��������� - ������ ��� ��������� ������ ���������� �������
 _TSO_CHECK(hStmt);
 _TSO_CHECK(!hStmt->m_pParentPort)
 _TSO_CHECK(!hStmt->m_spFetchResult);
 _TSO_CHECK(!hStmt->m_EFlags.test(hStmt->EFLAG__EXECUTION_WAS_DEFERRED));
 _TSO_CHECK(!hStmt->m_pClosingTr)
 
 //-----------------------------------------
 svc::RemoteFB_Connector__Commit(tracer,
                                 spConnector,
                                 &hTr);
 
 //-----------------------------------------
 svc::RemoteFB_Connector__DetachDatabase(tracer,
                                         spConnector);
}//test_220__err2__fbbug4983

------------------------------------------------------------------------------------------------------------------

Dmitry Kovalenko
www.ibprovider.com

2015-10-30