
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Properties;

/*
 * Main.java
 *
 * Created on 02. M�rz 2004, 08:59
 */

/**
 *
 * @author  tzillinger
 */
public class TestDB {
    
    static String SQL_ERROR_STMT_ = "SELECT * FROM TEST WHERE COL1='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx more than 263 chars xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'";
    static String SQL_WORKING_STMT_ = "SELECT * FROM TEST WHERE COL1='xxxx more than 10 (size of COL1) but less then 263 chars xxxxxxxx'";

    static String SQL_INSERT_STMT_ = "INSERT INTO TEST (COL1) VALUES(?)";
    static String SQL_SELECT_STMT_ = "SELECT * FROM TEST";
    
    static String SQL_DELTEALL_STMT_ = "DELETE FROM TEST";
    
    /** Creates a new instance of TestDB */
    public TestDB() {
    }
    
    private static void testDB(Connection con, String query)
    {
        try {
            Statement stmt = con.createStatement();
            System.out.println("send QUERY: " + query);
            ResultSet rset = stmt.executeQuery(query);      
        }
        catch (SQLException e)
        {
            System.out.println("\nException !!!\n");
            e.printStackTrace(System.out);
        }
        
    }
    
    
        private static void testWriteAndReadDB(Connection con, String stringDataInsert)
    {
        try {
	    
            System.out.println("Insert '" + stringDataInsert + "' into DB");
            con.createStatement().execute(SQL_DELTEALL_STMT_);
            System.out.println("Writing");
            PreparedStatement pstmt = con.prepareStatement(SQL_INSERT_STMT_);
            pstmt.setString(1,stringDataInsert);
            System.out.println("send STATEMENT: " + SQL_INSERT_STMT_);
            
            pstmt.execute();

            System.out.println("Reading");
            Statement stmt = con.createStatement();
            System.out.println("send QUERY: " + SQL_SELECT_STMT_);
            ResultSet rset = stmt.executeQuery(SQL_SELECT_STMT_);  
            
            while (rset.next())
            {
                String dbValue = rset.getString(1);
                System.out.println("Read from DB: '" + stringDataInsert + "'");
            }
        }
        catch (SQLException e)
        {
            System.out.println("\nException !!!\n");
            e.printStackTrace(System.out);
        }
        
    }
    
    private static void displayProperties(Driver driver, String url, Properties props)
        throws SQLException
    {
        DriverPropertyInfo[] propsInfo = driver.getPropertyInfo(url, props);
        System.out.println("Possible properties to be set:");
        for (int count = 0; count < propsInfo.length; count++)
        {
            DriverPropertyInfo prop = propsInfo[count];
            System.out.println(prop.required + " " + prop.name + " " + prop.value +
                " [" + prop.choices + "]" + " (" + prop.description + ")");
        }
    }
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        
        Driver driver = new org.firebirdsql.jdbc.FBDriver();
        
        DriverManager.registerDriver(driver);
        String dbCharsetNone = "jdbc:firebirdsql://localhost/D:/develop/Projects/TestDB/TEST_NONE.GDB";
        String dbCharsetUnicode = "jdbc:firebirdsql://localhost/D:/develop/Projects/TestDB/TEST_UNI.GDB";

        Connection conDBCharsetNone = DriverManager.getConnection(dbCharsetNone, "SYSDBA", "masterkey");
        Connection conDBCharsetUnicode = DriverManager.getConnection(dbCharsetUnicode, "SYSDBA", "masterkey");
        
        DatabaseMetaData metaData = conDBCharsetNone.getMetaData();
        System.out.println("Working with: \n" + metaData.getDriverName() +
                           " " + metaData.getDriverVersion() + 
                           " on " + metaData.getDatabaseProductName() + 
                           " " + metaData.getDatabaseProductVersion());

        System.out.println("\n*** Using DB with Charset none");
        System.out.println("\nTest1: Database with charset NONE - (query with chars > 263) - works correct (no exception)");
        testDB(conDBCharsetNone, SQL_ERROR_STMT_);

        System.out.println("\n*** Using DB with Charset Unicode");
        System.out.println("\nTest2: Database with charset UNICODE - query with chars < 263 - works correct (no exception)");
        testDB(conDBCharsetUnicode, SQL_WORKING_STMT_);

        System.out.println("\nTest3: Database with charset UNICODE - (query with chars > 263) - throws exception (why ?) ");
        testDB(conDBCharsetUnicode, SQL_ERROR_STMT_);

        System.out.println("\n*** Setting charset to UTF8 for UNICODE connection");
        System.out.println("Maybe explicitly setting charset resolves problem...");
        Properties props = new Properties();
        props.setProperty("user", "SYSDBA");
        props.setProperty("password", "masterkey");
        props.setProperty("charSet", "UTF8");
        Connection conDBCharsetUnicode2 = DriverManager.getConnection(dbCharsetUnicode, props);

        displayProperties(driver, dbCharsetUnicode, props);
        
        System.out.println("\nTest5: Database with charset UNICODE and props set to UNICODE - query with chars < 263 - works correct (no exception)");
        testDB(conDBCharsetUnicode2, SQL_WORKING_STMT_);

        System.out.println("\nTest6: Database with charset UNICODE and props set to UNICODE - (query with chars > 263) - throws exception (why ?) ");
        testDB(conDBCharsetUnicode2, SQL_ERROR_STMT_);

        // This didn't work for jaybird 1.5 beta3, but seems to be resolved in 1.5 RC2
//        System.out.println("\n*** Using DB with Charset none again");
//        System.out.println("\nTest7: Write and read to and from DB correct data (chars < 10) - works correct (no exception)");
//        testWriteAndReadDB(conDBCharsetNone,"1234567890");
//        System.out.println("\nTest8: Write and read to and from DB incorrect data (10 < chars < 12) - should throw exception because COL1 is VARCHAR(10)");
//        testWriteAndReadDB(conDBCharsetNone,"123456789012");
//        System.out.println("\nTest9: Write and read to and from DB incorrect data (chars > 13) - throws exception and looses connection, I can not write anymore to this connection");
//        testWriteAndReadDB(conDBCharsetNone,"1234567890123");
//        System.out.println("\nTest10: Can not write to same connection because it's lost.");
//        testWriteAndReadDB(conDBCharsetNone,"1234567890");
        
//        testWriteAndReadDB(conDBCharsetUnicode2, "test");
//        testWriteAndReadDB(conDBCharsetUnicode2, "�sterr");
        
        conDBCharsetNone.close();
        conDBCharsetUnicode.close();
        conDBCharsetUnicode2.close();
        System.out.println("End of test");
    }
}
