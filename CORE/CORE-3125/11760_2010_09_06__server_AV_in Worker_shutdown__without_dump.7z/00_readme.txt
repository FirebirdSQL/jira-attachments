This problem was detected in IBProvider Test System.
 - 8 worker threads

Hardware:
Q6600/4GB

OS:
Vista SP2+ x64

----
[06.09.2010 01:28:35] [info] Provider DLL    :_IBProvider_v3_vc9_w64_trial_i.dll
[06.09.2010 01:28:35] [info] Provider Version:3.0.0.10547
[06.09.2010 01:28:35] [info] Server Name     :Firebird SuperClassix x64 [2010-08-31 09:32] [VS2008 SP1+]
[06.09.2010 01:28:35] [info] Server Version  :2.5.0.26073
[06.09.2010 01:28:35] [info] Client Name     :Firebird SQL Server
[06.09.2010 01:28:35] [info] Client Version  :2.5.0.26073
[06.09.2010 01:28:35] [info] Database ODS    :11.2
[06.09.2010 01:28:35] [info] Database Dialect:3

----
Path to server source tree
d:\Users\Dima\Sourceforge_SVN2\firebird_B2_5_0\02

----
00_readme.txt
01_threads.txt
01_threads__sorted_by_func.txt
01_threads__sorted_by_ID.txt
02_thread__1384.txt
02_thread__1864.txt
02_thread__1880.txt
02_thread__2432.txt
02_thread__3324.txt
02_thread__3356.txt
02_thread__3724.txt
02_thread__4524.txt
02_thread__4744.txt
02_thread__5064.txt
02_thread__5140.txt
02_thread__5416.txt
02_thread__5556.txt
02_thread__6112.txt
02_thread__6280.txt
02_thread__7676.txt
03_fb_inet_server.exe_info__DLLs.txt
03_fb_inet_server.exe_info__files.txt
04_modules.txt
fb_inet_server.dmp (not includes to archive)
VS2008_screen.bmp

----
Kovalenko Dmitry
2010-09-06