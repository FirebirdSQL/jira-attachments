/*
 *  Program type:  API Interface
 *
 *  Description:
 *        This program adds several departments with small default
 *        budgets, using 'execute immediate' statement.
 *        Then, a prepared statement, which doubles budgets for
 *        departments with low budgets, is executed.
 * The contents of this file are subject to the Interbase Public
 * License Version 1.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy
 * of the License at http://www.Inprise.com/IPL.html
 *
 * Software distributed under the License is distributed on an
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express
 * or implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code was created by Inprise Corporation
 * and its predecessors. Portions created by Inprise Corporation are
 * Copyright (C) Inprise Corporation.
 *
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "example.h"
#include <ibase.h>

#include "Windows.h"
#include "Winbase.h"

#define MAXLEN      256
#define DNAMELEN    25
#define DNOLEN      3


isc_db_handle    DB = NULL;             /* database handle */
isc_tr_handle    trans = NULL;          /* transaction handle */
ISC_STATUS_ARRAY status;                /* status vector */
char             Db_name[128];

int main (int argc, char** argv)
{
    int                 n = 0;
    char                exec_str[MAXLEN];
    char                prep_str[MAXLEN];
    isc_stmt_handle     double_budget = NULL;    /* statement handle */
    HANDLE              hCP;

    SECURITY_DESCRIPTOR  rSecDesc;


    if (argc > 1)
        strcpy(Db_name, argv[1]);
    else
        strcpy(Db_name, "employee.fdb");

    /*
    Set an NULL ACL to allow all Access to the Object (process), needed because
    handles need to be shared between two applications not neccessary running
    under the same acount
    */
    if (!InitializeSecurityDescriptor(&rSecDesc, SECURITY_DESCRIPTOR_REVISION)) {
       printf("\nInitializeSecurityDescriptor failed %d\n", GetLastError);
    };
    if (! SetSecurityDescriptorDacl(&rSecDesc, TRUE, (PACL)NULL, FALSE)) {
       printf("\nSetSecurityDescriptorDacl failed %d\n", GetLastError);
    }
    if (! SetKernelObjectSecurity(GetCurrentProcess(), DACL_SECURITY_INFORMATION, &rSecDesc)) {
       printf("\nSetKernelObjectSecurity failed %d\n", GetLastError);
    }


    hCP = OpenProcess( PROCESS_DUP_HANDLE, 1, GetCurrentProcessId());
    if (hCP != 0) {
       printf("\nFirst DUP handle fine:\n%d:\n", hCP);
       CloseHandle(hCP);
    }

    printf("\nNow calling isc_attach_database %s",Db_name);

    if (isc_attach_database(status, 0, Db_name, &DB, 0, NULL))
    {
        ERREXIT(status, 1)
    }

    printf("\nDB is open %s",Db_name);

    hCP = OpenProcess( PROCESS_DUP_HANDLE, 1, GetCurrentProcessId());
    if (hCP != 0) {
       printf("\nSecond DUP handle fine:\n%d:\n", hCP);
       CloseHandle(hCP);
    } else {
       printf("\nSecond DUP handle failed :\n Reason %d:\n", GetLastError());
    }

    printf("\nClosing");
    isc_detach_database(status, &DB);
    return 0;
}

