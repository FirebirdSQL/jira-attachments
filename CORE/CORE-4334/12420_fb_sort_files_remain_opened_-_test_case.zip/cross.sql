set echo off;
show version;
commit;
set transaction read committed record_version no wait;
set stat on;
set term ^;
execute block returns(msg varchar(80) ) as
  declare n int = 1000;
  declare k int = 20;
  declare q int = 0;
  declare m int;
  declare v1 int;
  declare v2 int;
begin
  for
    with recursive 
    nx as(
      select 1 m from rdb$database union all select r.m+1 from nx r where r.m < :n
    )
    select m from nx 
    order by rand()
  into m
  do begin
    in autonomous transaction do
    begin
        insert into t(id, f1, f2)
        with recursive data as(
          select 1 x from rdb$database union all select r.x+1 from data r where r.x < :k
        )
        select gen_id(g,1), :m*10000 + 100*d.x+rand()*50 v1, :m*10000 + 100*d.x+51+rand()*49
        from data d
        order by rand();
        q = q + ROW_COUNT;
        when any do begin end
    end
    --if ( mod(m, 50) = 0 ) then begin
      msg=cast('now' as timestamp)||' m='||m||', total rows affected: '||q;
      suspend;
    --end
    when any do begin end -- ?!
  end
end^
set term ;^
set stat off;

--set echo on;
--select count(*) from v_cross_m;
--set echo off;
rollback;
set echo on;
select count(*) from v_cross_t;
select count(*) from t;
rollback;
