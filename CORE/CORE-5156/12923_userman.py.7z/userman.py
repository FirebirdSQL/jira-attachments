import fdb
from fdb import services

con4secdb = services.connect(host='localhost/3400', user='sysdba', password='masterkey')

con4sysdba=fdb.connect(dsn='localhost/3400:e40', user='sysdba', password='masterkey')
cur4sysdba=con4sysdba.cursor()
con4sysdba.begin()


u01 = services.User('ozzy')
u01.first_name = 'John'
u01.middle_name = 'Michael'
u01.last_name = 'Osbourne'
u01.password = '123'
con4secdb.add_user(u01)

print('\n\nStart:')
sec_sttm="select * from sec$users"
cur4sysdba.execute(sec_sttm)
for row in cur4sysdba:
  print( row[0]+" "+row[1]+" "+row[2]+" "+row[3] )

con4user = fdb.connect(dsn='localhost/3400:e40', user='ozzy', password='123')

who_sttm="select mon$attachment_id,mon$user from mon$attachments"
c_who_are_here=con4user.cursor()
c_who_are_here.execute(who_sttm)

print('\n\nWho are here, non-privileged POV:')
for row in c_who_are_here:
  print( str(row[0])+" "+row[1] )

c_who_sysdba=con4sysdba.cursor()
c_who_sysdba.execute(who_sttm)
print('\n\nWho are here, SYSDBA POV:')

for row in c_who_sysdba:
  print( str(row[0])+" "+row[1] )

con4user.close()

u01.first_name =  '___O___Z___Z___Y____'
u01.middle_name = '### THE TERRIBLE ###'
u01.last_name =   '___O.S.B.O.U.R.N.E__'

u01.password = '' # <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< !!!!! WHY IT IS POSSIBLE HERE ????? <<<<<<<

con4secdb.modify_user(u01) # <<<<<<<<<<<<<<<<<<<<<<<< !!!!! NO ERROR ABOUT EMPTY PASSWORD !!!!!!!

con4sysdba.commit()

#con4user_b = fdb.connect(dsn='localhost/3400:e40', user='ozzy', password='') # SQLCODE: -902 Your user name and password...
#con4user_b.close()

print('\n\nFinal:')
con4sysdba.begin()
sec_sttm="select * from sec$users"
cur4sysdba.execute(sec_sttm)
for row in cur4sysdba:
  print( row[0]+" "+row[1]+" "+row[2]+" "+row[3] )
con4sysdba.commit()

con4secdb.remove_user('ozzy')
