import os
import time
import threading
from datetime import datetime

import fdb
from fdb import TPB

os.environ["ISC_USER"] = 'sysdba'
os.environ["ISC_PASSWORD"] = 'masterke'

dbname='localhost:e40'

# description of test:
# http://www.sql.ru/forum/1224046-3/zabavnoe-povedenie-rec-version-v-wait-tranzakciyah?mid=19466920#19466920
# Tracker, hvlad:
# Test database have page size 16KB and records in test table have near 8KB declared length 
# and 1100-1200B packed length, i.e. records fragmented often. 

sql_update='''update test set
   s01 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s02 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s03 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s04 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s05 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s06 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s07 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s08 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s09 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
  ,s10 = iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
where id = ?
;
'''

def send_event_function(att, command_list):
   cur=att.cursor()
   for cmd in command_list:
      cur.execute(cmd)
   att.commit()

def showtime():
   import datetime
   return datetime.datetime.now().strftime("%H:%M:%S.%f")[:12] # 00:41:06.316

class myThread (threading.Thread):
    def __init__(self, threadID, name, a_tpb):
	import threading
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        
        global dbname
        global launched_tx_lock_timeout
        self.att = fdb.connect(dsn=dbname) 

        self.local_tpb = TPB()
        self.local_tpb.isolation_level = (fdb.isc_tpb_read_committed, fdb.isc_tpb_no_rec_version)
        self.local_tpb.lock_timeout = launched_tx_lock_timeout
        
        #self.local_tpb = a_tpb

        print( 'Thread %d created OK, dbname=%s, att=%d' % (threadID, dbname, self.att.attachment_id) )

    def run(self):
        from random import randint
        global id_max

        tx = self.att.trans( default_tpb = self.local_tpb )

        tx.begin()
        cx = tx.cursor()

        print( '%s: %s - START listening for event, att=%d, trn=%d' % ( showtime(), self.name, self.att.attachment_id, tx.transaction_id ) )

        self.evt = self.att.event_conduit(['wake-up'])
        self.evt.begin()
        self.evt_result = self.evt.wait() # ------   m a k e    c l i e n t    w a i t   f o r    e v e n t
        self.evt.close()

        for i in self.evt_result:
            print('%s: %s got event %s, att # %d' % ( showtime(), self.name, i, self.att.attachment_id) )

        # -- [ 1 ]
        #tx = self.att.trans( default_tpb = global_tpb )
        #cx = tx.cursor()

        c2 = tx.cursor() 

        try:
            cx.execute('select id from test where id > %d rows %d with lock' % ( randint(0, id_max-1 ), randint(50,200) ) )
            rset=[]
            for r in cx.fetchall():
                rset.append( (r[0],) )
            
            cx.executemany(sql_update, rset)

        except Exception as e:
            print('\n%s: %s EXCEPTION in att # %d, trn_id # %d, text: %s ' % (showtime(), self.name, self.att.attachment_id, tx.transaction_id, e[0] ) )
        else:
            print('%s: %s - SUCCESS, att # %d, trn_id # %d' % (showtime(), self.name, self.att.attachment_id, tx.transaction_id ) )
        finally:
            tx.commit()


####################################################################################

con_main = fdb.connect(dsn=dbname)

id_max=0

cur=con_main.cursor()
cur.execute('select id from test order by id desc rows 1')
for r in cur.fetchall():
  id_max = r[0]

num_of_launched_threads = 175
event_sending_delay_sec = 5
launched_tx_lock_timeout = 4

global_tpb = TPB()
global_tpb.isolation_level = (fdb.isc_tpb_read_committed, fdb.isc_tpb_no_rec_version)
global_tpb.lock_timeout = launched_tx_lock_timeout

print('%s: MAIN THREAD - START, attachment_id=%d' % (showtime(), con_main.attachment_id) )


trd_lst=[]

#    a s y n c     s t a r t    <num_of_launched_threads>   c l i e n t s   i n     s e p a r a t e      t h r e a d s


for i in range(0, num_of_launched_threads):
    trd_lst.append( myThread( i, "Thread-"+str(i), global_tpb ) )

#  s e n d    e v e n t    t o   c l i e n t s    a f t e r    <event_sending_delay_sec>   s e c o n d s

print('%s: MAIN THREAD - SEND EVENT WITH DELAY' % showtime() )
timed_event = threading.Timer( event_sending_delay_sec, send_event_function, args=[ con_main, ["execute procedure sp_run",] ])
timed_event.start()


for i in range(0, num_of_launched_threads):
    trd_lst[i].start()

print('%s: MAIN THREAD - WAITING FOR FINISH...' % showtime())
for t in trd_lst:
    t.join()

for i in range(0, num_of_launched_threads):
    trd_lst[i].att.close()

print('%s: MAIN THREAD - closing attach' % showtime())
con_main.close()
print('%s: MAIN THREAD - FINISH' % showtime())
exit(0)
# WI-T4.0.0.326
