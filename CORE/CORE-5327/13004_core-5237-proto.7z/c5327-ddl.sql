shell del C:\MIX\firebird\QA\fbt-repo\tmp\c5327.fdb 2>nul;
create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\c5327.fdb' page_size 16384;
commit;

create table test(
   id bigint primary key using descending index test_pk_desc
  ,trn_id bigint
  ,s01 varchar(820) unique
  ,s02 varchar(820) unique
  ,s03 varchar(820) unique
  ,s04 varchar(820) unique
  ,s05 varchar(820) unique
  ,s06 varchar(820) unique
  ,s07 varchar(820) unique
  ,s08 varchar(820) unique
  ,s09 varchar(820) unique
  ,s10 varchar(820) unique
);
commit;

create sequence g;
commit;

set term ^;
execute block as
    declare n int = 2000;
begin
    while (n>0) do
    begin
        insert into test(id, trn_id, s01, s02, s03, s04, s05, s06, s07, s08, s09, s10)
        values( 
            gen_id(g,1)
           ,0
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
           ,iif( rand() < 0.13, rpad('', 820, uuid_to_char(gen_uuid())), null)
        );
        n = n - 1;
    end
end
^
create or alter procedure sp_run as
begin
  post_event 'wake-up';
end
^
set term ;^
commit;
