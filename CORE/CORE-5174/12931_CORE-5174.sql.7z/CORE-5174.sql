shell del CORE-5174;
create database "CORE-5174";
create table t (f varchar(20));
create exception Boom 'Boom';
set term ^;
create procedure ins_t2 returns (a integer) as
begin
  a = coalesce(rdb$get_context('USER_TRANSACTION', 'a'),0);
  rdb$set_context('USER_TRANSACTION', 'a', a+1);
  insert into t values (:a);
  if (a = 2) then
      exception Boom;
end^
create procedure ins_t1 returns (a integer) as
begin
  a = 100;
  while (1=1) do
   begin
    begin
      insert into t values (:a||'a');
      execute procedure ins_t2 returning_values a;
      if (a > 4) then
        leave;
      suspend;
      insert into t values (:a||'b');
    when any do begin insert into t values (-1); end
    end
   end
end^
commit^
execute block returns (a integer) as
begin
  for select a from ins_t1 into :a do
   begin
    insert into t values (:a||'c');
    suspend;
    insert into t values (:a||'d');
   end
end^
set term ;^
select * from t;
