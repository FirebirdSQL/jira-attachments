-- recreate sequence g; commit;
-- recreate table t(id bigint, s01 varchar(8), s02 varchar(8));
-- recreate table ins_log(
--   dts_beg timestamp, dts_end timestamp,
--   elapsed_ms int computed by(datediff(millisecond from dts_beg to dts_end)), 
--   gen_after_ins bigint, pp_after_ins int ); 
-- commit;
-- create descending index ins_log_dts_beg_desc on ins_log(dts_beg); 
-- commit;

select 'start packet' msg, current_timestamp dts, gen_id(g,0) gen_before_ins from rdb$database;

set stat on;
set term ^;
execute block as
  declare n bigint = 1000000;
  declare v_base bigint;
  declare i bigint = 0;
  declare v_dbkey char(8) character set octets;
begin
  v_base = gen_id(g, 0);

  insert into ins_log ( dts_beg ) values ( 'now' )
  returning rdb$db_key into v_dbkey;

  while (i<n) do begin

     insert into t(id,s01,s02)
     values( :v_base + :i,
             rpad('', 8, uuid_to_char(gen_uuid())),
             rpad('', 8, uuid_to_char(gen_uuid()))
            );
     i=i+1;
  end
  i = gen_id(g, :n);

  update ins_log set 
    dts_end = 'now', gen_after_ins = gen_id(g, 0),
    pp_after_ins = ( select count(*) 
		     from rdb$pages p natural join rdb$relations r 
		     where r.rdb$relation_name='T' and p.rdb$page_type=4 
		   )
  where rdb$db_key = :v_dbkey;

end ^
set term ;^
set stat off;

select 'finish packet' msg, i.* from ins_log i order by dts_beg desc rows 1;
--select current_timestamp dts, 'finish packet' msg, gen_id(g,0) curr_gen from rdb$database;
-- set stat on;
-- set echo on;
commit;
-- set echo off;
-- set stat off;
select 'done commit' msg, current_timestamp dts, iif(gen_id(g,0) > 10000000000, 'stop!', 'go-on' ) flag  from rdb$database;
