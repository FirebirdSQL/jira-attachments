#include <inttypes.h>
#include <memory.h>
#include <stdio.h>

typedef int32_t SLONG;
typedef long long SINT64;
typedef signed char SCHAR;
typedef unsigned char UCHAR;
typedef short SSHORT;
typedef unsigned short USHORT;

#define MAX_SCHAR		0x7F
#define MIN_SCHAR		(-MAX_SCHAR - 1)

#define MAX_SSHORT		0x7FFF
#define MIN_SSHORT		(-MAX_SSHORT - 1)

#define MAX_SLONG		0x7FFFFFFF
#define MIN_SLONG		(-MAX_SLONG - 1)

SINT64 isc_portable_integer_fixed(const UCHAR* ptr, SSHORT length)
{
/**************************************
 *
 *	i s c _ p o r t a b l e _ i n t e g e r
 *
 **************************************
 *
 * Functional description
 *	Pick up (and convert) a Little Endian (VAX) style integer
 *      of variable length to local system's Endian format.
 *
 *   various parameter blocks (i.e., dpb, tpb, spb) flatten out multibyte
 *   values into little endian byte ordering before network transmission.
 *   programs need to use this function in order to get the correct value
 *   of the integer in the correct Endian format.
 *
 * **Note**
 *
 *   This function is similar to gds__vax_integer() in functionality.
 *   The difference is in the return type. Changed from SLONG to SINT64
 *   Since gds__vax_integer() is a public API routine, it could not be
 *   changed. This function has been made public so gbak can use it.
 *
 **************************************/
	if (!ptr || length <= 0 || length > 8)
		return 0;

	SINT64 value = 0;
	int shift = 0;

	while (--length > 0)
	{
		value += ((SINT64) *ptr++) << shift;
		shift += 8;
	}
	value += ((SINT64)(SCHAR) *ptr) << shift;

	return value;
}

SINT64 isc_portable_integer(const UCHAR* ptr, SSHORT length)
{
/**************************************
 *
 *	i s c _ p o r t a b l e _ i n t e g e r
 *
 **************************************
 *
 * Functional description
 *	Pick up (and convert) a Little Endian (VAX) style integer
 *      of length 1, 2, 4 or 8 bytes to local system's Endian format.
 *
 *   various parameter blocks (i.e., dpb, tpb, spb) flatten out multibyte
 *   values into little endian byte ordering before network transmission.
 *   programs need to use this function in order to get the correct value
 *   of the integer in the correct Endian format.
 *
 * **Note**
 *
 *   This function is similar to gds__vax_integer() in functionality.
 *   The difference is in the return type. Changed from SLONG to SINT64
 *   Since gds__vax_integer() is a public API routine, it could not be
 *   changed. This function has been made public so gbak can use it.
 *
 **************************************/
	if (!ptr || length <= 0 || length > 8)
		return 0;

	SINT64 value = 0;

	for (int shift = 0; --length >= 0; shift += 8) {
		value += ((SINT64) *ptr++) << shift;
	}

	return value;
}

USHORT INF_convert(SINT64 number, UCHAR* buffer)
{
/**************************************
 *
 *	I N F _ c o n v e r t
 *
 **************************************
 *
 * Functional description
 *	Convert a number to VAX form -- least significant bytes first.
 *	Return the length.
 *
 **************************************/
	if (number == 0)
		return 0;

	if (number > 0)
	{
		USHORT length = 0;
		SINT64 tmp;
		do
		{
			tmp = number;
			*buffer++ = number & 0xFF;
			number >>= 8;
			length++;
		} while (tmp > 0x7F);
		return length;
	}
	else
	{
		USHORT length = 0;
		SINT64 tmp;
		do
		{
			tmp = number;
			*buffer++ = number & 0xFF;
			number >>= 8;
			length++;
		} while (tmp < -128);
		return length;
	}
}

void test(SINT64 value)
{
  UCHAR buf[128];
  USHORT len = INF_convert(value, buf);
  SINT64 result = isc_portable_integer(buf, len);
  SINT64 fixed_result = isc_portable_integer_fixed(buf, len);
  printf("%20lld%20lld%20lld (length %d)\n", value, result, fixed_result, len);
}

int main()
{
  printf("      original value   portable_integer()           fixed\n");
  test(0);
  test(1);
  test(-1);
  test(127);
  test(128);
  test(-128);
  test(129);
  test(-129);
  test((SINT64)MAX_SSHORT);
  test((SINT64)MIN_SSHORT);
  test((SINT64)MAX_SSHORT + 1);
  test((SINT64)MIN_SSHORT - 1);
  test((SINT64)MAX_SLONG);
  test((SINT64)MIN_SLONG);
  test((SINT64)MAX_SLONG + 1);
  test((SINT64)MIN_SLONG - 1);
  return 0;
}
