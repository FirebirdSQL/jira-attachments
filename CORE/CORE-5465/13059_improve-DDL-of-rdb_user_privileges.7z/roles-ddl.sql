set bail on;
set autoddl off;
set echo on;

set term ^;
execute block as
  declare u int = 2000; ----------------------- number of USERS ------------------
begin
  while(u>0) do
  begin
      execute statement 'create or alter user u_'||u||' password ''1''';
      u=u-1;
  end
end
^
commit
^
execute block as
  declare u int = 20; --------------------------- number of ROLES  ---------------
  declare r varchar(63);
  declare usr_cnt int;
  declare i int;
  declare c_role cursor for -- roles
    (select rr.rdb$role_name
      from rdb$roles rr
     where coalesce(rr.rdb$system_flag,0)=0
    );
begin
  open c_role;
  while (1=1) do
  begin
    fetch c_role into r;
    if (row_count = 0) then leave;
    execute statement 'drop role '||r;
  end
  close c_role;

  select count(*) from sec$users u where u.sec$user_name starting with upper('U_') into usr_cnt;

  while(u>0) do
  begin
      execute statement 'create role r_'||u;
      i = usr_cnt;
      while (i>0) do
      begin
          execute statement 'grant r_'||u||' to u_'||i;
          i = i-1;
      end
      u=u-1;
  end
end
^
commit
^

execute block as
  declare u int = 3000; ----------------------- number of TABLES ------------------------
begin
  while(u>0) do
  begin
      execute statement 'recreate table t_'||u||'(u int, v int, w int)';
      u=u-1;
  end
end
^
commit
^

execute block as
  declare rel_name varchar(63);
  declare role_name varchar(63);
  declare stt varchar(255);
begin
  for
      select r.rdb$relation_name, s.rdb$role_name
      from rdb$roles s
      cross join rdb$relations r
      where r.rdb$relation_name starting with upper('T_') and s.rdb$role_name starting with upper('R_')
      into rel_name, role_name
  do begin
    stt = 'grant all on '||trim(rel_name)||' to role '||trim(role_name);
    execute statement stt;
  end
end
^
set term ;^
commit;


-------------------------------------------------------------------------

recreate table user_priv_copy (  ------------- this table is used for comparison, see script 'roles-run.sql'
    rdb$user           char(63) character set utf8,
    rdb$grantor        char(63) character set utf8,
    rdb$privilege      char(6),
    rdb$grant_option   smallint,
    rdb$relation_name  char(63) character set utf8,
    rdb$field_name     char(63) character set utf8,
    rdb$user_type      smallint,
    rdb$object_type    smallint
);
commit;

insert into user_priv_copy select * from rdb$user_privileges;
commit;

create index up_rel_name on user_priv_copy (rdb$relation_name);
create index up_user_priv_fldname on user_priv_copy (rdb$user,rdb$privilege,rdb$field_name); -- modified key here: add two fields.
commit;

grant select on user_priv_copy to role R_19;
commit;

-- standard indices for rdb$user_privileges:
--create index rdb$index_29 on rdb$user_privileges (rdb$relation_name);
--create index rdb$index_30 on rdb$user_privileges (rdb$user);
