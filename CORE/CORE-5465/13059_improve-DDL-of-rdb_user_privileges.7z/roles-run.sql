connect 'localhost:e40' user U_1999 password '1' role R_19;

set list on;
set count on;

with recursive role_tree as (
     select rdb$relation_name as nm, 0 as ur
     from USER_PRIV_COPY
     where
         rdb$privilege = 'M'
         and rdb$field_name = 'D'
         and rdb$user = 'U_1999' -- ?
         and rdb$user_type = 8
     UNION ALL
     select rdb$role_name as nm, 1 as ur
     from rdb$roles
     where rdb$role_name = 'R_19'
     UNION ALL
     select p.rdb$relation_name as nm, t.ur
     from USER_PRIV_COPY p
     join role_tree t on t.nm = p.rdb$user
     where
         p.rdb$privilege = 'M'
         and (p.rdb$field_name = 'D' or t.ur = 1)
)
select  r.rdb$role_name,  r.rdb$system_privileges
from role_tree t
join rdb$roles r on t.nm = r.rdb$role_name
;
