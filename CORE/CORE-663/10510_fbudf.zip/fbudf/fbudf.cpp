inline bool IsLeapYear(int Y)
//You can consider move this function to another place and use it in calls from fbudf.cpp, SysFunction.cpp, timestamp.cpp
{
	return Y % 4 == 0 && Y % 100 != 0 || Y % 400 == 0;
}    

FBUDF_API ISC_SHORT WeekOfYear(const ISC_TIMESTAMP* v)
// Algorithm for Converting Gregorian Dates to ISO 8601 Week Date by Rick McCarty, 1999
// http://personal.ecu.edu/mccartyr/ISOwdALG.txt
{
	tm times;
	internal::decode_timestamp(v, &times);
	int Y=times.tm_year + 1900;
/*
	int M=times.tm_mon + 1; //1-12
	int D=times.tm_mday; //1-31

	const int Mnth[] = {0,31,59,90,120,151,181,212,243,273,304,334};
	//Find the DayOfYearNumber for Y M D 
	int DayOfYearNumber=D+Mnth[M-1];
	if (IsLeapYear(Y) && (M>2)) DayOfYearNumber++;
*/
	int DayOfYearNumber=times.tm_yday + 1;

	//Find the Jan1Weekday for Y (Monday=1, Sunday=7)
	int YY = (Y - 1) % 100;
	int C = (Y - 1) - YY;
	int G = YY + YY/4;
	int Jan1Weekday = 1 + (((((C / 100) % 4) * 5) + G) % 7);

	//Find the Weekday for Y M D
	int H = DayOfYearNumber + (Jan1Weekday - 1);
	int Weekday = 1 + ((H - 1) % 7);

	//Find if Y M D falls in YearNumber Y-1, WeekNumber 52 or 53
	int YearNumber, WeekNumber;
	if ((DayOfYearNumber <= (8 - Jan1Weekday)) && (Jan1Weekday > 4))
	{
		YearNumber = Y - 1;
		WeekNumber = (Jan1Weekday == 5) || ((Jan1Weekday == 6) && IsLeapYear(YearNumber)) ? 53 : 52;
	}
	else
		YearNumber = Y;

	//Find if Y M D falls in YearNumber Y+1, WeekNumber 1
	if (YearNumber == Y)
	{
		int I = IsLeapYear(Y) ? 366 : 365;
		if ((I - DayOfYearNumber) < (4-Weekday))
		{
			YearNumber = Y + 1;
			WeekNumber = 1;
		}
	}
        
	//Find if Y M D falls in YearNumber Y, WeekNumber 1 through 53    
	if (YearNumber==Y)
	{
		int J=DayOfYearNumber + (7 - Weekday) + (Jan1Weekday -1);
		WeekNumber = J / 7;
		if (Jan1Weekday > 4) WeekNumber--;
	}
	return (WeekNumber);
}
