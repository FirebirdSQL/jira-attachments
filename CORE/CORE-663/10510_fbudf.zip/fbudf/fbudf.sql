--FBUDF_API ISC_SHORT WeekOfYear(const ISC_TIMESTAMP* v)
declare external function weekofyear
timestamp
returns smallint by value
entry_point 'WeekOfYear' module_name 'fbudf';