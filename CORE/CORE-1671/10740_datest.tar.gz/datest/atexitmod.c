#include <stdlib.h>
#include <stdio.h>

void exithandler(void);

void hellodriver(void) {
  printf("hello driver\n");
  fflush(stdout);
  atexit(exithandler);
}

void exithandler(void) {
  printf("now exiting\n");
  fflush(stdout);
}
