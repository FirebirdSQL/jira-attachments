#include <stdlib.h>
#include <stdio.h>
#include <dlfcn.h>

int main (void) {
  void *dlhandle;
  void (*hellodriver) (void);
  dlhandle = dlopen("/home/markus/prog/datest/atexitmod.so", RTLD_LAZY);
  if (!dlhandle) {
    printf("cannot open module\n");
    exit(1);
  }
  hellodriver = dlsym(dlhandle, "hellodriver");
  if (!hellodriver) {
    printf("cannot locate function\n");
    exit(1);
  }
  hellodriver();
  dlclose(dlhandle);
  exit(0);
}
