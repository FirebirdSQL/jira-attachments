THE EXE FILE COULD NOT BE INCLUDED BECAUSE OF LIMIT 256kb.
I WILL SEND IT BY EMAIL IF YOU ASK ME.

You can recompile the program with Delphi 7 Pro with IBX 7.08.

This is testing tool for simulating bug of incorrect behavior 
during stopping firebird server. 

It was tested with Firebird 1.5.1 SuperServer installation.

I RECOMMEND YOU TO MAKE A COPY OF TEST.FDB BEFORE RUNNING 
A TEST.

Run simulator.exe (it's Win32 GUI application) and follow
the instruction in main form.




Best regards
Martin Janus

mjanus@janus.cz