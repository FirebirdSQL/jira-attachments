// compile: javac -cp .;jaybird-full-2.2.4.jar FbGetDatabaseInfo.java
// run:     java -cp .;jaybird-full-2.2.4.jar FbGetDatabaseInfo 1>FbGetDatabaseInfo.log 2>FbGetDatabaseInfo.err
import static java.lang.System.*;
import java.text.*;
import java.util.*;
import org.firebirdsql.gds.*;
public final class FbGetDatabaseInfo
{
  private static DateFormat df = new SimpleDateFormat("HH:mm:ss.SSS");

  private static final String DB_URL="192.168.0.201/3252:employee";
  //private static final String DB_URL="192.168.0.220/3330:idx_test";
  private static final String DB_USER="sysdba";
  private static final String DB_PSWD="masterke";
  static public void main (String args[]) throws Exception
  {
    // todo: use args for: db_name, db_user, db_password, sleep_delay  
    try {

      org.firebirdsql.gds.GDS gdso = org.firebirdsql.gds.GDSObjectFactory.createJavaGDSImpl();
      // Factory method to create a new IscDbHandle instance specific to the implementation of this interface.
      IscDbHandle dh =  gdso.createIscDbHandle();

      DatabaseParameterBuffer dpb = gdso.createDatabaseParameterBuffer();
      dpb.addArgument(DatabaseParameterBuffer.USER, DB_USER);
      dpb.addArgument(DatabaseParameterBuffer.PASSWORD, DB_PSWD);
      dpb.addArgument(DatabaseParameterBuffer.CONNECT_TIMEOUT, 2000);

      out.println( df.format( System.currentTimeMillis() )+ " trying to attach. . .");
      gdso.iscAttachDatabase(DB_URL, dh, dpb);
      out.println( df.format( System.currentTimeMillis() )+" attached to "+DB_URL);
      
      Map<Integer, StatValue> cntx = new LinkedHashMap<Integer, StatValue>();
      cntx.put( ISCConstants.isc_info_reads,   new StatValue("reads",7));
      cntx.put( ISCConstants.isc_info_writes,  new StatValue("writes",7));
      cntx.put( ISCConstants.isc_info_fetches, new StatValue("fetches",7));
      cntx.put( ISCConstants.isc_info_marks,   new StatValue("marks",7));
      cntx.put( ISCConstants.isc_info_end,     new StatValue("end",7));

      byte[] items = new byte[cntx.size()];
      int ii=0;
      for(Integer k : cntx.keySet()) {
         items[ii++] = k.byteValue();
      }
      
      int len;
      byte item;
      short i;
      byte[] dbstat; // stores result values of counters
      int prevVal, currVal; //StatValue v = new StatValue(null);
      while(true) {
        try {  
            out.println(df.format( System.currentTimeMillis() )+" trying to gather db statistics. . .");
            dbstat=gdso.iscDatabaseInfo(dh, items, 0); // 128);
            out.print(df.format( System.currentTimeMillis() )+" statistics gathered, dbstat[] length="+dbstat.length);
            //out.println(dbstat[0]);
            String dts;
            i=0;
            while( dbstat[i]!=ISCConstants.isc_info_end) { 
                // API guide: A one-byte item return type. 
                // There are compile-time constants defined for all the item return
                // types in ibase.h (inf_pub.h ?)
                item=dbstat[i++];
                // API guide:  A two-byte number specifying the number of bytes that 
                // follow in the remainder of the cluster.          
                len = gdso.iscVaxInteger(dbstat, i, 2);
                i+=2;
                dts=df.format( System.currentTimeMillis() );
                if  (cntx.containsKey( (int)item) ) {
                   out.println();
                   prevVal = cntx.get((int)item).val;
                   currVal = gdso.iscVaxInteger(dbstat, i, len);

                   out.print(   dts+"\t\t"+cntx.get((int)item).title+" "
                                +String.format( "%12d; diff: %12d", 
                                                prevVal, 
                                                prevVal != 0 ? currVal - prevVal : -1
                                              ) 
                           );
                   cntx.get( (int)item).val = currVal;
                   //cntx.put((int)item, v);
                }

                i+=len;
            }
            out.println("\n");
            Thread.sleep(5000);

        } catch (GDSException e)   {
            break;
        }
      } // while (true)

      out.println ("\n"+df.format( System.currentTimeMillis() )+" detaching from database. . .");
      gdso.iscDetachDatabase(dh);
      out.println (df.format( System.currentTimeMillis() )+" detached.");
    }
    catch (GDSException e) {
        out.println(df.format( System.currentTimeMillis() )+" EXCEPTION: SQLSTATE="+e.getSQLState()+", fb_error="+e.getFbErrorCode()+", msg="+e.getMessage());
    }
  }
  
  static class StatValue {
      //int isc_const;
      String title;
      int val=0;
      
      StatValue(String s) { title=s; }
      StatValue(String s, int rPad) { title=String.format("%1$-" + rPad + "s", s); }
      
      @Override
      public String toString() { return title; }
      // contract for Map or Set:
      @Override
      public boolean equals(Object o) {
          return (o instanceof StatValue)
                  && ((StatValue)o).title.equalsIgnoreCase(title);
      }
     
      @Override
      public int hashCode() {
          return title.hashCode();
      }
  }
}
