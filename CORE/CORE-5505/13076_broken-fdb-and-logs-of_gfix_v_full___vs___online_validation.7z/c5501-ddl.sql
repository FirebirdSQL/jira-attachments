set list on;

shell del C:\MIX\firebird\QA\fbt-repo\tmp\c5501.fdb 2>nul;
create database 'localhost:C:\MIX\firebird\QA\fbt-repo\tmp\c5501.fdb'; -- page_size 8192;

alter database drop linger;
commit;

/*
create table test(s varchar(1000), b blob);
insert into test(s, b) 
select rpad( '',1000, uuid_to_char(gen_uuid()) ), rpad('', 10000, 'qwertyuioplkjhgfdsazxcvbnm0987654321')
from rdb$types
rows 100;
*/

create table test(s varchar(1000));
commit;

set count on;
insert into test(s) 
select rpad( '',1000, uuid_to_char(gen_uuid()) )
from rdb$types
rows 100;
set count off;
commit;

set echo on;

select rdb$linger from rdb$database;

show table test;

select count(*) from test;


