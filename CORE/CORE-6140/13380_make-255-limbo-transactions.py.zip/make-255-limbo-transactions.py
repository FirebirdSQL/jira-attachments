from __future__ import print_function
import os
import sys
import time
import subprocess
import fdb
from fdb import services

# Example how to run: 
###########################################################
# python make-limbo-transactions.py C:\FB\30SS\fbclient.dll 
###########################################################

print( 'fdb version: ', fdb.__version__ )

FBCLNT=sys.argv[1]

# Add path to client library at the head of PATH list, otherwise Services.connect()
# will try to work with probably another client and will fail:
os.environ["PATH"] = ';'.join( (os.path.dirname( FBCLNT ), os.environ["PATH"] ) )


#################################
DBPATH=r'C:\TEMP'
#DBPATH=r'C:\FBTESTING\qa\misc'
DBUSER='SYSDBA'
DBPSWD='masterkey'

DBNAME_A = DBPATH + r'\c5930_a.fdb'
DBNAME_B = DBPATH + r'\c5930_b.fdb'
LIMBO_COUNT = 255
##################################

if os.path.isfile(DBNAME_A):
    os.remove(DBNAME_A)
if os.path.isfile(DBNAME_B):
    os.remove(DBNAME_B)
 
svc = services.connect(host='localhost', user=DBUSER, password=DBPSWD)
 
con1 = fdb.create_database( dsn = 'localhost:' + DBNAME_A, fb_library_name = FBCLNT, user=DBUSER, password=DBPSWD )
con2 = fdb.create_database( dsn = 'localhost:' + DBNAME_B, fb_library_name = FBCLNT, user=DBUSER, password=DBPSWD )

print( con1.firebird_version )
con1.execute_immediate( 'create table test(id int, x int, constraint test_pk primary key(id) using index test_pk)' )
con1.commit()

con2.execute_immediate( 'create table test(id int, x int, constraint test_pk primary key(id) using index test_pk)' )
con2.commit()

con1.close()
con2.close()

cgr = fdb.ConnectionGroup()

con1 = fdb.connect( dsn = 'localhost:' + DBNAME_A, fb_library_name = FBCLNT, user=DBUSER, password=DBPSWD )
con2 = fdb.connect( dsn = 'localhost:' + DBNAME_B, fb_library_name = FBCLNT, user=DBUSER, password=DBPSWD )

cgr.add(con1)
cgr.add(con2)
 
# https://pythonhosted.org/fdb/reference.html#fdb.TPB
# https://pythonhosted.org/fdb/reference.html#fdb.Connection.trans
 
custom_tpb = fdb.TPB()
custom_tpb.access_mode = fdb.isc_tpb_write
custom_tpb.isolation_level = (fdb.isc_tpb_read_committed, fdb.isc_tpb_rec_version)
#custom_tpb.lock_timeout = 3
custom_tpb.lock_resolution = fdb.isc_tpb_nowait

tx1_list=[]
for i in range(0, LIMBO_COUNT):
   tx1_list += [ con1.trans( default_tpb = custom_tpb ) ]


cur_list=[]
for i, tx1 in enumerate(tx1_list):
    tx1.begin()
    ##cur_list += [ tx1.cursor() ]
    ##cur_list[-1].execute( "insert into test(id, x) values( ?, ? )", ( i, i*11111 ) )
    cur=tx1.cursor()
    cur.execute( "insert into test(id, x) values( ?, ? )", ( i, i*11111 ) )
    cur.close()
    tx1.prepare()


tx2 = con2.trans( default_tpb = custom_tpb )
cur2=tx2.cursor()
cur2.execute( "insert into test(id, x) values( ?, ? )", (-2, -2222222) )
cur2.close()

#for cur1 in cur_list:
#    cur1.close()

#for tx1 in tx1_list:
#    tx1.prepare()

tx2.prepare()
tx2.commit()

svc.shutdown( DBNAME_A, services.SHUT_FULL, services.SHUT_FORCE, 0)

print('Database ',DBNAME_A,' is in full shutdown state now.')

for tx1 in tx1_list:
    try:
        tx1.close()
    except:
        pass

# Result for DBNAME_A when it will be returned online 
# and we query table TEST:
#     Statement failed, SQLSTATE = HY000
#     record from transaction <N> is stuck in limbo
# See also "gfix -list <disk>\path\to\dbname_a"

#cgr.disband()
cgr.clear()
print('ConnectionGroup instance has been cleared.')

svc.bring_online( DBNAME_A, services.SHUT_NORMAL )
print('Database ',DBNAME_A,' is in ONLINE state now.')

print('Trying to get list of limbo Tx.')
limbo_tx = svc.get_limbo_transaction_ids(database = DBNAME_A)
print('len(limbo_tx)=',len(limbo_tx))
print('--------- start data from get_limbo_transaction_ids -----------')
for i in limbo_tx:
    print('Found Tx in limbo, ID:', i)
print('--------- finish data from get_limbo_transaction_ids -----------')
print('')

svc.close()
con2.close()

try:
    # This will fail for sure because DB state was changed to full shutdown
    con1.close()
except:
    pass

gfix_bin=os.path.join( os.path.dirname( FBCLNT ), 'gfix')
print('Result of ', gfix_bin, ' -list ', DBNAME_A, ':')
print('--------- start gfix output -----------')
subprocess.call( [ gfix_bin, '-list', DBNAME_A  ] )
print('---------- finish gfix output ---------')
print('')
print('Bye-bye from Python.')
exit(0)
