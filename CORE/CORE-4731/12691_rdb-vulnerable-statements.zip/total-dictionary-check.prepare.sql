set echo on;
drop user tmp$maverick;
commit;
create user tmp$maverick password '123';
commit;
revoke all on all from tmp$maverick;
grant create table to tmp$maverick;
grant drop any table to tmp$maverick;
grant alter any table to tmp$maverick;
commit;

