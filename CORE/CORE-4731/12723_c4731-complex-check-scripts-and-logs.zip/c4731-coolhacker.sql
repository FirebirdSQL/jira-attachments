drop user coolhacker;
commit;
create user coolhacker password '123';
commit;
revoke all on all from coolhacker;
commit;
grant create table to coolhacker;
grant alter any table to coolhacker;
commit;

recreate table vulnerable_on_sys_tables(
    sys_table rdb$relation_name, 
    vulnerable_type char(1),
    vulnerable_gdscode int,
    vulnerable_sqlcode int,
    vulnerable_sqlstate char(5),
    vulnerable_expr varchar(1024)
);
commit;

set list on;
set autoddl off;
commit;

set term ^;
execute block returns (
    rel_name varchar(31) character set unicode_fss collate unicode_fss,
    vulnerable_expr varchar(1024) character set unicode_fss collate unicode_fss
) as
    declare v_dbname type of column mon$database.mon$database_name;
    declare v_usr type of column sec$users.sec$user_name = 'coolhacker';
    declare v_pwd varchar(20) = '123';
    declare v_fk1 varchar(8192) character set unicode_fss collate unicode_fss;
    declare v_fks varchar(8192) character set unicode_fss collate unicode_fss;
    declare v_mf varchar(8192) character set unicode_fss collate unicode_fss;
begin

    v_dbname = 'localhost:' ||  rdb$get_context('SYSTEM','DB_NAME');

    for
        with
        a as (
        select
            lower(rc.rdb$relation_name) tab_name
            --,rc.rdb$constraint_name cnt_name
            ,lower(rc.rdb$index_name) idx_name
            --,rc.rdb$constraint_type
            --,ri.rdb$index_id
            ,rs.rdb$field_position fld_pos
            ,lower(rs.rdb$field_name) fld_name
            --,rf.rdb$field_name
            ,rf.rdb$field_source fld_src
            ,case ff.rdb$field_type
                when 7 then 'smallint'
                when 8 then 'integer'
                when 10 then 'float'
                when 14 then 'char' --(' || cast(cast(f.rdb$field_length/iif(ce.rdb$character_set_name=upper('utf8'),4,1) as int) as varchar(5)) || ')'
                when 16 then -- dialect 3 only
                  case ff.rdb$field_sub_type
                    when 0 then 'bigint'
                    when 1 then 'numeric' --(15,' || cast(-f.rdb$field_scale as varchar(6)) || ')'
                    when 2 then 'decimal' --(15,' || cast(-f.rdb$field_scale as varchar(6)) || ')'
                    else 'unknown'
                  end
                when 12 then 'date'
                when 13 then 'time'
                when 27 then -- dialect 1 only
                  case ff.rdb$field_scale
                    when 0 then 'double precision'
                    else 'numeric' -- (15,' || cast(-f.rdb$field_scale as varchar(6)) || ')'
                  end
                when 35 then iif(m.dia=1, 'date', 'timestamp')
                when 37 then 'varchar' -- (' || cast(cast(f.rdb$field_length/iif(ce.rdb$character_set_name=upper('utf8'),4,1) as int) as varchar(5)) || ')'
                when 261 then 'blob' -- sub_type ' || f.rdb$field_sub_type || ' segment size ' || f.rdb$segment_length
                else 'unknown'
            end as fld_base_type
           --,ff.rdb$field_length fld_len
           ,cast(ff.rdb$field_length / iif(ce.rdb$character_set_name in ( upper('utf8'), upper('un~icode_fss') ), 4, 1) as int) fld_len
           ,lower(ce.rdb$character_set_name) cset
           ,lower(co.rdb$collation_name) coll
           ,dense_rank()over(partition by rc.rdb$relation_name order by rc.rdb$index_name, rs.rdb$field_position) dr1
           ,dense_rank()over(partition by rc.rdb$relation_name, rc.rdb$index_name order by rs.rdb$field_position) dr2
           ,dense_rank()over(partition by rc.rdb$relation_name, rc.rdb$index_name order by rs.rdb$field_position desc) dr2d
           ,count(*)over(partition by rc.rdb$relation_name) fld_cnt
        from (select m.mon$sql_dialect as dia from mon$database m) m
        cross join rdb$relation_constraints rc
        join rdb$relations rr on rc.rdb$relation_name = rr.rdb$relation_name
        join rdb$indices ri on rc.rdb$index_name = ri.rdb$index_name
        join rdb$index_segments rs on ri.rdb$index_name = rs.rdb$index_name
        left join rdb$relation_fields rf on rc.rdb$relation_name = rf.rdb$relation_name and rs.rdb$field_name = rf.rdb$field_name
        left join rdb$fields ff on rf.rdb$field_source = ff.rdb$field_name
        left join rdb$collations co on ff.rdb$character_set_id=co.rdb$character_set_id and ff.rdb$collation_id=co.rdb$collation_id
        left join rdb$character_sets ce on co.rdb$character_set_id=ce.rdb$character_set_id
        where
            --rc.rdb$relation_name --starting with upper('rdb$')
            coalesce(rr.rdb$system_flag,0) is distinct from 0 -- ###  S Y S T E M    t a b l e s  ###
            and rr.rdb$relation_type = 0 -- exclude: views, GTTs, external tables
            and rr.rdb$relation_name not starting with 'MON$'
        )
       ,b as (
            select
                tab_name,
                idx_name,
                fld_pos,
                fld_name,
                fld_src,
                fld_base_type,
                fld_len,
                cset,
                coll,
                dr1,
                dr2,
                dr2d,
                fld_cnt,
                trim( replace( fld_name, '$','_') )||' '||trim(fld_base_type)
                ||iif( fld_base_type in ('char','varchar', 'numeric'),
                      '(' || fld_len || ')' || iif( fld_base_type='numeric', '', ' '||trim(coalesce(' character set '||cset, ''))||' '||trim(coalesce(' collate '||coll, '')))
                      ,''
                     ) fld_full
            from a
       )
       ,c as (
            select
                tab_name,
                idx_name,
                fld_pos,
                fld_name,
                fld_src,
                fld_base_type,
                fld_len,
                cset,
                coll,
                dr1,
                dr2,
                dr2d,
                fld_cnt,
                fld_full,
                (select list(distinct fld_full) from b x where x.tab_name = b.tab_name) fld_list
            from b
       )
    select *
    from c
    order by tab_name, idx_name, dr1

    as cursor c
    do begin
       if ( c.dr1 = 1 ) then
       begin
           vulnerable_expr = 'recreate table ' || trim(replace(c.tab_name,'$','_')) || '(' || c.fld_list;
           v_fks = '';
       end

       if ( c.dr2 = 1 ) then begin
           v_fk1 = '';
           v_mf = '';
       end

       if ( c.dr2 = 1 ) then
           v_fk1 = v_fk1 || '  ,constraint fk_'
                         || lower(trim(replace(c.idx_name,'$','_')))
                         || '   foreign key(';

       v_fk1 = v_fk1 || iif( c.dr2 = 1, '', ', ') || trim( replace( c.fld_name, '$', '_' ) );
       v_mf = v_mf || iif( c.dr2 = 1, '', ', ') || trim( c.fld_name );

       if ( c.dr2d = 1 ) then
       begin
           v_fk1 = v_fk1 ||  ')' || '   references ' || trim(lower(c.tab_name)) || '(' || v_mf || ')';
           v_fks = v_fks || v_fk1;
       end

       if ( c.dr1 = c.fld_cnt ) then
       begin
           vulnerable_expr = vulnerable_expr || v_fks || ');';

           rel_name = c.tab_name;

           -- execute statement vulnerable_expr;

           execute statement vulnerable_expr -- this statement ALWAYS should FAIL!
           on external (v_dbname)
           as user (v_usr) password (v_pwd);

           -- this statement must NOT occur at all. If this record would be added then its mean
           -- then RDB table can be DIRECTLY modified by user!
           insert into vulnerable_on_sys_tables( sys_table, vulnerable_type, vulnerable_expr)
                                         values( :rel_name, 'R',            :vulnerable_expr);

           suspend;

        when any do
            begin
               insert into vulnerable_on_sys_tables(sys_table, vulnerable_type, vulnerable_gdscode, vulnerable_sqlcode, vulnerable_sqlstate, vulnerable_expr)
               values( :rel_name, 'R', gdscode, sqlcode, sqlstate, :vulnerable_expr);
            end
       end
    end
end
^

-------------------------

execute block returns(
    rel_name varchar(31) character set unicode_fss collate unicode_fss,
    vulnerable_expr varchar(1024)
) as
    declare v_dbname type of column mon$database.mon$database_name;
    declare v_usr type of column sec$users.sec$user_name = 'coolhacker';
    declare v_pwd varchar(20) = '123';
    declare v_connect varchar(255);
    declare vulnerable_type char(1);
    declare v_exists smallint;
    declare v_sign smallint = 0;
begin

    v_dbname = 'localhost:' ||  rdb$get_context('SYSTEM','DB_NAME');

    for
        with recursive
        c0 as(
        select
            r.rdb$relation_name rel_name
            ,rf.rdb$field_position fld_pos
            ,rf.rdb$field_name fld_name
            ,case f.rdb$field_type
                when 7 then 'smallint'
                when 8 then 'integer'
                when 10 then 'float'
                when 14 then 'char' --(' || cast(cast(f.rdb$field_length/iif(ce.rdb$character_set_name=upper('utf8'),4,1) as int) as varchar(5)) || ')'
                when 16 then -- dialect 3 only
                  case f.rdb$field_sub_type
                    when 0 then 'bigint'
                    when 1 then 'numeric' --(15,' || cast(-f.rdb$field_scale as varchar(6)) || ')'
                    when 2 then 'decimal' --(15,' || cast(-f.rdb$field_scale as varchar(6)) || ')'
                    else 'unknown'
                  end
                when 12 then 'date'
                when 13 then 'time'
                when 27 then -- dialect 1 only
                  case f.rdb$field_scale
                    when 0 then 'double precision'
                    else 'numeric' -- (15,' || cast(-f.rdb$field_scale as varchar(6)) || ')'
                  end
                when 35 then iif(m.dia=1, 'date', 'timestamp')
                when 37 then 'varchar' -- (' || cast(cast(f.rdb$field_length/iif(ce.rdb$character_set_name=upper('utf8'),4,1) as int) as varchar(5)) || ')'
                when 261 then 'blob' -- sub_type ' || f.rdb$field_sub_type || ' segment size ' || f.rdb$segment_length
                else 'unknown'
            end as fld_base_type
            ,iif( coalesce(rf.rdb$null_flag,0) = 0, 1, 0) fld_nullable
            --,rf.rdb$field_source
            --,rf.rdb$field_id
            --,rf.rdb$null_flag
            --,rf.rdb$collation_id
            --,f.rdb$field_length
            --,f.rdb$field_scale
            --,f.rdb$field_precision
            --,f.rdb$field_type
            --,f.rdb$field_sub_type
            --,f.rdb$character_set_id
            --,f.rdb$collation_id
            --,f.rdb$character_length
            ,count(*)over(partition by r.rdb$relation_name) fld_count
            from (select m.mon$sql_dialect as dia from mon$database m) m
            join rdb$relations r on 1=1
            join rdb$relation_fields rf on r.rdb$relation_name = rf.rdb$relation_name
            join rdb$fields f on rf.rdb$field_source = f.rdb$field_name
            left join rdb$collations co on f.rdb$character_set_id=co.rdb$character_set_id and f.rdb$collation_id=co.rdb$collation_id
            left join rdb$character_sets ce on co.rdb$character_set_id=ce.rdb$character_set_id
            where
                coalesce(r.rdb$system_flag,0) is distinct from 0 --------------- ###   o n l y    S Y S T E M    t a b l e s  ###
                and r.rdb$relation_type = 0 -- exclude: views, GTTs, external tables
                and r.rdb$relation_name not starting with 'MON$'
                and f.rdb$computed_source is null ------------------------------ ### exclude COMPUTED BY fields! ###
            order by rel_name,fld_pos
        )
        ,c1 as (
            select
                rel_name
                ,fld_pos
                ,fld_name
                ,fld_base_type
                ,fld_nullable
                ,fld_count
                -- these are values which we'll try to write in insert or update statements
                -- if corresponding fields are NOT null:
                ,decode( fld_base_type,
                         'smallint',  '32767',
                         'integer', '2147483647',
                         'bigint', '9223372036854775807',
                         'float', '0e0',
                         'numeric', '0.00',
                         'decimal', '0.00',
                         'double precision', '0e0',
                         'date', 'current_date',
                         'time', 'current_time',
                         'timestamp', 'current_timestamp',
                         'char', '''C''',
                         'varchar', '''V''',
                         'blob', '''test_for_blob'''
                      ) ins_default
            from c0
        )
        --select * from c1
        
        ,c2 as (
            select
                rel_name
                ,fld_pos
                ,fld_name
                ,fld_base_type
                ,fld_nullable
                ,fld_count
                ,ins_default
                ,cast( 'select ' || trim(fld_name)
                       || iif( c1.fld_pos+1 = c1.fld_count, ' from '||trim(rel_name)||' rows 1 with lock;', '')  as varchar(1024)
                     ) as lok_stt
                ,cast( 'insert into '
                       || trim(rel_name)
                       || '('
                       || trim(fld_name)
                       || iif( c1.fld_pos+1 = c1.fld_count, ')', '')  as varchar(1024)
                     )  as ins_stt
                ,cast( 'values('
                       || trim(iif(fld_nullable=1, 'null', ins_default))
                       || iif( c1.fld_pos+1 = c1.fld_count, ');', '') as varchar(1024)
                     ) as ins_val
                ,cast( 'update '
                       || trim(rel_name)
                       || ' set '||trim(fld_name)
                       || '='||trim(iif(fld_nullable=1, 'null', ins_default))
                       || trim(trailing from iif( c1.fld_pos+1 = c1.fld_count, ' rows 1', ''))
                       || iif( c1.fld_pos+1 = c1.fld_count, ';', '') as varchar(1024)
                     ) upd_stt
                ,cast( 'delete from ' || trim(rel_name) || iif( c1.fld_pos+1 = c1.fld_count, ';', '') as varchar(1024) ) del_stt
                ,cast( 'alter table '|| trim(rel_name) || ' add rdb$my_field char(31)'  as varchar(1024)) add_fld
                ,cast( 'alter table '|| trim(rel_name) || ' alter '||trim(fld_name)|| ' null'  as varchar(1024)) set_nul
                ,cast( 'alter table '|| trim(rel_name) || ' add constraint '||left(trim(fld_name)||'_dummy',31) ||' check ('||trim(fld_name) ||' is not distinct from '||trim(fld_name)||')'  as varchar(1024)) set_chk
                ,cast( 'alter table '|| trim(rel_name) || ' alter '||trim(fld_name)|| ' set default '||ins_default as varchar(1024)) set_def
                ,cast( 'alter table '|| trim(rel_name) || ' drop '||trim(fld_name) as varchar(1024)) kil_fld
                ,cast( 'drop table '|| trim(rel_name) as varchar(1024)) kil_tab
                ,iif( c1.fld_pos+1 = c1.fld_count, 1, 0) cmd_end
            from c1
            where fld_pos = 0
        
            UNION ALL
        
            select
                c1.rel_name
                ,c1.fld_pos
                ,c1.fld_name
                ,c1.fld_base_type
                ,c1.fld_nullable
                ,c1.fld_count
                ,c1.ins_default
                ,c2.lok_stt || ', ' || trim(c1.fld_name) || iif( c1.fld_pos+1 = c1.fld_count, ' from '||trim(c2.rel_name)||' rows 1 with lock;', '')
                ,c2.ins_stt || ', ' || trim(c1.fld_name) || iif( c1.fld_pos+1 = c1.fld_count, ')', '')
                ,trim(c2.ins_val) || ', ' || trim(iif(c1.fld_nullable=1, 'null', c1.ins_default)) || iif( c1.fld_pos+1 = c1.fld_count, ');', '')
                ,trim(c2.upd_stt)
                 || ', '|| trim(c1.fld_name)
                 || '=' || trim(iif(c1.fld_nullable=1, 'null', c1.ins_default))
                 || trim(trailing from iif( c1.fld_pos+1 = c1.fld_count, ' rows 1', ''))
                 || iif( c1.fld_pos+1 = c1.fld_count, ';', '')
                ,trim(c2.del_stt) || iif( c1.fld_pos+1 = c1.fld_count, ';', '')
                ,trim(c2.add_fld) || iif( c1.fld_pos+1 = c1.fld_count, ';', '')
                ,trim(c2.set_nul) || iif( c1.fld_pos+1 = c1.fld_count, ';', '')
                ,trim(c2.set_chk) || iif( c1.fld_pos+1 = c1.fld_count, ';', '')
                ,trim(c2.set_def) || iif( c1.fld_pos+1 = c1.fld_count, ';', '')
                ,trim(c2.kil_fld) || iif( c1.fld_pos+1 = c1.fld_count, ';', '')
                ,trim(c2.kil_tab) || iif( c1.fld_pos+1 = c1.fld_count, ';', '')
                ,iif( c1.fld_pos+1 = c1.fld_count, 1, 0) cmd_end
            from  c2 join c1 on c2.rel_name = c1.rel_name and c1.fld_pos = c2.fld_pos + 1
        )
        --select * from c2
        ,c3 as (
            select
                c2.rel_name --, c2.ins_stt || ' ' ||c2.ins_val insert_statement, c2.upd_stt update_statement, c2.del_stt delete_statement
               ,n.op
               ,decode(
                    n.op
                    ,'I' ,c2.ins_stt || ' ' ||c2.ins_val
                    ,'L' ,c2.lok_stt
                    ,'U' ,c2.upd_stt
                    ,'D' ,c2.del_stt
                    ,'A' ,c2.add_fld
                    ,'N' ,c2.set_nul
                    ,'C' ,c2.set_chk
                    ,'F' ,c2.set_def
                    ,'K' ,c2.kil_fld
                    ,'Z' ,c2.kil_tab
                ) vulnerable_expr
            from c2
            cross join(
                select 'I' op, 10 as ord_pos from rdb$database -- DML, insert
                union all select 'L', 20 from rdb$database -- DML, select WITH LOCK
                union all select 'U', 30 from rdb$database -- DML, update
                union all select 'D', 40 from rdb$database -- DML, delete
                union all select 'A', 50 from rdb$database -- DDL, add column
                union all select 'N', 60 from rdb$database -- DDL, alter column set NULL flag
                union all select 'C', 65 from rdb$database -- DDL, alter column add new constraint on it
                union all select 'F', 70 from rdb$database -- DDL, alter column set DEFAULT value
                union all select 'K', 80 from rdb$database -- DDL, drop column
                union all select 'Z', 90 from rdb$database -- DDL, drop RDB$-table
            ) n
            where cmd_end=1
            order by rel_name, n.ord_pos
        )
        ,r1 as(
            -- Add statements which will try to drop constrains, starting from FK:
            select rc.rdb$relation_name rel_name, rc.rdb$constraint_name cnt_name, rc.rdb$constraint_type cnt_type
            from rdb$relation_constraints rc
            where rc.rdb$relation_name starting with 'RDB$'
            order by decode(rc.rdb$constraint_type, 'FOREIGN KEY', 0, 1)
        )
        ,r2 as (
            select
                 trim(r1.rel_name) as rel_name
                ,'R' as op
                ,'alter table '||trim(r1.rel_name)||' drop constraint '||trim(r1.cnt_name)||';' as vulnerable_expr
            from r1
        )

        select rel_name, op, vulnerable_expr
        from c3

        UNION ALL

        select rel_name, op, vulnerable_expr
        from r2

        into rel_name, vulnerable_type, vulnerable_expr
    do
    begin
        if ( vulnerable_type in ('L', 'U', 'D') ) then
        begin
            v_exists = null;
            execute statement ( 'select 1 as id from '||rel_name||' rows 1'  ) into v_exists;
        end

        if ( vulnerable_type in ('I', 'A', 'K', 'Z') or v_exists = 1 ) then
        begin

            -- #########################################################################################################
            -- ###   A T T E M P T   O F   D I R E C T    W R I T E   T O    R D B $   o r   S E C$    T A B L E S   ###
            -- #########################################################################################################

            -- execute statement vulnerable_expr;

            execute statement vulnerable_expr -- this statement ALWAYS should FAIL!
            on external (v_dbname)
            as user (v_usr) password (v_pwd);


            -- this statement must NOT occur at all. If this record would be added then its mean
            -- then RDB table can be DIRECTLY modified by user!
            insert into vulnerable_on_sys_tables(sys_table, vulnerable_type, vulnerable_expr) values( :rel_name, :vulnerable_type, :vulnerable_expr);
            
            if (v_sign = 0) then 
            begin
                vulnerable_expr = 'set count on; set echo on;';
                v_sign = 1;
                suspend;
            end

            suspend;

        when any do
            begin
               insert into vulnerable_on_sys_tables(sys_table, vulnerable_type, vulnerable_gdscode, vulnerable_sqlcode, vulnerable_sqlstate, vulnerable_expr)
               values( :rel_name, :vulnerable_type, gdscode, sqlcode, sqlstate, :vulnerable_expr);
            end
        end
    end

end
^
set term ;^

select count(*) as count_of_passed
from vulnerable_on_sys_tables v 
where v.vulnerable_gdscode is null;

select 
    sys_table, 
    vulnerable_gdscode, 
    vulnerable_expr as blocked_expr
from vulnerable_on_sys_tables;

rollback;
