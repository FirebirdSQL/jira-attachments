/* This is the original statement. If we run in FB 1.5.3 it runs fast, and correct.
   If we change the server to FB 2 RC5 there is returning with nothing

   In 1.5 the plan will be:

   PLAN SORT ((RES INDEX (FK_RESERVATIONS_ROOMS, RESERVATIONS_ARRIVE, RESERVATIONS_DEPARTURE)))
   PLAN (ROM NATURAL)

   In 2.0:

   PLAN SORT ((RES INDEX (RESERVATIONS_ARRIVE, RESERVATIONS_DEPARTURE)))
   PLAN (ROM NATURAL)

   The FK_RESERVATIONS_ROOMS index can not use in FB2.

*/

select
  ROM.ROOM
from
  ROOMS ROM
where
  ROM.ROOM not in (select
                     distinct RES.ROOM
                   from
                     RESERVATIONS RES
                   where
                     RES.ARRIVE < '2006.10.20' and
                     RES.DEPARTURE > '2006.10.10'
                   )

/*

  If we change a littlebit. The result will be correct in FB2 too.

*/

select
  ROM.ROOM
from
  ROOMS ROM
where
  ROM.ROOM not in (select
                     distinct RES.ROOM
                   from
                     RESERVATIONS RES
                   where
                     RES.ROOM is not null and
                     RES.ARRIVE < '2006.10.20' and
                     RES.DEPARTURE > '2006.10.10'
                   )


/*
  If we change the subselect to exists. The query in the FB 1.5 is still fast,
  but in the FB 2 is still slower more then three times.
*/

select
  ROM.ROOM
from
  ROOMS ROM
where
  not exists (select
                     first 1 0
                   from
                     RESERVATIONS RES
                   where
                     RES.ROOM = ROM.ROOM and
                     RES.ARRIVE < '2006.10.20' and
                     RES.DEPARTURE > '2006.10.10'
                   )
