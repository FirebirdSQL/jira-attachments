set names utf8;
shell del C:\MIX\firebird\QA\fbt-repo\tmp\c1178-utf8.fdb 2>nul;
create database 'localhost/3333:C:\MIX\firebird\QA\fbt-repo\tmp\c1178-utf8.fdb' default character set utf8;
commit;

recreate table test_utf(s varchar(10) character set utf8 constraint test_utf_pk primary key using index test_utf_pk collate unicode_ci_ai);
commit;

set echo on;

insert into test_utf values('ñ');
insert into test_utf values('.ñ');
insert into test_utf values('..ñ');
insert into test_utf values('ñ.');
insert into test_utf values('ñ..');
insert into test_utf values('n');
insert into test_utf values('N');


insert into test_utf values('à');
insert into test_utf values('.à');
insert into test_utf values('..à');
insert into test_utf values('à.');
insert into test_utf values('à..');
insert into test_utf values('a');
insert into test_utf values('A');

insert into test_utf values('ê');
insert into test_utf values('.ê');
insert into test_utf values('..ê');
insert into test_utf values('ê.');
insert into test_utf values('ê..');
insert into test_utf values('e');
insert into test_utf values('E');

select * from test_utf;
