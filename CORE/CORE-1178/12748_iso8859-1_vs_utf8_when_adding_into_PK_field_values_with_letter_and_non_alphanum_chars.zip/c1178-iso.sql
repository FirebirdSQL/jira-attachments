set names iso8859_1;
shell del C:\MIX\firebird\QA\fbt-repo\tmp\c1178.fdb 2>nul;
create database 'localhost/3333:C:\MIX\firebird\QA\fbt-repo\tmp\c1178.fdb' default character set iso8859_1;
commit;

create collation coll_fr for iso8859_1 from external ('FR_FR') case insensitive accent insensitive;
create collation coll_es for iso8859_1 from external ('ES_ES') case insensitive accent insensitive;
create collation coll_pt for iso8859_1 from external ('PT_PT') case insensitive accent insensitive;

recreate table test_es(s varchar(10) character set iso8859_1 constraint test_es_pk primary key using index test_es_pk collate coll_es);
recreate table test_fr(s varchar(10) character set iso8859_1 constraint test_fr_pk primary key using index test_fr_pk collate coll_fr);
recreate table test_pt(s varchar(10) character set iso8859_1 constraint test_pt_pk primary key using index test_pt_pk collate coll_pt);
commit;


set echo on;

insert into test_es values('�');
insert into test_es values('.�');
insert into test_es values('..�');
insert into test_es values('�.');
insert into test_es values('�..');
insert into test_es values('n');
insert into test_es values('N');
select * from test_es;


insert into test_fr values('�');
insert into test_fr values('.�');
insert into test_fr values('..�');
insert into test_fr values('�.');
insert into test_fr values('�..');
insert into test_fr values('a');
insert into test_fr values('A');

select * from test_fr;

insert into test_pt values('�');
insert into test_pt values('.�');
insert into test_pt values('..�');
insert into test_pt values('�.');
insert into test_pt values('�..');
insert into test_pt values('e');
insert into test_pt values('E');

select * from test_pt;
