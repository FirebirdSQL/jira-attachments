--recreate global temporary table gtt1(s varchar(2000) unique) on commit preserve rows;
--commit;

set list on;
select current_transaction from rdb$database;
set term ^;
execute block as
  declare n int = 100000;
  declare i int;
begin
  while (n>0) do
      in autonomous transaction do
      select :n-1 from rdb$database into n
  ;
end
^
set term ;^

