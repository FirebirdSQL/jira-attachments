
/*!
Extracts the specified amount of the first characters from a string.

Declaration in Firebird:
DECLARE EXTERNAL FUNCTION MF_LEFTCHARS
INTEGER,
CSTRING(100) NULL
RETURNS CSTRING(100) FREE_IT
ENTRY_POINT 'MF_LeftChars' MODULE_NAME 'MFDBFunc';

\return the first characters or NULL.
*/
char* __stdcall MF_LeftChars(
	IN long* plChars,  //!< The number of characters to extract.
	IN const char* pszValue  //!< Source string.
)
{
	char* pszSubstring = NULL;

	// NOTE: This UDF must behave identically
	//       to the MF_LeftChars function in CMF_DataFunctionCall!

	// Process non-NULL values only.
	if( plChars != NULL &&
		pszValue != NULL )
	{
		// Not NULL.

		// The number of characters must be valid.
		if( *plChars < 0 )
			*plChars = 0;
		
		// Convert from UTF-8 to Windows Unicode.
		// The buffer size of as many widechars as UTF-8 chars is always sufficient
		// because a single UTF-8 char never translates to multiple 16-bit chars ( surrogates ).
		// Two or three UTF-8 chars might represent a 16-bit surrogate pair, but that is then
		// already enough space in 16-bit chars.
		ULONG ulLength = strlen( pszValue );
		wchar_t* pwszValue = ( wchar_t* )malloc( ( ulLength + 1 ) * sizeof( wchar_t ) );
		if( pwszValue )
		{
			// Convert from UTF-8 to Windows Unicode.
			// NOTE: We advise MultiByteToWideChar to copy a terminating NULL character, 
			// too, so pwszValue should be NULL-terminated. This also works correctly when 
			// the input string is an empty string.
			int iWritten = MultiByteToWideChar( CP_UTF8, 0, pszValue, ulLength + 1, pwszValue, ulLength + 1 );
			if( iWritten )
			{
				// Determine the number of characters to copy.
				ULONG ulCharsToCopy = ( ULONG )( *plChars );
				ulLength = wcslen( pwszValue );
				if( ulLength < ulCharsToCopy )
					ulCharsToCopy = ulLength;

				// Convert back to UTF-8 (in the worst case, every WCHAR is translated into 3 bytes).
				int iBufferSize = ( 3 * ulCharsToCopy ) + 1;
				pszSubstring = ( char* )ib_util_malloc( iBufferSize );
				if( pszSubstring )
				{
					// Before copying, ensure that the source string is NULL-terminated.
					// It necessarily isn't when the source string is longer than 
					// the number of characters to extract.
					pwszValue[ ulCharsToCopy ] = 0;

					// Terminate the target string before conversion to prepare for
					// a possible (although extremely unlikely) failure of WideCharToMultiByte.
					*pszSubstring = NULL;
					if( WideCharToMultiByte( CP_UTF8, 0, pwszValue, -1, pszSubstring, iBufferSize, NULL, NULL ) )
					{
						// OK
					}

				}  // end if ( pszSubstring )

			}  // end if ( written )

			free( pwszValue ); pwszValue = NULL;

		}  // end if ( pwszValue )

	}  // end if ( not NULL )

	return pszSubstring;
}