select 
    'M_ ' || current_time as Now_,
    MON$STAT_ID as STAT_ID,
    MON$STAT_GROUP as STAT_GR,
    MON$MEMORY_USED as MEM_USED,
    MON$MEMORY_ALLOCATED as MEM_ALLOC
  from MON$MEMORY_USAGE
  where MON$MEMORY_USED=(select max(MON$MEMORY_USED) from MON$MEMORY_USAGE);
commit;