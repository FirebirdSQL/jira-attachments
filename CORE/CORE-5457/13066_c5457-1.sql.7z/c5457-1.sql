set bail on;
set echo on;
set term  ^;
create or alter procedure sp_test(id bigint) returns(val bigint) as begin 
  val = 0;
  suspend;
end
^
set term ;^
commit;

recreate table test (
    id bigint not null,
    --txt varchar(80),
    val bigint computed by (null),
    primary key (id)
);
commit;

set term ^;
create or alter procedure sp_test (id bigint) returns (val bigint) as 
begin 
  val = id * 7;
  suspend; 
end 
^
set term ;^
commit;

alter table test 
      alter val type bigint computed by (
          ( select val from sp_test(test.id) )
      )
;

commit;

insert into test(id) select row_number()over() from rdb$types rows 10;
commit;

---------------------------------------

select count(*), sum(val) from test;

set term ^;
alter procedure sp_test (id bigint) returns (val bigint) as 
begin
  val =  13 * id;
  suspend;
end
^
set term ;^

select count(*), sum(val) from test;
commit;

select count(*), sum(val) from test;

quit;



/************************************************************************
WI-V3.0.2.32683 07-feb-2017: ok
log:
CSPROG	Tue Feb 07 10:05:02 2017
	Modifying procedure SP_TEST which is currently in use by active user requests

===========================================

WI-T4.0.0.463, 06-dec-2016, SuperClassic
WI-T4.0.0.503, 18-jan-2017 Classic:
Statement failed, SQLSTATE = 2F000
Cannot execute procedure ��,����� of the unimplemented package


WI-T4.0.0.522, 03-feb-2017 SS/SC/CS:
Statement failed, SQLSTATE = 08006
Error reading data from the connection.

firebird.log:
CSPROG	Tue Feb 07 10:03:08 2017
	Modifying procedure SP_TEST which is currently in use by active user requests


CSPROG	Tue Feb 07 10:03:08 2017
	INET/inet_error: read errno = 10054, server host = csprog, address = 192.168.1.56/3400


CSPROG	Tue Feb 07 10:03:08 2017
	REMOTE INTERFACE/gds__detach: Unsuccesful detach from database.
	Uncommitted work may have been lost.
	Error writing data to the connection.

WI-T4.0.0.530, 07-FEB-2017 SS/SC

select count(*), sum(val) from test;
Statement failed, SQLSTATE = 08006
Error reading data from the connection.


log:
CSPROG	Tue Feb 07 10:09:06 2017
	Modifying procedure SP_TEST which is currently in use by active user requests


CSPROG	Tue Feb 07 10:09:06 2017
	INET/inet_error: read errno = 10054, server host = csprog, address = 192.168.1.56/3400


CSPROG	Tue Feb 07 10:09:06 2017
	REMOTE INTERFACE/gds__detach: Unsuccesful detach from database.
	Uncommitted work may have been lost.
	Error writing data to the connection.


CSPROG	Tue Feb 07 10:09:06 2017
	setsockopt: error setting IPV6_V6ONLY to 0



*/
