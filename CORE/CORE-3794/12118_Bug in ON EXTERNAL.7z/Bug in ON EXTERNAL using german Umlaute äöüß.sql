CREATE DOMAIN DMN_BOOLEAN AS
SMALLINT
DEFAULT 0
NOT NULL
CHECK (VALUE IN (0,1));

CREATE DOMAIN DMN_RDB_TABLENAME AS
VARCHAR(31) CHARACTER SET UNICODE_FSS
NOT NULL
COLLATE UNICODE_FSS;

CREATE DOMAIN DMN_RDB_ATTACHMENTNAME AS
VARCHAR(255) CHARACTER SET UNICODE_FSS
NOT NULL
COLLATE UNICODE_FSS;

CREATE DOMAIN DMN_RDB_INDEXNAME AS
VARCHAR(31) CHARACTER SET UNICODE_FSS
NOT NULL
COLLATE UNICODE_FSS;

set term ^ ;

CREATE OR ALTER PROCEDURE SET_STATISTICS_1 (
    TABLENAME TYPE OF DMN_RDB_TABLENAME DEFAULT '',
    USE_AUTONOMOUS_TRANSACTION TYPE OF DMN_BOOLEAN DEFAULT 1)
AS
DECLARE VARIABLE C_EMPTYTABLENAME TYPE OF DMN_RDB_TABLENAME DEFAULT '';
DECLARE VARIABLE ATTACHMENT_NAME TYPE OF DMN_RDB_ATTACHMENTNAME;
DECLARE VARIABLE INDEX_NAME TYPE OF DMN_RDB_INDEXNAME;
begin

  tablename = COALESCE(tablename, '');
  use_autonomous_transaction = COALESCE(use_autonomous_transaction, 1);

  select MON$ATTACHMENT_NAME
    from mon$attachments
    where MON$ATTACHMENT_ID = CURRENT_CONNECTION
    into :attachment_name;

  for

    select TRIM(RDB$INDEX_NAME)
      from rdb$indices
      where (:tablename = :c_emptytablename) or
            (UPPER(:tablename) = RDB$RELATION_NAME)
      into :index_name

  do
  begin

    if (use_autonomous_transaction <> 1) then
    begin

      execute statement 'SET statistics INDEX ' || :index_name || ';';

    end else
    begin

      -- doesn't work if 'attachment_name' contains german Umlaute ����
      execute statement 'SET statistics INDEX ' || :index_name || ';'
        with autonomous transaction
        on external :attachment_name;

    end

  end

end^


CREATE OR ALTER PROCEDURE SET_STATISTICS_2 (
    TABLENAME TYPE OF DMN_RDB_TABLENAME DEFAULT '',
    USE_AUTONOMOUS_TRANSACTION TYPE OF DMN_BOOLEAN DEFAULT 1)
AS
DECLARE VARIABLE C_EMPTYTABLENAME TYPE OF DMN_RDB_TABLENAME DEFAULT '';
DECLARE VARIABLE ATTACHMENT_NAME TYPE OF DMN_RDB_ATTACHMENTNAME;
DECLARE VARIABLE INDEX_NAME TYPE OF DMN_RDB_INDEXNAME;
begin

  tablename = COALESCE(tablename, '');
  use_autonomous_transaction = COALESCE(use_autonomous_transaction, 1);

  select MON$ATTACHMENT_NAME
    from mon$attachments
    where MON$ATTACHMENT_ID = CURRENT_CONNECTION
    into :attachment_name;

  for

    select TRIM(RDB$INDEX_NAME)
      from rdb$indices
      where (:tablename = :c_emptytablename) or
            (UPPER(:tablename) = RDB$RELATION_NAME)
      into :index_name

  do
  begin

    if (use_autonomous_transaction <> 1) then
    begin

      execute statement 'SET statistics INDEX ' || :index_name || ';';

    end else
    begin

      -- workaround, if 'attachment_name' contains german Umlaute ����
      execute statement 'SET statistics INDEX ' || :index_name || ';'
        with autonomous transaction
        on external '127.0.0.1:' || :attachment_name
        as user 'SYSDBA'
        password 'masterkey';

    end

  end

end^

set term ; ^

CREATE TABLE SOME_TABLE (
    SOME_FIELD     INTEGER NOT NULL,
    ANOTHER_FIELD  VARCHAR(17)
);

ALTER TABLE SOME_TABLE ADD CONSTRAINT PK_SOME_TABLE PRIMARY KEY (SOME_FIELD);

