set bail on;

recreate table test2(d double precision);
commit;
insert into test2(d) values(0.015
); insert into test2(d) values(0.045
); insert into test2(d) values(0.075
); insert into test2(d) values(0.105
); insert into test2(d) values(0.005
); insert into test2(d) values(0.015
); insert into test2(d) values(0.025
); insert into test2(d) values(0.065
); insert into test2(d) values(129.005
); insert into test2(d) values(129.015
); insert into test2(d) values(129.035
); insert into test2(d) values(129.045
); insert into test2(d) values(0.015
); insert into test2(d) values(0.045
); insert into test2(d) values(0.075
); insert into test2(d) values(0.105
); insert into test2(d) values(0.005
); insert into test2(d) values(0.015
); insert into test2(d) values(0.025
); insert into test2(d) values(0.065
); insert into test2(d) values(0.005
); insert into test2(d) values(0.015
); insert into test2(d) values(0.025
); insert into test2(d) values(0.065
); insert into test2(d) values(0.03
); insert into test2(d) values(0.05
); insert into test2(d) values(0.06
); insert into test2(d) values(0.07
); insert into test2(d) values(0.13
); insert into test2(d) values(0.26
); insert into test2(d) values(0.51
); insert into test2(d) values(0.52
); insert into test2(d) values(0.015
); insert into test2(d) values(0.025
); insert into test2(d) values(0.055
); insert into test2(d) values(0.065
); insert into test2(d) values(0.055
); insert into test2(d) values(0.095
); insert into test2(d) values(0.125
); insert into test2(d) values(0.255
); insert into test2(d) values(0.065
); insert into test2(d) values(0.255
); insert into test2(d) values(0.265
); insert into test2(d) values(0.315
); insert into test2(d) values(0.015
); insert into test2(d) values(0.045
); insert into test2(d) values(0.055
); insert into test2(d) values(0.075
); insert into test2(d) values(0.005
); insert into test2(d) values(0.015
); insert into test2(d) values(0.025
); insert into test2(d) values(0.055
); insert into test2(d) values(0.05
); insert into test2(d) values(0.07
); insert into test2(d) values(0.09
); insert into test2(d) values(0.1
); insert into test2(d) values(0.01
); insert into test2(d) values(0.02
); insert into test2(d) values(0.03
); insert into test2(d) values(0.04
); insert into test2(d) values(0.295
); insert into test2(d) values(1.055
); insert into test2(d) values(1.065
); insert into test2(d) values(1.175
); insert into test2(d) values(0.0249
); insert into test2(d) values(0.0349
); insert into test2(d) values(0.0649
); insert into test2(d) values(0.0849
); insert into test2(d) values(1185920.115
); insert into test2(d) values(1185920.125
); insert into test2(d) values(1185920.135
); insert into test2(d) values(1185920.145
); insert into test2(d) values(0.295
); insert into test2(d) values(1.015
); insert into test2(d) values(1.035
); insert into test2(d) values(1.055
); insert into test2(d) values(0.005
); insert into test2(d) values(0.015
); insert into test2(d) values(0.055
); insert into test2(d) values(0.065
); insert into test2(d) values(0.015
); insert into test2(d) values(0.025
); insert into test2(d) values(0.045
); insert into test2(d) values(0.055
); insert into test2(d) values(0.005
); insert into test2(d) values(0.015
); insert into test2(d) values(0.055
); insert into test2(d) values(0.065
); insert into test2(d) values(0.015
); insert into test2(d) values(0.025
); insert into test2(d) values(0.045
); insert into test2(d) values(0.055
); insert into test2(d) values(0.265
); insert into test2(d) values(0.295
); insert into test2(d) values(0.525
); insert into test2(d) values(0.585
); insert into test2(d) values(1.005
); insert into test2(d) values(1.015
); insert into test2(d) values(8.065
); insert into test2(d) values(8.075
); insert into test2(d) values(0.015
); insert into test2(d) values(0.045
); insert into test2(d) values(0.075
); insert into test2(d) values(0.105
); insert into test2(d) values(8.065
); insert into test2(d) values(8.155
); insert into test2(d) values(129.105
); insert into test2(d) values(129.135
); insert into test2(d) values(8.065
); insert into test2(d) values(8.155
); insert into test2(d) values(129.105
); insert into test2(d) values(129.135
); insert into test2(d) values(1.005
); insert into test2(d) values(1.015
); insert into test2(d) values(8.065
); insert into test2(d) values(8.075
); insert into test2(d) values(8.065
); insert into test2(d) values(8.155
); insert into test2(d) values(129.105
); insert into test2(d) values(129.135
); insert into test2(d) values(0.005
); insert into test2(d) values(0.015
); insert into test2(d) values(0.025
); insert into test2(d) values(0.045
); insert into test2(d) values(0.145
); insert into test2(d) values(0.285
); insert into test2(d) values(0.565
); insert into test2(d) values(0.575
);
commit;

recreate table test(d double precision);
commit;
insert into test(d) select distinct d from test2;
commit;
drop table test2;

set term ^;
create or alter function alter_round( x numeric(15,4) ) returns double precision
as
begin
   return floor( x * 100 + .5) / 100.00;
end^

set term ; ^
commit;

select t.d, alter_round( t.d ) as alter_round from test t;
