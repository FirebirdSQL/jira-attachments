<?php
$id = $argv[1];
$count = $argv[2];

for($i = 0; $i < $count; ++$i)
	pclose(popen("start /b e:/php/php runner1.php $id $i", 'r'));
?>
