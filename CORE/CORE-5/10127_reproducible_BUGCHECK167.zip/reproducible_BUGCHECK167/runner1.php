<?php
	$name = $argv[1];
	$id = $argv[2];

	//fwrite(STDERR, "runner $id initialized\n");
	$db = ibase_connect("127.0.0.1:e:\\work\\firebird\\TEST.FDB", "SYSDBA", "masterkey");

	//fwrite(STDERR, "runner $id start\n");

	$key = $name."_".$id;

	$mainId = ibase_gen_id("main_generator", 1, $db);
	$sql = "INSERT INTO main_type(main_type_id,uniString,subtype_1_id,subtype_2_id,subtype_3_id, subtype_4_id, subtype_5_id, string1, subtype_6_id) VALUES ($mainId, '$name for $id',1,1,1,1,1,'string1for$id',1)";

	//fwrite(STDERR, "runner $id sql = $sql\n");

	$trans = ibase_trans(IBASE_DEFAULT, $db);
	if(!$trans){
		$error = ibase_errmsg();
		fwrite(STDERR, "execute() ibase_trans failed: ".$error."\n query was: ".$sql."\n");
	}

	$result = ibase_query($trans, $sql);
	//fwrite(STDERR, "runner $id after query res = $result\n");
	if(!$result){
		$error = ibase_errmsg();
		fwrite(STDERR, "execute() ibase_query failed: ".$error."\n query was: ".$sql."\n");
	}

	$result = ibase_commit($trans);
	if(!$result){
		$error = ibase_errmsg();
		fwrite(STDERR, "execute() ibase_commit failed: ".$error."\n query was: ".$sql."\n");
	}

	fwrite(STDERR, "runner $id exiting\n");
?>
