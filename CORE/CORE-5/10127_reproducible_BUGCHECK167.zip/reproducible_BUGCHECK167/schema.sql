/* Schema file*/

CREATE GENERATOR main_generator;
CREATE TABLE main_type
(
	main_type_id BIGINT NOT NULL PRIMARY KEY,
	uniString VARCHAR(128) NOT NULL UNIQUE,				

	subtype_1_id BIGINT,	
	subtype_2_id BIGINT NOT NULL,
	subtype_3_id BIGINT NOT NULL, 			
	subtype_4_id BIGINT NOT NULL,
	subtype_5_id BIGINT NOT NULL,

	string1 VARCHAR(128) NOT NULL,

	subtype_6_id BIGINT,

	string2 VARCHAR(128),
	string3 VARCHAR(128)
);

CREATE GENERATOR secondary_type_generator;
CREATE TABLE secondary_type
(
	main_type_id BIGINT,
	uniString VARCHAR(128),				

	subtype_1_id BIGINT,	
	subtype_2_id BIGINT,
	subtype_3_id BIGINT, 			
	subtype_4_id BIGINT,
	subtype_5_id BIGINT,

	string1 VARCHAR(128),

	subtype_6_id BIGINT,

	string2 VARCHAR(128),
	string3 VARCHAR(128)
);

SET TERM !! ;

CREATE OR ALTER PROCEDURE helper (string VARCHAR(1024))
  RETURNS (barf BIGINT) AS
DECLARE VARIABLE data VARCHAR(1024);
BEGIN
  IF (string IS NULL) THEN EXIT;
END!!

CREATE PROCEDURE insert_secondary_type(system_id VARCHAR(1024), tester VARCHAR(1024), tester_email VARCHAR(1024) )
	AS
	DECLARE VARIABLE row_number INTEGER;
	DECLARE VARIABLE idsize INTEGER;
	DECLARE VARIABLE tester_size INTEGER;
	DECLARE VARIABLE email_size INTEGER;
	BEGIN

		EXECUTE PROCEDURE helper :tester RETURNING_VALUES :tester_size;
		EXECUTE PROCEDURE helper :tester_email RETURNING_VALUES :email_size;
		EXECUTE PROCEDURE helper :tester RETURNING_VALUES :tester_size;
		EXECUTE PROCEDURE helper :tester_email RETURNING_VALUES :email_size;
		EXECUTE PROCEDURE helper :tester RETURNING_VALUES :tester_size;
		EXECUTE PROCEDURE helper :tester_email RETURNING_VALUES :email_size;
		EXECUTE PROCEDURE helper :tester RETURNING_VALUES :tester_size;
		EXECUTE PROCEDURE helper :tester_email RETURNING_VALUES :email_size;

		row_number = GEN_ID (secondary_type_generator, 1);
		INSERT INTO secondary_type (main_type_id, uniString, subtype_1_id) VALUES (:row_number, :tester, :system_id);
		INSERT INTO secondary_type (main_type_id, uniString, subtype_1_id) VALUES (:row_number, :tester, :system_id);
		INSERT INTO secondary_type (main_type_id, uniString, subtype_1_id) VALUES (:row_number, :tester, :system_id);
	END!!

/* THIS TRIGGER causes BUGCHECK(167) */

CREATE OR ALTER TRIGGER main_type_trigger 
FOR main_type 
AFTER INSERT AS 
BEGIN
	EXECUTE PROCEDURE insert_secondary_type NEW.main_type_id, NULL, NULL;
END!!
SET TERM ; !! 
