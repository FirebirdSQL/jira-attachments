this is meant to reproduce a Firebird issue
where the server throws BUGCHECK 167 Invalid send request

This only happens on windows.

SETUP:
put files in a directory. I had them under e:\work\firebird

if you put them into a different directory open runner1.php
and edit the firebird connection string accordingly.

You need PHP5 (I used php 5.1.4 )
This bug happens when using c++ as well,
but the coding is faster with php.


RUNNING:

1. run createdb.cmd to create the database
2. run e:\php\php spawner.php linux1 1000
	the first parameter is the unique key for the "main_type" table
	the second parameter is the number of instances of runner1.php to spawn

	php cant spawn these processes very quickly so on my machine I had at most
	10 runner1.php's running at one time.


This produces the BUGCHECK with a 90% consistency.  This is a threading issue
in the server, so it might take longer to reproduce on other machines.

I use:
P4 HT 3.0 Ghz
1GB Ram
Windows XP Pro
Firebird 1.5.3


