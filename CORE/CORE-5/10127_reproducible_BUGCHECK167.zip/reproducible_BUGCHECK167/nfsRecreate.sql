drop database;
create database "test.fdb" page_size 8192; 

input "schema.sql";

commit;

