    alter sequence g restart with 0;
    commit;
    set transaction read committed;
    set term ^;
    execute block as
        declare n_limit int = 1000000;
        declare s_length smallint;
    begin
        select ff.rdb$field_length
        from rdb$fields ff
        join rdb$relation_fields rf on ff.rdb$field_name = rf.rdb$field_source
        where rf.rdb$relation_name=upper('test') and rf.rdb$field_name=upper('s')
        into s_length;

        while (n_limit > 0) do
        begin
            --insert into test(id, s) values( gen_id(g,1), rpad('',uuid_to_char(gen_uuid()), :s_length) )
            --returning :n_limit - 1 into n_limit;

            execute statement ('insert into test(id, s) values( ?, ?)')
                  ( gen_id(g,1), rpad('', :s_length, uuid_to_char(gen_uuid()))  )
                  with autonomous transaction
            ;

            n_limit = n_limit - 1;
        end
        insert into test( id ) values( -current_connection );
    end
    ^
    set term ;^
    commit;
