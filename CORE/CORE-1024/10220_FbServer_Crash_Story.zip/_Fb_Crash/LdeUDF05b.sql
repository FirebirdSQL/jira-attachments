/*
// UnitCnv and round
*/
declare external function Round
  double precision by descriptor, 
  double precision by descriptor,
  integer
  returns parameter 1
  entry_point 'Round' module_name 'LdeUdf05b.dll';

declare external function UnitCnvR
  double precision by descriptor, 
  double precision by descriptor,
  cstring(254),
  cstring(254),
  integer
  returns parameter 1
  entry_point 'UnitCnvR' module_name 'LdeUdf05b.dll';

declare external function UnitCnvRN
  double precision by descriptor, 
  double precision by descriptor,
  cstring(254),
  cstring(254)
  returns parameter 1
  entry_point 'UnitCnvRN' module_name 'LdeUdf05b.dll';

declare external function UnitCnvRP
  double precision by descriptor, 
  double precision by descriptor,
  cstring(254),
  cstring(254),
  integer
  returns parameter 1
  entry_point 'UnitCnvRP' module_name 'LdeUdf05b.dll';

declare external function UnitCnvRY
  double precision by descriptor, 
  double precision by descriptor,
  cstring(254),
  cstring(254)
  returns parameter 1
  entry_point 'UnitCnvRY' module_name 'LdeUdf05b.dll';

declare external function ChkIsNum
  cstring(254)
  returns integer by value
  entry_point 'ChkIsNum' module_name 'LdeUdf05b.dll';

declare external function StrToNum
  cstring(254)
  returns double precision by value
  entry_point 'StrToNum' module_name 'LdeUdf05b.dll';
