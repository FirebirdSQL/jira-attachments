

Attached files
==============

.\UdfDsc	UdfDsc.dll and pascal files (Delphi 6.0)











Steps to reproduce the problem
==============================


1. Create an empty database (on a FB 2.0.0 or 2.0.3 server, ODS 11.0)

2. Add UdfDsc.dll to the server UDF directory

3. Define UDF and Table, load table from file UdfCrash_1_LoadTable.sql

4. Run select 1 from file UdfCrash_2_Select.sql: Server will keep running

5. Run select 2 from file UdfCrash_2_Select.sql: Server will crash


Redo this on a FB Version 1.5.3: will not crash
