
/*
// UdfCrash 
*/

/* First select without distinct: does not crash  /*

select 
  RtrRound(TJS_AVGFORCE, 2)
from
  Test
order by
  LNR_ID  
  


/* Second select with distinct: crashes the server  /*


select distinct
  RtrRound(TJS_AVGFORCE, 2)
from
  Test
order by
  LNR_ID

