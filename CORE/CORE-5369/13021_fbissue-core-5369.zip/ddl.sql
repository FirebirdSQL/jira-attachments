drop table master;
drop table detail;

create table master (
  id integer not null,
  nr integer not null
);
alter table master add constraint pk_master primary key (id, nr);

create table detail (
  id integer not null,
  nr integer not null,
  ts timestamp not null,
  tday integer,
  val integer
);
alter table detail add constraint pk_detail primary key (id, nr, ts);
create index idx_detail_tday on detail (tday);
create index idx_detail_val on detail (val);

