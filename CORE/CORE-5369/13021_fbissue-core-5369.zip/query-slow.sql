select max( (
  select avg(val) from detail d
  where d.id = m.id and d.nr = m.nr and
    d.tday between 1 and 14
) ) as mvalue, count(*) as num
from master m;

