    set list on;

    show version;
    select mon$user,mon$remote_protocol,mon$auth_method from mon$attachments where mon$attachment_id=current_connection;
    commit;

    set echo on;
    drop user boss;
    drop user ozzy;
    commit;
    create user boss password '123' grant admin role;
    commit;
    
    select u.sec$user_name, u.sec$plugin, u.sec$admin from sec$users u where u.sec$user_name='BOSS';

    set term ^;
    execute block as
    begin
        execute statement 'create user ozzy password ''456'''
        as user 'BOSS' password '123' role 'RDB$ADMIN';
    end
    ^
    set term ;^
    commit;

    
    select u.sec$user_name, sec$plugin, u.sec$admin
    from sec$users u
    where u.sec$user_name = upper('ozzy');

    set term ^;
    execute block as
    begin
        execute statement 'drop user ozzy'
        as user 'BOSS' password '123' role 'RDB$ADMIN';
    end
    ^
    set term ;^
    commit;


    drop user boss;
    commit;
