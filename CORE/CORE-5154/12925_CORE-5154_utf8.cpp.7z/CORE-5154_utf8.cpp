/*
 *    Program type:  API Interface
 *
 *    Description:
 *        This program creates a new database, given an SQL statement
 *        string.  The newly created database is accessed after its
 *        creation, and a sample table is added.
 *
 *        The SQLCODE is extracted from the status vector and is used
 *        to check whether the database already exists.
 * The contents of this file are subject to the Interbase Public
 * License Version 1.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy
 * of the License at http://www.Inprise.com/IPL.html
 *
 * Software distributed under the License is distributed on an
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express
 * or implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code was created by Inprise Corporation
 * and its predecessors. Portions created by Inprise Corporation are
 * Copyright (C) Inprise Corporation.
 *
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
//#include "example.h"
#include <ibase.h>

int pr_error (ISC_STATUS *, const char *);



int main (int argc, char** argv)
{
    isc_db_handle   newdb = NULL;          /* database handle */
    isc_tr_handle   trans = NULL;          /* transaction handle */
    ISC_STATUS_ARRAY status;               /* status vector */
    long            sqlcode;               /* SQLCODE  */
    const char      new_dbname[] = {0xD0, 0x90, 0xD0, 0x91, 0xD0, 0x92, 0xD0, 0x93};
	const ISC_SCHAR	dpb[] = {isc_dpb_version1,
							 isc_dpb_user_name, 6, 'S','Y','S','D','B','A',
							 isc_dpb_password, 9, 'm','a','s','t','e','r','k','e','y',
							 isc_dpb_utf8_filename, 0,
							 isc_dpb_lc_ctype, 5, 'u','t','f','-','8',
							 isc_dpb_sql_dialect, 1, 3};

    /*
     *    Create a new database.
     *    The database handle is zero.
     */
    
    if (isc_create_database(status, 0, new_dbname, &newdb, sizeof(dpb),
                                   dpb, 0))
    {
        if (pr_error(status, "create database"))
            return 1;
    }

    printf("Created database '%s'.\n", new_dbname);

    /*
     *    Connect to the new database and create a sample table.
     */
	isc_start_transaction(status, &trans, 1, &newdb, 0, NULL);

	if (isc_dsql_execute_immediate(status, &newdb, &trans, 0,
				"create table \"ёпрст\" (a integer)", 3, NULL))
        if (pr_error(status, "create table"))
            return 1;

	if (isc_dsql_execute_immediate(status, &newdb, &trans, 0,
				"create index \"фыва\" on \"ёпрст\" (a)", 3, NULL))
        if (pr_error(status, "create index"))
            return 1;

	if (isc_commit_transaction(status, &trans))
        if (pr_error(status, "commit transaction"))
            return 1;

    /* newdb will be set to null on success */ 
    if (isc_detach_database(status, &newdb))
        if (pr_error(status, "attach database"))
            return 1;


	isc_svc_handle service_handle = NULL;
	ISC_SCHAR spb_buffer[] = {isc_spb_version, isc_spb_current_version,
							  isc_spb_user_name, 6, 'S','Y','S','D','B','A',
							  isc_spb_password, 9, 'm','a','s','t','e','r','k','e','y'
							  ,isc_spb_utf8_filename, 0
							 };
								 
	if (isc_service_attach(status, 0, "service_mgr", &service_handle, sizeof(spb_buffer), spb_buffer))
        if (pr_error(status, "attach service"))
            return 1;

    printf("Successfully attached to service manager.\n");

	ISC_SCHAR qry[] =  {isc_action_svc_db_stats,
						isc_spb_dbname,
						8, 0, 0xD0, 0x90, 0xD0, 0x91, 0xD0, 0x92, 0xD0, 0x93, // UTF8 'АБВГ'
						isc_spb_options, isc_spb_sts_data_pages|isc_spb_sts_idx_pages, 0, 0, 0
					   };

	if (isc_service_start(status, &service_handle, NULL, sizeof(qry), qry))
        pr_error(status, "start service");
	else
	{
		printf("service started ok\n");
		char respbuf[1024], *p = respbuf, *x;
		do
	    {
			const char    sendbuf[] = {isc_info_svc_line};
			if (isc_service_query (status, &service_handle, NULL, 0, NULL,
				sizeof (sendbuf), sendbuf, sizeof(respbuf), respbuf))
			{
		        pr_error(status, "query service");
				break;
			}

		    x = p = respbuf;

		    if (*p++ == isc_info_svc_line) 
			{
				ISC_USHORT len = 0, chTmp = 0;
				ISC_ULONG  tra_id = 0;

				len = (ISC_USHORT)isc_vax_integer(p, sizeof(ISC_USHORT));
				if (len == 0)
					break;
				p += sizeof (ISC_USHORT);
				printf("%.*s", len, p);
				p += len;
			}
	
			if (*p == isc_info_truncated)
			    continue;
			printf("\n");
			/****************************
			if (*p == isc_info_end)
		    	break;
			**************************/

	    }
		while (*x == isc_info_svc_line);
	}

	if (isc_service_detach(status, &service_handle))
        if (pr_error(status, "detach service"))
            return 1;

	newdb = NULL;

    if (isc_attach_database(status, 0, new_dbname, &newdb, sizeof(dpb), dpb))
        if (pr_error(status, "attach database"))
            return 1;

    printf("Successfully accessed the newly created database.\n");

    isc_drop_database(status, &newdb);

    return 0;
}            

/*
 *    Print the status, the SQLCODE, and exit.
 *    Also, indicate which operation the error occured on.
 */
int pr_error (ISC_STATUS* status, const char* operation)
{
    printf("[\n");
    printf("PROBLEM ON \"%s\".\n", operation);

    isc_print_status(status);

    printf("SQLCODE:%d\n", isc_sqlcode(status));

    printf("]\n");

    return 1;
}

