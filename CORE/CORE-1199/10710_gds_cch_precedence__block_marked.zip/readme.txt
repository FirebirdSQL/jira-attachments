This Test Case is meant to reproduce:
CORE-1199
Firebird SS: internal gds software consistency check (CCH_precedence: block marked (212), file: cch.cpp line: 3640)

The logs I get with FB 2.0.0 is a bit different:
internal gds software consistency check (CCH_precedence: block marked (212), file: cch.cpp line: 3805)


Instructions:

Under windows with:
	VS7 includes/libs/path environment variables set,
	Firebird bin in path
	Firebird 2.0.0 installation in c:/firebird

Run make.bat
	will compile firebird_tester.cpp
	will create database tester.fdb in the current directory

Create an alias to the newly created tester.fdb, called "tester"

Run: firebird_tester.exe

On my machine, I get the GDS check in 3 out of 5 times within the first minute or two.

