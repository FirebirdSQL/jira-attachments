/* Driver file for creating database*/
create database "tester.fdb" page_size 16384; 
input "schema.sql";
commit;

