#include <string>
#include <vector>
#include <iostream>
#include <strstream>

#include <assert.h>

#include <stdlib.h>
#include <ibase.h>

#ifdef WIN32
#include <windows.h>
#else
#include <pthreads.h>
#endif

using namespace std;

const unsigned int THREADS = 100;
const unsigned int CONNECTIONS_PER_THREAD = 10000;
const unsigned int STATEMENTS_PER_CONNECTION = 10;

#ifdef WIN32
CRITICAL_SECTION g_mutex;
#else 
#endif

class AutoMutex{
public:
	AutoMutex(CRITICAL_SECTION* mutex) : m_mutex(mutex){
#ifdef WIN32
		EnterCriticalSection(mutex);
#else 
#endif
	}
	~AutoMutex(){
#ifdef WIN32
		LeaveCriticalSection(m_mutex);
#else 
#endif
	}
private:
	CRITICAL_SECTION* m_mutex;
};

enum {MAX_IBASE_MSG_SIZE = 256, MAX_ERROR_MSG_SIZE = 512};

string parseError(ISC_STATUS_ARRAY status)
{
	char msg[MAX_ERROR_MSG_SIZE];
	char *s = msg;
	
	while (s - msg < MAX_ERROR_MSG_SIZE - (MAX_IBASE_MSG_SIZE + 2) && isc_interprete(s, &status)) {
		strcat(msg, " ");
		s = msg + strlen(msg);
	}

	return msg;
}

enum{SQL_DIALECT = 3};
enum{SQLDA_VERSION = SQLDA_VERSION1}; 

isc_db_handle fbconnect(	
		const char* hostdb, 
		const char* user, 
		const char* pass)
{

	enum {MAX_TRIES = 6};
	enum {SLEEP_INTERVAL = 1000};

    ISC_STATUS_ARRAY status;               
	isc_db_handle db = NULL;

    char *  dpb = NULL;    // DB parameter buffer
    short   dpb_length = 0;

   
	int res;

	{
		// firebird users suggest mutexing isc_attach_database calls
		//  seems to work better this way
		//  prepared statements dont hang for 30-90 seconds for no reason
		AutoMutex a(&g_mutex);
	
		 isc_expand_dpb(&dpb, &dpb_length,
                   isc_dpb_user_name, user,
                   isc_dpb_password, pass, NULL);
	
		
		res = isc_attach_database(status, 0, hostdb, &db, dpb_length, dpb);
	}

	if (res){
		cout<<"fbconnect() isc_attach_database failed: "<<parseError(status)<<endl;
		isc_free(dpb);
		return NULL;
	}

	isc_free(dpb);
	return db;
}

isc_tr_handle beginTransaction(isc_db_handle db)
{

    ISC_STATUS_ARRAY status;               /* status vector */
    isc_tr_handle   trans = NULL;          /* transaction handle */

	static char  	isc_tpb[4] = {isc_tpb_version3,
				      isc_tpb_write,
				      isc_tpb_concurrency,
				      isc_tpb_wait};


    if(isc_start_transaction(status, &trans, 1, &db, 4, isc_tpb)){
		cout<<"beginTransaction() isc_start_transaction failed: "<<parseError(status)<<endl;
		return NULL;
	}

	return trans;
}

void commitTransaction(isc_tr_handle tr){
	ISC_STATUS_ARRAY            status;           /* status vector */
	if(isc_commit_transaction(status, &tr)){
		cout<<"commitTransaction() isc_commit_transaction failed: "<<parseError(status)<<endl;
	}
}


typedef __int64 BIGINT;

vector<BIGINT> 
getNumericsFromSelect(	
					  isc_db_handle db,
					  const char* selectSql, 
					  unsigned int numberOfResults,
					  isc_tr_handle trans,
					  ISC_STATUS_ARRAY& status
					  ) 
{
    isc_stmt_handle             stmt = NULL;      /* statement handle */
    XSQLDA *                    sqlda;
    short                       flag0 = 0;
	ISC_STATUS_ARRAY local_status;

	bool localTransaction = false;

	vector<BIGINT> output;
	vector<BIGINT> outputVals(numberOfResults);


	if( !trans){
		trans = beginTransaction(db);
		localTransaction = true;
	}
    
	// Allocate and prepare the select statement.
    if (isc_dsql_allocate_statement(status, &db, &stmt))
    {
		//cout<<"getNumericsFromSelect() isc_dsql_allocate_statement failed: "<<parseError(status)<<endl;
		return output;
    }
    
	// Allocate result structure
	//
    sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(numberOfResults));
    sqlda->sqln = numberOfResults;
    sqlda->version = 1;

    if (isc_dsql_prepare(status, &trans, &stmt, 0, selectSql, 3, sqlda))
    {
		//cout<<"getNumericsFromSelect() isc_dsql_prepare failed :"<<parseError(status)<<"\nsql="<<selectSql<<endl;
		free(sqlda);
		return output;
    }

	BIGINT* results = (BIGINT*)malloc(sizeof(BIGINT)*numberOfResults);
	
	//auto_ptr<BIGINT> p = results;
	
	for( unsigned int i = 0; i < numberOfResults; ++i){
		sqlda->sqlvar[i].sqldata = (char *)&results[i];
		sqlda->sqlvar[i].sqltype = SQL_INT64 + 1;
		sqlda->sqlvar[i].sqlind  = &flag0;
	}


    if (isc_dsql_execute(status, &trans, &stmt, 3, NULL))
    {
		//cout<<"getNumericsFromSelect() isc_dsql_execute failed :"<<parseError(status)<<endl;
		isc_dsql_free_statement(local_status, &stmt, DSQL_drop);
		free(sqlda);
		free(results);

		return output;
    }
	
    long fetch_stat;
    if ((fetch_stat = isc_dsql_fetch(status, &stmt, 3, sqlda)) == 0)
    {
		for( unsigned int i = 0; i < numberOfResults; ++i){
			//cout<<"getNumericsFromSelect() select = "<<selectSql<<" valueIndex = "<<i<<" value = "<<results[i]<<endl;
			outputVals[i] = results[i];
		}

	} else {
		//cout<<"getNumericsFromSelect() isc_dsql_fetch failed: "<<parseError(status)<<endl;
		isc_dsql_free_statement(local_status, &stmt, DSQL_drop);
		free(sqlda);
		free(results);
		return output;
	}	

    if (isc_dsql_free_statement(status, &stmt, DSQL_drop))
    {
		//cout<<"getNumericsFromSelect() isc_dsql_free_statement failed: "<<parseError(status)<<endl;
		free(sqlda);
		free(results);
		return outputVals;
    }

	if( localTransaction ){
		commitTransaction(trans);
	}

    free(sqlda);
	free(results);
	return outputVals;
}

void fbdisconnect(isc_db_handle db){
    ISC_STATUS_ARRAY status;       
	//AutoMutex a(&g_mutex);
    isc_detach_database(status, &db);
}

enum {MAX_TRIES = 20};


DWORD WINAPI runner( LPVOID lpParameter ){
	
	unsigned int threadNumber = *((unsigned int *)lpParameter);
	ISC_STATUS_ARRAY status;
	
	for(unsigned int con = 0; con < CONNECTIONS_PER_THREAD; ++con){

		// assume we have an alias pointing to tester.fdb in the current directory
		isc_db_handle db = fbconnect("localhost:tester", "SYSDBA", "masterkey");
		assert(db);
		isc_tr_handle trans = beginTransaction(db);
		assert(trans);

		for(unsigned int i = 0; i < STATEMENTS_PER_CONNECTION; ++i){
			unsigned int tries = 0;
			strstream data1;
			data1 << "PrimaryData1_" <<threadNumber << "_" <<con<< "_" << i <<ends;
			strstream data2;
			data2 << "PrimaryData2" << threadNumber << "_" << con << "_" << i <<ends;

			string data2Str = data2.str();
			string sql = "SELECT primary_element_id, super_element_id FROM login_primary_element('"
				+string(data1.str())+"','"+data2Str+"','sub1_"+data2Str+"','sub2_"+data2Str+"','sub3_"+data2Str+"','sub4_"+data2Str+"',1180489607,'secondaryData_"+data2Str+"_.xxx',6,122,'',0,'','now');";
			//string sql = "SELECT id, manufacturer_id FROM system";
			vector<BIGINT> output;
RETRY:
			output = getNumericsFromSelect(db,
				sql.c_str(),
				2,
				trans,
				status);

			if( output.size() != 2){
				// deadlock -- restart transaction
			
				if(tries >= MAX_TRIES){	
					cout<<"MAX_TRIES reached error: "<<parseError(status)<<endl;
				}
				tries++;
				commitTransaction(trans);
				trans = beginTransaction(db);
				goto RETRY;
			}
		}

		commitTransaction(trans);
		fbdisconnect(db);
	}

	return 0;
}

int main(){

	DWORD threadId;

	InitializeCriticalSection(&g_mutex);


#ifdef WIN32
	vector<HANDLE> threads(THREADS);
#else 
#endif

	for( unsigned int i = 0; i < THREADS; ++i){
#ifdef WIN32
		threads[i] = CreateThread(
			NULL,
			0,
			runner,
			&i,
			0,
			&threadId);
#else 
#endif
	}

	for( unsigned int i = 0; i < THREADS; ++i){
#ifdef WIN32
		WaitForSingleObject(threads[i],500000);
#else 
#endif
	}

	cout<<"all done"<<endl;

	string hi;
	cin >> hi;
	
	DeleteCriticalSection(&g_mutex);
}


