/* Schema file*/

CREATE GENERATOR sub_element_1_generator;
CREATE TABLE sub_element_1
(
	id BIGINT NOT NULL PRIMARY KEY,
	sub_element_1 VARCHAR(128) NOT NULL UNIQUE
);

CREATE GENERATOR sub_element_2_generator;
CREATE TABLE sub_element_2
(
	id BIGINT NOT NULL PRIMARY KEY,
	sub_element_2 VARCHAR(128) NOT NULL UNIQUE
);

CREATE GENERATOR sub_element_3_generator;
CREATE TABLE sub_element_3
(
	id BIGINT NOT NULL PRIMARY KEY,
	sub_element_3 VARCHAR(128) NOT NULL UNIQUE
);

CREATE GENERATOR sub_element_4_generator;
CREATE TABLE sub_element_4
(
	id BIGINT NOT NULL PRIMARY KEY,
	sub_element_4 VARCHAR(128) NOT NULL UNIQUE
);

CREATE GENERATOR sub_element_5_generator;
CREATE TABLE sub_element_5
(
	id BIGINT NOT NULL PRIMARY KEY,
	sub_element_5 VARCHAR(128) NOT NULL UNIQUE
);

CREATE GENERATOR primary_element_generator;
CREATE TABLE primary_element
(
	id BIGINT NOT NULL PRIMARY KEY,
	element_key VARCHAR(128) NOT NULL UNIQUE,			
	sub_element_2_id BIGINT NOT NULL,
	sub_element_3_id BIGINT NOT NULL, 		
	sub_element_4_id BIGINT NOT NULL, 	
	sub_element_5_id BIGINT NOT NULL, 		
	primary_element_mac VARCHAR(128) NOT NULL,

	sub_element_1_id BIGINT NOT NULL,
	value_1 VARCHAR(128),
	value_2 VARCHAR(128),

	FOREIGN KEY(sub_element_2_id) REFERENCES sub_element_2(id),
	FOREIGN KEY(sub_element_3_id) REFERENCES sub_element_3(id),
	FOREIGN KEY(sub_element_4_id) REFERENCES sub_element_4(id),
	FOREIGN KEY(sub_element_5_id) REFERENCES sub_element_5(id),
	FOREIGN KEY(sub_element_1_id) REFERENCES sub_element_1(id)
);

CREATE TABLE primary_element_hidden_state
(
	primary_element_id BIGINT NOT NULL,
	is_hidden CHAR(1) DEFAULT 'N',

	FOREIGN KEY(primary_element_id) REFERENCES primary_element(id)
);


CREATE TABLE pcd_primary_element_times
(
	primary_element_id BIGINT NOT NULL,
	last_access_time BIGINT,

	FOREIGN KEY(primary_element_id) REFERENCES primary_element(id)
);

CREATE TABLE pcd_primary_element_keys
(
	primary_element_id BIGINT NOT NULL,
	is_true CHAR(1) default '0',
	complete CHAR(1) default '0',

	FOREIGN KEY(primary_element_id) REFERENCES primary_element(id)
);

CREATE GENERATOR version_generator;
CREATE TABLE version
(
	id           BIGINT NOT NULL PRIMARY KEY,
	major_number BIGINT NOT NULL,
	minor_number BIGINT NOT NULL,
	build_id	 VARCHAR(24) NOT NULL,
	revision	 BIGINT NOT NULL,
	os           VARCHAR(128) DEFAULT '',
	build_date   TIMESTAMP,

	UNIQUE( major_number, minor_number, build_id, revision, os)
);

CREATE GENERATOR side_element_1_generator;
CREATE TABLE side_element_1
(
	id BIGINT NOT NULL PRIMARY KEY,
	side_element_1 VARCHAR(1024) NOT NULL UNIQUE
);


CREATE GENERATOR side_element_2_generator;
CREATE TABLE side_element_2
(
	id BIGINT NOT NULL PRIMARY KEY,
	element_value VARCHAR(1024) NOT NULL UNIQUE
);

CREATE GENERATOR super_element_generator;
CREATE TABLE super_element
(
	id BIGINT NOT NULL PRIMARY KEY,
	primary_element_id BIGINT NOT NULL,
	version_id BIGINT NOT NULL,

	start_date TIMESTAMP DEFAULT 'now',
	end_date TIMESTAMP DEFAULT 'now',
	location VARCHAR(100) DEFAULT '',
	user_id BIGINT,
	is_true CHAR(1) default 'N',
	side_element_2_id BIGINT NOT NULL, 

	sub_element_2_id BIGINT NOT NULL,
	sub_element_3_id BIGINT NOT NULL,
	sub_element_4_id BIGINT NOT NULL, 
	sub_element_5_id BIGINT NOT NULL,
	side_element_1_id BIGINT NOT NULL,

	FOREIGN KEY(primary_element_id) REFERENCES primary_element(id),
	FOREIGN KEY(version_id) REFERENCES version(id),
	FOREIGN KEY(side_element_2_id) REFERENCES side_element_2(id),

	FOREIGN KEY(sub_element_2_id) REFERENCES sub_element_2(id),
	FOREIGN KEY(sub_element_3_id) REFERENCES sub_element_3(id),
	FOREIGN KEY(sub_element_4_id) REFERENCES sub_element_4(id),
	FOREIGN KEY(sub_element_5_id) REFERENCES sub_element_5(id),

	FOREIGN KEY(side_element_1_id) REFERENCES side_element_1(id)
);


CREATE TABLE pcd_primary_element_assocc
(
	primary_element_id BIGINT NOT NULL,		
	super_element_id BIGINT,  					
	last_super_element_id BIGINT, 

	FOREIGN KEY(primary_element_id) REFERENCES primary_element(id)
);


SET TERM !! ; 

CREATE OR ALTER PROCEDURE get_sub_element_1_id( sub_element_1 VARCHAR(128) )
RETURNS( sub_element_1_row BIGINT )
AS
BEGIN
	SELECT id FROM sub_element_1 WHERE sub_element_1 = :sub_element_1 INTO :sub_element_1_row;
	IF(:sub_element_1_row IS NULL ) THEN
	BEGIN
		sub_element_1_row = GEN_ID (sub_element_1_generator, 1);
		INSERT INTO sub_element_1 VALUES(:sub_element_1_row, :sub_element_1);	
	END
	SUSPEND;
END!!

CREATE OR ALTER PROCEDURE get_sub_element_2_id( sub_element_2 VARCHAR(128) )
RETURNS( sub_element_2_row BIGINT )
AS
BEGIN
	SELECT id FROM sub_element_2 WHERE sub_element_2 = :sub_element_2 INTO :sub_element_2_row;
	IF(:sub_element_2_row IS NULL ) THEN
	BEGIN
		sub_element_2_row = GEN_ID (sub_element_2_generator, 1);
		INSERT INTO sub_element_2 VALUES(:sub_element_2_row, :sub_element_2);	
	END
	SUSPEND;
END!!

CREATE OR ALTER PROCEDURE get_sub_element_3_id( sub_element_3 VARCHAR(128) )
RETURNS( group_row BIGINT )
AS
BEGIN
	SELECT id FROM sub_element_3 WHERE sub_element_3 = :sub_element_3 INTO :group_row;
	IF(:group_row IS NULL) THEN
	BEGIN
		group_row = GEN_ID (sub_element_3_generator, 1);
		INSERT INTO sub_element_3 VALUES(:group_row, :sub_element_3);	
	END
	SUSPEND;
END!!

CREATE OR ALTER  PROCEDURE get_sub_element_4_id( sub_element_4 VARCHAR(128) )
RETURNS( sub_element_4_row BIGINT )
AS
BEGIN
	SELECT id FROM sub_element_4 WHERE sub_element_4 = :sub_element_4 INTO :sub_element_4_row;
	IF(:sub_element_4_row IS NULL) THEN
	BEGIN
		sub_element_4_row = GEN_ID (sub_element_4_generator, 1);
		INSERT INTO sub_element_4 VALUES(:sub_element_4_row, :sub_element_4);	
	END
	
	SUSPEND;
END!!

CREATE OR ALTER  PROCEDURE get_sub_element_5_id( sub_element_5 VARCHAR(128) )
RETURNS( sub_element_5_row BIGINT )
AS
BEGIN
	SELECT id FROM sub_element_5 WHERE sub_element_5 = :sub_element_5 INTO :sub_element_5_row;
	IF(:sub_element_5_row IS NULL) THEN
	BEGIN
		sub_element_5_row = GEN_ID (sub_element_5_generator, 1);
		INSERT INTO sub_element_5 VALUES(:sub_element_5_row, :sub_element_5);	
	END
	
	SUSPEND;
END!!

CREATE OR ALTER PROCEDURE get_version_id(major_version BIGINT, minor_version BIGINT, build_id VARCHAR(24), revision BIGINT, os VARCHAR(128), build_date TIMESTAMP)
RETURNS( version_row BIGINT )
AS
BEGIN
	SELECT id FROM version WHERE 	major_number = :major_version AND
											minor_number = :minor_version AND
											build_id = :build_id AND
											revision = :revision AND
											os = :os
									INTO :version_row;
	IF(:version_row IS NULL) THEN
	BEGIN
		version_row = GEN_ID (version_generator, 1);
		INSERT INTO version VALUES(:version_row, :major_version, :minor_version, :build_id, :revision, :os, :build_date);	
	END
	SUSPEND;
END!!

CREATE OR ALTER PROCEDURE get_side_element_1_id( side_element_1_name VARCHAR(1024))
RETURNS( side_element_1_row BIGINT )
AS
BEGIN
	SELECT id FROM side_element_1 WHERE side_element_1 = :side_element_1_name INTO :side_element_1_row;
	IF( :side_element_1_row IS NULL) THEN 
	BEGIN
		side_element_1_row = GEN_ID (side_element_1_generator, 1);
		INSERT INTO side_element_1(id, side_element_1) VALUES(:side_element_1_row, :side_element_1_name);
	END
	
	SUSPEND;
END!!

CREATE OR ALTER PROCEDURE get_side_element_2_id( element_value VARCHAR(1024))
RETURNS( element_value_id BIGINT )
AS
BEGIN
	SELECT id FROM side_element_2 WHERE element_value = :element_value INTO :element_value_id;

	IF( :element_value_id IS NULL ) THEN
	BEGIN
		element_value_id = GEN_ID (side_element_2_generator, 1);
		INSERT INTO side_element_2 VALUES( :element_value_id, :element_value );
	END
	SUSPEND;
END!!

CREATE OR ALTER PROCEDURE login_primary_element(	primary_element_key VARCHAR(128), 
										primary_element_mac VARCHAR(128), 
										sub_element_3 VARCHAR(128), 
										primary_element_sub_element_4 VARCHAR(128), 
										primary_element_sub_element_5 VARCHAR(128), 
										sub_element_2 VARCHAR(128), 
										time_now INTEGER, 
										side_element_1_name VARCHAR(1024), 
										major_version BIGINT, 
										minor_version BIGINT, 
										build_id VARCHAR(24), 
										revision BIGINT, 
										os VARCHAR(128),
										build_date TIMESTAMP 
									  )

	RETURNS (primary_element_id BIGINT, super_element_id BIGINT) 
	AS
	DECLARE sub_element_2_row BIGINT;
	DECLARE group_row BIGINT;
	DECLARE sub_element_4_row BIGINT;
	DECLARE sub_element_5_row BIGINT;
	DECLARE sub_element_1_row BIGINT;

	DECLARE version_row BIGINT;
	DECLARE side_element_1_row BIGINT;
	DECLARE side_element_2_id BIGINT;
	BEGIN

		EXECUTE PROCEDURE get_sub_element_2_id :sub_element_2 RETURNING_VALUES :sub_element_2_row;
		EXECUTE PROCEDURE get_sub_element_3_id :sub_element_3 RETURNING_VALUES :group_row;
		EXECUTE PROCEDURE get_sub_element_4_id :primary_element_sub_element_4 RETURNING_VALUES :sub_element_4_row;
		EXECUTE PROCEDURE get_sub_element_5_id :primary_element_sub_element_5 RETURNING_VALUES :sub_element_5_row;

		BEGIN
			/*initialize script */
			super_element_id = GEN_ID (super_element_generator, 1);

			SELECT id FROM primary_element WHERE element_key = :primary_element_key INTO :primary_element_id;

			IF ( :primary_element_id IS NULL ) THEN 
				BEGIN
					/* new primary_element */
					primary_element_id = GEN_ID (primary_element_generator, 1);

					EXECUTE PROCEDURE get_sub_element_1_id '' RETURNING_VALUES :sub_element_1_row;

					INSERT INTO primary_element(id,sub_element_2_id,element_key,sub_element_3_id,sub_element_4_id,sub_element_5_id,primary_element_mac,sub_element_1_id)
						  VALUES(:primary_element_id,:sub_element_2_row,:primary_element_key,:group_row, :sub_element_4_row, :sub_element_5_row, :primary_element_mac, :sub_element_1_row);
					
					INSERT INTO primary_element_hidden_state(primary_element_id) VALUES(:primary_element_id);
					INSERT INTO pcd_primary_element_times(primary_element_id,last_access_time) VALUES(:primary_element_id, :time_now);
					INSERT INTO pcd_primary_element_keys(primary_element_id, is_true, complete) VALUES(:primary_element_id, 'N', 'N');

					EXECUTE PROCEDURE get_version_id :major_version, :minor_version, :build_id, :revision, :os, :build_date RETURNING_VALUES :version_row;
					EXECUTE PROCEDURE get_side_element_1_id :side_element_1_name RETURNING_VALUES :side_element_1_row;
					EXECUTE PROCEDURE get_side_element_2_id 'DEFAULT_ELEMENT_VALUE' RETURNING_VALUES :side_element_2_id;

					INSERT INTO super_element(id,primary_element_id,is_true,side_element_2_id,sub_element_2_id,sub_element_3_id,sub_element_4_id,
						sub_element_5_id, side_element_1_id, version_id)
					VALUES(:super_element_id,:primary_element_id,'Y',:side_element_2_id,
						:sub_element_2_row, :group_row, :sub_element_4_row, :sub_element_5_row,
						:side_element_1_row, :version_row);


					INSERT INTO pcd_primary_element_assocc(primary_element_id, super_element_id, last_super_element_id) VALUES(:primary_element_id, :super_element_id, :super_element_id);

					/*
					EXECUTE PROCEDURE insert_blank_primary_element_extra(:primary_element_id);
					*/
				END
			ELSE
				BEGIN


					/* existing primary_element */
					UPDATE primary_element SET 
							sub_element_2_id		= :sub_element_2_row,
							sub_element_3_id	= :group_row,
							sub_element_4_id	= :sub_element_4_row,
							sub_element_5_id	= :sub_element_5_row
						
							WHERE id = :primary_element_id; 

					UPDATE pcd_primary_element_keys SET is_true = 'N', complete = 'N' WHERE primary_element_id = :primary_element_id;

					EXECUTE PROCEDURE get_version_id :major_version, :minor_version, :build_id, :revision, :os, :build_date RETURNING_VALUES :version_row;
					EXECUTE PROCEDURE get_side_element_1_id :side_element_1_name RETURNING_VALUES :side_element_1_row;
					EXECUTE PROCEDURE get_side_element_2_id 'DEFAULT_ELEMENT_VALUE' RETURNING_VALUES :side_element_2_id;

					INSERT INTO super_element(id,primary_element_id,is_true,side_element_2_id,sub_element_2_id,sub_element_3_id,sub_element_4_id,
						sub_element_5_id, side_element_1_id, version_id)
					VALUES(:super_element_id,:primary_element_id,'Y',:side_element_2_id,
						:sub_element_2_row, :group_row, :sub_element_4_row, :sub_element_5_row,
						:side_element_1_row, :version_row);

					UPDATE pcd_primary_element_assocc SET super_element_id = :super_element_id, last_super_element_id = :super_element_id WHERE primary_element_id = :primary_element_id;

				END


			SUSPEND;

		END
	END!!

SET TERM ; !! 
