This is a test case to reproduce 60 seconds delays during data transfer operations on Windows 2003 Server.

Steps to reproduce the problem:

- use the attached Delphi sources to build and run test application
  (zipped EXE is larger than 256 K SourceForge limit, I can't attach it directly)
- fill in username, password and ! localhost ! database name (ie. 'localhost:C:\TESTDB.FDB')
- click on Create DB to create the test database
- click on Start button and let the program run for 15 minutes
- every detected delay is written in the memo
- if it doesn't detect any delay within 15 minutes, your system has passed the test