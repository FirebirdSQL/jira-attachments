// test_udf.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "test_udf.h"


// This is an example of an exported variable
TEST_UDF_API int ntest_udf=0;

extern "C"
{
// This is an example of an exported function.
TEST_UDF_API int fn_test_udf(void)
{
	return 42;
}


//extern "C" EXPORT int fn_strpos(char* search, char* s)
TEST_UDF_API int fn_strpos(char* search, char* s)
{
  char *ptr;
  if (!*search) return 0;
  ptr = strstr(s, search);
  return (ptr) ? ((AUDFL_size_t /* because limit string length */)(ptr - s) + 1) : 0;
}

//extern "C" int EXPORT fn_strpos_un(char* search, char* s)
TEST_UDF_API int fn_strpos_un(char* search, char* s)
{
  char *ptr;
  if (!*search) return 0;
  ptr = strstr(s, search);
  return (ptr) ? ( (AUDFL_usize_t)(ptr - s) + 1) : 0;
}

//extern "C" int EXPORT fn_strpos_alt ( char *substr, char *str )
TEST_UDF_API __int64 fn_strpos_alt ( char *substr, char *str )
{
  char *avalue;

  if ( strlen ( substr ) == 0 ) return 0;
  if ( strlen ( str ) == 0 ) return 0;

  avalue = strstr ( str, substr );
  if ( avalue == 0 ) return 0;
  return avalue - str + 1;
}

}
