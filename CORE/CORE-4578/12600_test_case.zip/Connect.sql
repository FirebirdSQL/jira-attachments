CONNECT "employee"  USER "sysdba" PASSWORD "masterkey";
commit;

