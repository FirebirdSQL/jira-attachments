input connect.sql;

shell delete_if_exists tmpfile.tmp;

set echo off;
set list on;

output tmpfile.tmp;
select first(1) cast ('show database;' as varchar(255)) from rdb$roles union all
select first(1) cast ('/****/' as varchar(255)) from rdb$roles;
select first(1) cast ('show version;' as varchar(255)) from rdb$roles union all
select first(1) cast ('commit;' as varchar(255)) from rdb$roles;
output;

input tmpfile.tmp;

shell delete_if_exists tmpfile.tmp;

shell dir;
commit;

