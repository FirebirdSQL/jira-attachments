-- From %FB_HOME%\intl\fbintl.conf 

set echo on;
shell del c:\temp\tmp4test.fdb 2>nul;

create database 'localhost:c:\temp\tmp4test.fdb' default character set SJIS_0208 ;
alter character set SJIS_0208 set default collation SJIS_0208;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set SJIS_0208 ;
alter character set SJIS_0208 set default collation SJIS_0208_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------

create database 'localhost:c:\temp\tmp4test.fdb' default character set EUCJ_0208 ;
alter character set EUCJ_0208 set default collation EUCJ_0208;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set EUCJ_0208 ;
alter character set EUCJ_0208 set default collation EUCJ_0208_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  4 3 7  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DOS437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DOS437_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------

create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_DEU437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_ESP437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_FIN437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_FRA437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_ITA437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------

create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_NLD437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_SVE437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_UK437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation DB_US437;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation PDOX_ASCII;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation PDOX_INTL;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set DOS437 ;
alter character set DOS437 set default collation PDOX_SWEDFIN;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  8 5 0  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation dos850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DOS850_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_DEU850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_FRA850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_FRC850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_ITA850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_NLD850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_PTB850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_SVE850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_UK850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos850 ;
alter character set dos850 set default collation DB_US850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--################################   D O S  8 6 5  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos865 ;
alter character set dos865 set default collation dos865;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos865 ;
alter character set dos865 set default collation DOS865_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos865 ;
alter character set dos865 set default collation DB_DAN865;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos865 ;
alter character set dos865 set default collation DB_NOR865;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos865 ;
alter character set dos865 set default collation PDOX_NORDAN4;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##############################  I S O 8 8 5 9 _ 1  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation iso8859_1;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------

create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation ISO8859_1_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation da_da;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation de_de;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation du_nl;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation en_uk;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation en_us;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation es_es;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation es_es_ci_ai;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation fi_fi;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation fr_ca;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation fr_fr;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation is_is;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation it_it;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation no_no;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation sv_sv;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation pt_br;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set iso8859_1 ;
alter character set iso8859_1 set default collation pt_pt;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##############################  I S O 8 8 5 9 _ 2  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_2 ;
alter character set iso8859_2 set default collation ISO8859_2;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_2 ;
alter character set iso8859_2 set default collation ISO8859_2_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_2 ;
alter character set iso8859_2 set default collation CS_CZ;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_2 ;
alter character set iso8859_2 set default collation ISO_HUN;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_2 ;
alter character set iso8859_2 set default collation ISO_PLK;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##############################  I S O 8 8 5 9 _ 3  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_3 ;
alter character set iso8859_3 set default collation ISO8859_3;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_3 ;
alter character set iso8859_3 set default collation ISO8859_3_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##############################  I S O 8 8 5 9 _ 4  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_4 ;
alter character set iso8859_4 set default collation ISO8859_4;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_4 ;
alter character set iso8859_4 set default collation ISO8859_4_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##############################  I S O 8 8 5 9 _ 5  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_5 ;
alter character set iso8859_5 set default collation ISO8859_5;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_5 ;
alter character set iso8859_5 set default collation ISO8859_5_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--##############################  I S O 8 8 5 9 _ 6  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_6 ;
alter character set iso8859_6 set default collation ISO8859_6;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_6 ;
alter character set iso8859_6 set default collation ISO8859_6_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##############################  I S O 8 8 5 9 _ 7  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_7 ;
alter character set iso8859_7 set default collation ISO8859_7;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_7 ;
alter character set iso8859_7 set default collation ISO8859_7_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##############################  I S O 8 8 5 9 _ 8  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_8 ;
alter character set iso8859_8 set default collation ISO8859_8;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_8 ;
alter character set iso8859_8 set default collation ISO8859_8_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--##############################  I S O 8 8 5 9 _ 9  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_9 ;
alter character set iso8859_9 set default collation ISO8859_9;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_9 ;
alter character set iso8859_9 set default collation ISO8859_9_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--##############################  I S O 8 8 5 9 _ 1 3  ###########################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_13 ;
alter character set iso8859_13 set default collation ISO8859_13;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_13 ;
alter character set iso8859_13 set default collation ISO8859_13_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ISO8859_13 ;
alter character set iso8859_13 set default collation LT_LT;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--################################   D O S  8 5 2  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation dos852;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation DOS852_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation DB_CSY;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation DB_PLK;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation DB_SLO;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation PDOX_CSY;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation PDOX_HUN;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation PDOX_PLK;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos852 ;
alter character set dos852 set default collation PDOX_SLO;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--################################   D O S  8 5 7  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos857 ;
alter character set dos857 set default collation dos857;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos857 ;
alter character set dos857 set default collation DOS857_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos857 ;
alter character set dos857 set default collation DB_TRK;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  8 6 0  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos860 ;
alter character set dos860 set default collation dos860;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos860 ;
alter character set dos860 set default collation DOS860_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos860 ;
alter character set dos860 set default collation DB_PTG860;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--################################   D O S  8 6 1  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos861 ;
alter character set dos861 set default collation dos861;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos861 ;
alter character set dos861 set default collation DOS861_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos861 ;
alter character set dos861 set default collation PDOX_ISL;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  8 6 3  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos863 ;
alter character set dos863 set default collation dos863;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos863 ;
alter character set dos863 set default collation DOS863_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos863 ;
alter character set dos863 set default collation DB_FRC863;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   C Y R L  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set cyrl ;
alter character set cyrl set default collation cyrl;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set cyrl ;
alter character set cyrl set default collation cyrl_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set cyrl ;
alter character set cyrl set default collation DB_RUS;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set cyrl ;
alter character set cyrl set default collation PDOX_CYRL;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--################################   D O S  7 3 7  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos737 ;
alter character set dos737 set default collation dos737;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos737 ;
alter character set dos737 set default collation DOS737_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  7 7 5  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos775 ;
alter character set dos775 set default collation dos775;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos775 ;
alter character set dos775 set default collation DOS775_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  8 5 8  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos858 ;
alter character set dos858 set default collation dos858;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos858 ;
alter character set dos858 set default collation DOS858_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  8 6 2  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos862 ;
alter character set dos862 set default collation dos862;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos862 ;
alter character set dos862 set default collation DOS862_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  8 6 4  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos864 ;
alter character set dos864 set default collation dos864;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos864 ;
alter character set dos864 set default collation DOS864_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  8 6 6  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos866 ;
alter character set dos866 set default collation dos866;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos866 ;
alter character set dos866 set default collation DOS866_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   D O S  8 6 9  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set dos869 ;
alter character set dos869 set default collation dos869;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set dos869 ;
alter character set dos869 set default collation DOS869_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--###############################   W I N 1 2 5 0  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation win1250;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation win1250_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation PXW_CSY;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation PXW_HUN;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation PXW_HUNDC;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation PXW_PLK;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation PXW_SLOV;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation BS_BA;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation WIN_CZ;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1250 ;
alter character set win1250 set default collation WIN_CZ_CI_AI;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--###############################   W I N 1 2 5 1  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1251 ;
alter character set win1251 set default collation win1251;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1251 ;
alter character set win1251 set default collation win1251_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1251 ;
alter character set win1251 set default collation PXW_CYRL;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1251 ;
alter character set win1251 set default collation WIN1251_UA;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--###############################   W I N 1 2 5 2  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1252 ;
alter character set win1252 set default collation win1252;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1252 ;
alter character set win1252 set default collation win1252_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1252 ;
alter character set win1252 set default collation PXW_INTL;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1252 ;
alter character set win1252 set default collation PXW_INTL850;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1252 ;
alter character set win1252 set default collation PXW_NORDAN4;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1252 ;
alter character set win1252 set default collation WIN_PTBR;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1252 ;
alter character set win1252 set default collation PXW_SPAN;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1252 ;
alter character set win1252 set default collation PXW_SWEDFIN;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--###############################   W I N 1 2 5 3  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1253 ;
alter character set win1253 set default collation win1253;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1253 ;
alter character set win1253 set default collation win1253_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1253 ;
alter character set win1253 set default collation PXW_GREEK;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--###############################   W I N 1 2 5 4  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1254 ;
alter character set win1254 set default collation win1254;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1254 ;
alter character set win1254 set default collation win1254_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1254 ;
alter character set win1254 set default collation PXW_TURK;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;



--##################################   N E X T   ###############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set next ;
alter character set next set default collation next;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set next ;
alter character set next set default collation NEXT_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set next ;
alter character set next set default collation NXT_DEU;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set next ;
alter character set next set default collation NXT_ESP;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set next ;
alter character set next set default collation NXT_FRA;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set next ;
alter character set next set default collation NXT_ITA;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set next ;
alter character set next set default collation NXT_US;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--###############################   W I N 1 2 5 5  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1255 ;
alter character set win1255 set default collation win1255;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1255 ;
alter character set win1255 set default collation win1255_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--###############################   W I N 1 2 5 6  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1256 ;
alter character set win1256 set default collation win1256;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1256 ;
alter character set win1256 set default collation win1256_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--###############################   W I N 1 2 5 7  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1257 ;
alter character set win1257 set default collation win1257;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1257 ;
alter character set win1257 set default collation win1257_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1257 ;
alter character set win1257 set default collation WIN1257_EE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1257 ;
alter character set win1257 set default collation WIN1257_LT;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1257 ;
alter character set win1257 set default collation WIN1257_LV;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##############################   K S C _ 5 6 0 1  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set ksc_5601 ;
alter character set ksc_5601 set default collation ksc_5601;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ksc_5601 ;
alter character set ksc_5601 set default collation ksc_5601_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set ksc_5601 ;
alter character set ksc_5601 set default collation KSC_DICTIONARY;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--#################################  B I G _ 5  ###############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set big_5 ;
alter character set big_5 set default collation big_5;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set big_5 ;
alter character set big_5 set default collation big_5_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--#############################  G B _ 2 3 1 2  ###############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set gb_2312 ;
alter character set gb_2312 set default collation gb_2312;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set gb_2312 ;
alter character set gb_2312 set default collation gb_2312_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--#############################  K O I 8 R   #################################

create database 'localhost:c:\temp\tmp4test.fdb' default character set koi8r ;
alter character set koi8r set default collation koi8r;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set koi8r ;
alter character set koi8r set default collation koi8r_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set koi8r ;
alter character set koi8r set default collation koi8r_ru;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;

--#############################  K O I 8 U   #################################

create database 'localhost:c:\temp\tmp4test.fdb' default character set koi8u ;
alter character set koi8u set default collation koi8u;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set koi8u ;
alter character set koi8u set default collation koi8u_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set koi8u ;
alter character set koi8u set default collation koi8u_ua;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--###############################   W I N 1 2 5 8  #############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set win1258 ;
alter character set win1258 set default collation win1258;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set win1258 ;
alter character set win1258 set default collation win1258_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;



--################################   T I S 6 2 0 ##############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set tis620 ;
alter character set tis620 set default collation tis620;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set tis620 ;
alter character set tis620 set default collation tis620_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--##################################   G B K   ################################

create database 'localhost:c:\temp\tmp4test.fdb' default character set gbk ;
alter character set gbk set default collation gbk;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set gbk ;
alter character set gbk set default collation gbk_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   C 9 6 4 3 C ##############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set cp943c ;
alter character set cp943c set default collation cp943c;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set cp943c ;
alter character set cp943c set default collation cp943c_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;


--################################   G B 1 8 0 3 0  ##############################

create database 'localhost:c:\temp\tmp4test.fdb' default character set gb18030 ;
alter character set gb18030 set default collation gb18030;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
--------------------------------------------------------------------------------
create database 'localhost:c:\temp\tmp4test.fdb' default character set gb18030 ;
alter character set gb18030 set default collation gb18030_UNICODE;
commit;
recreate view v_info as select f.rdb$field_name as f_name from rdb$fields f where f.rdb$field_name = upper('dm_name');
commit;
drop database;
