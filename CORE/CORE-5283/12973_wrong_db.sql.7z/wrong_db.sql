create database "linserver:/tmp/database.fdb" user "SYSDBA" password "masterkey";
commit;
create table t (f varchar(40));
insert into t values ('A database');
commit;
create database "linserver:/tmp/DATABASE.fdb" user "SYSDBA" password "masterkey";
commit;
create table t (f varchar(40));
insert into t values ('Right database');
commit;
create database "winserver:database3.fdb" user "SYSDBA" password "masterkey";
commit;
connect winserver:database3.fdb user SYSDBA password masterkey;
set term ^;
execute block as
begin
  execute statement 'update t set f = ''Wrong database'''
  on external 'linserver:/tmp/database.fdb' as user 'sysdba' password 'masterkey';
end^
execute block returns(f varchar(40)) as
begin
  for execute statement 'select f from t'
  on external 'linserver:/tmp/DATABASE.fdb' as user 'sysdba' password 'masterkey'
  into f do
      suspend;
end^
set term ;^
