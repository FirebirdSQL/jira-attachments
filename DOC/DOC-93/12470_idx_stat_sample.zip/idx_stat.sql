recreate table t(x int, y int, z int);
create index t_x on t(x);
create index t_y on t(y);
create index t_z on t(z);
commit;
set term ^;
execute block as
  declare n int = 100000;
begin
  while(n>0) do insert into t values(rand()*10, rand()*1000, rand()*100000) returning :n-1 into n;
end^
set term ;^
commit;


set list off;
set heading off;
select 'after initial insert:' from rdb$database;
set heading on;
set list on;
select ri.rdb$relation_name, ri.rdb$index_name, ri.rdb$statistics from rdb$indices ri where ri.rdb$relation_name='T';

set statistics index t_x;
commit;
set statistics index t_y;
commit;
set statistics index t_z;
commit;

set list off;
set heading off;
select 'after 1st set statistics:' from rdb$database;
set heading on;
set list on;
select ri.rdb$relation_name, ri.rdb$index_name, ri.rdb$statistics from rdb$indices ri where ri.rdb$relation_name='T';
select 1.0000000000 / count(distinct x) check_sel_x, 1.0000000000 / count(distinct y) check_sel_y, 1.0000000000 / count(distinct z) check_sel_z from t;

set echo on;
update t set x=y, y=z, z=x; -- 'shift left, cyclic'
commit;
update t set x=x, y=y, z=z; -- remove garbage!
commit;
set echo off;

set statistics index t_x;
commit;
set statistics index t_y;
commit;
set statistics index t_z;
commit;

set list off;
set heading off;
select 'after 2nd set statistics:' from rdb$database;
set heading on;
set list on;
select ri.rdb$relation_name, ri.rdb$index_name, ri.rdb$statistics from rdb$indices ri where ri.rdb$relation_name='T';
select 1.0000000000 / count(distinct x) check_sel_x, 1.0000000000 / count(distinct y) check_sel_y, 1.0000000000 / count(distinct z) check_sel_z from t;


set echo on;
update t set x=y, y=z, z=x; -- 'shift left, cyclic'
commit;
update t set x=x, y=y, z=z; -- remove garbage!
commit;
set echo off;

set statistics index t_x;
commit;
set statistics index t_y;
commit;
set statistics index t_z;
commit;

set list off;
set heading off;
select 'after 3rd set statistics:' from rdb$database;
set heading on;
set list on;
select ri.rdb$relation_name, ri.rdb$index_name, ri.rdb$statistics from rdb$indices ri where ri.rdb$relation_name='T';
select 1.0000000000 / count(distinct x) check_sel_x, 1.0000000000 / count(distinct y) check_sel_y, 1.0000000000 / count(distinct z) check_sel_z from t;

set echo on;
update t set x=1, y=2, z=3;
commit;
update t set x=x, y=y, z=z; -- remove garbage!
commit;
set echo off;

set list off;
set heading off;
select 'after 3rd set statistics:' from rdb$database;
set heading on;
set list on;
select ri.rdb$relation_name, ri.rdb$index_name, ri.rdb$statistics from rdb$indices ri where ri.rdb$relation_name='T';
select 1.0000000000 / count(distinct x) check_sel_x, 1.0000000000 / count(distinct y) check_sel_y, 1.0000000000 / count(distinct z) check_sel_z from t;
