﻿Option Strict On
Option Explicit On

Imports System.Text

Public Class Job

    Private _ID As Integer
    Private _Description As String
    Private _AppPath As String
    Private _AppParm As String
    Private _NextSchedId As Integer
    Private _Enabled As Boolean
    Private WithEvents _Schedules As ScheduleList
    Private _HasChanges As Boolean


    Public ReadOnly Property ID As Integer
        Get
            Return _ID
        End Get
    End Property

    Public Property Description As String
        Get
            Return _Description
        End Get
        Set(ByVal value As String)
            value = value.Trim
            If value.Length > 128 Then Throw New ApplicationException("Limit Job Description To 128 Characters")
            _Description = value
            _HasChanges = True
        End Set
    End Property

    Public Property ApplicationPath As String
        Get
            Return _AppPath
        End Get
        Set(ByVal value As String)
            value = value.Trim
            If value.Length > 511 Then Throw New ApplicationException("Limit Application Path To 511 Characters")
            _AppPath = value
            _HasChanges = True
        End Set
    End Property

    Public Property ApplicationParameters As String
        Get
            Return _AppParm
        End Get
        Set(ByVal value As String)
            value = value.Trim
            If value.Length > 512 Then Throw New ApplicationException("Limit Application Parameters To 512 Characters")
            _AppParm = value
            _HasChanges = True
        End Set
    End Property

    Public ReadOnly Property NextScheduleId As Integer
        Get
            Return _NextSchedId
        End Get
    End Property

    Public Property Enabled As Boolean
        Get
            Return _Enabled
        End Get
        Set(ByVal value As Boolean)
            _Enabled = value
            _HasChanges = True

        End Set
    End Property

    Public ReadOnly Property HasChanges As Boolean
        Get
            Return _HasChanges
        End Get
    End Property

    Public ReadOnly Property Schedules As ScheduleList
        Get
            Return _Schedules
        End Get
    End Property

    Private Sub ScheduleListCleared() Handles _Schedules.ListCleared

        _HasChanges = True

    End Sub

    Private Sub SchedListItmRemoved() Handles _Schedules.ItemRemoved

        _HasChanges = True

    End Sub

    Private Sub SchedListItmAdded(ByVal itm As JobSchedule) Handles _Schedules.ItemAdded

        ' if the item added line item id is > the NextSchedule, increase the next schedule
        If itm.ItemNumber = _NextSchedId Then
            _NextSchedId += 1
        ElseIf itm.ItemNumber > _NextSchedId Then
            Throw New ApplicationException(String.Format("Invalid Schedule Id.  Job: {0}   Itme Number: {1}", itm.JobId, itm.ItemNumber))
        End If

    End Sub

    Public Sub New()
        _ID = -1
        _Description = "New Scheduled Job"
        _AppPath = String.Empty
        _AppParm = String.Empty
        _NextSchedId = 1
        _Enabled = True
        _HasChanges = False
        _Schedules = New ScheduleList()
        _Schedules.Add(NewJobSchedule)

    End Sub

    Public Sub New(ByVal myID As Integer, ByVal myDesc As String, ByVal Path As String, ByVal Parm As String, _
                    ByVal NxtSchedId As Integer, ByVal IsEnabled As Boolean)
        _ID = myID
        _Description = myDesc
        _AppPath = Path
        _AppParm = Parm
        _NextSchedId = NxtSchedId
        _Enabled = IsEnabled
        _HasChanges = False
        _Schedules = New ScheduleList

    End Sub

    Public Function NewJobSchedule() As JobSchedule

        Dim rv As JobSchedule = New JobSchedule(_ID, _NextSchedId)
        _NextSchedId += 1
        Return rv

    End Function

    Public Sub DbConfirm()

       
        ' do a dbConfirm on all job schedules for this job
        For Each js As JobSchedule In _Schedules
            js.DBConfirm()
        Next

        ' set changes flag to false
        _HasChanges = False

    End Sub

    Public Overrides Function ToString() As String
        Dim rv As New StringBuilder
        With rv
            .Append(_ID.ToString)
            .Append(ControlChars.Tab)
            .Append(_AppPath)
            .Append(" ")
            .Append(_AppParm)
        End With

        Return rv.ToString

    End Function

    Public Sub JobSavedToDB(ByVal NewId As Integer)

        If NewId < 0 Then Throw New ApplicationException("Invalid Job ID From Job Save")
        If NewId <> _ID Then
            If _ID < 0 Then
                _ID = NewId
                For Each js As JobSchedule In _Schedules
                    js.CheckJobId(NewId)
                Next

            Else
                Throw New ApplicationException("Attempted Overwrite ID of Existing Job")
            End If
        End If
    End Sub

End Class
