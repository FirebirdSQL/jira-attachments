﻿Option Strict On
Option Explicit On

Public Class ScheduleList
    Implements IList(Of JobSchedule)


    Private _List As List(Of JobSchedule)

    Public Event ItemAdded(ByVal itm As JobSchedule)
    Public Event ItemRemoved()
    Public Event ListCleared()
    Public Event ItemChanged()


    Public Sub New()

        MyBase.New()
        _List = New List(Of JobSchedule)

    End Sub

    Public Sub Add(ByVal item As JobSchedule) Implements System.Collections.Generic.ICollection(Of JobSchedule).Add

        _List.Add(item)
        RaiseEvent ItemAdded(item)

    End Sub

    Public Sub Clear() Implements System.Collections.Generic.ICollection(Of JobSchedule).Clear

        _List.Clear()
        RaiseEvent ListCleared()

    End Sub

    Public Function Contains(ByVal item As JobSchedule) As Boolean Implements System.Collections.Generic.ICollection(Of JobSchedule).Contains

        Return _List.Contains(item)

    End Function

    Public Sub CopyTo(ByVal array() As JobSchedule, ByVal arrayIndex As Integer) Implements System.Collections.Generic.ICollection(Of JobSchedule).CopyTo

        Throw New NotImplementedException

    End Sub

    Public ReadOnly Property Count As Integer Implements System.Collections.Generic.ICollection(Of JobSchedule).Count
        Get
            Return _List.Count
        End Get
    End Property

    Public ReadOnly Property IsReadOnly As Boolean Implements System.Collections.Generic.ICollection(Of JobSchedule).IsReadOnly
        Get
            Throw New NotImplementedException
        End Get
    End Property

    Public Function Remove(ByVal item As JobSchedule) As Boolean Implements System.Collections.Generic.ICollection(Of JobSchedule).Remove

        Dim rv As Boolean = _List.Remove(item)
        If rv = True Then RaiseEvent ItemRemoved()
        Return rv

    End Function

    Public Function GetEnumerator() As System.Collections.Generic.IEnumerator(Of JobSchedule) Implements System.Collections.Generic.IEnumerable(Of JobSchedule).GetEnumerator
        Return _List.GetEnumerator
    End Function

    Public Function IndexOf(ByVal item As JobSchedule) As Integer Implements System.Collections.Generic.IList(Of JobSchedule).IndexOf
        Return _List.IndexOf(item)
    End Function

    Public Sub Insert(ByVal index As Integer, ByVal item As JobSchedule) Implements System.Collections.Generic.IList(Of JobSchedule).Insert

        _List.Insert(index, item)
        RaiseEvent ItemAdded(item)

    End Sub

    Default Public Property Item(ByVal index As Integer) As JobSchedule Implements System.Collections.Generic.IList(Of JobSchedule).Item
        Get
            Return _List.Item(index)
        End Get
        Set(ByVal value As JobSchedule)
            _List.Item(index) = value
            RaiseEvent ItemChanged()
        End Set
    End Property

    Public Sub RemoveAt(ByVal index As Integer) Implements System.Collections.Generic.IList(Of JobSchedule).RemoveAt

        _List.RemoveAt(index)
        RaiseEvent ItemRemoved()

    End Sub

    Public Function GetEnumerator1() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
        Return _List.GetEnumerator
    End Function
End Class
