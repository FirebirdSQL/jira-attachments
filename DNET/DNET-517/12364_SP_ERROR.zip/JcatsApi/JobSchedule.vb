﻿Option Strict On
Option Explicit On

Imports System.Text
Imports System.Text.RegularExpressions

Public Class JobSchedule

    Public Class DaySchedule

        Private _Day As DayOfWeek
        Private _Scheduled As Boolean

        Public Event DaySchedChanged()

        Public ReadOnly Property DayScheduled As DayOfWeek
            Get
                Return _Day
            End Get
        End Property

        Public Property Scheduled As Boolean
            Get
                Return _Scheduled
            End Get
            Set(ByVal value As Boolean)
                _Scheduled = value
                RaiseEvent DaySchedChanged()
            End Set
        End Property

        Public Sub New(ByVal d As DayOfWeek, ByVal sched As Boolean)

            _Day = d
            _Scheduled = sched

        End Sub

        Public Overrides Function ToString() As String
            Dim rv As String = String.Format("{0}:{1}", CType(_Day, Integer), CType(_Scheduled, Integer))
            Return rv
        End Function

    End Class

    Private _JobId As Integer
    Private _JobsId As Integer
    Private _JobsStart As Date
    Private _JobsEnd As Date
    Private WithEvents _JobsDays As List(Of DaySchedule)
    Private _JobsTime As Date
    Private _JobsEnabled As Boolean
    Private _hasChanges As Boolean
    Private _JobsMonthlySched As Boolean
    Private _JobsDayOfMonth As Integer


    Public ReadOnly Property JobId As Integer
        Get
            Return _JobId
        End Get
    End Property

    Public ReadOnly Property ItemNumber As Integer
        Get
            Return _JobsId
        End Get
    End Property

    Public Property StartDate As Date
        Get
            Return _JobsStart
        End Get
        Set(ByVal value As Date)
            _JobsStart = value
            _hasChanges = True
        End Set
    End Property

    Public Property EndDate As Date
        Get
            Return _JobsEnd
        End Get
        Set(ByVal value As Date)
            _JobsEnd = value
            _hasChanges = True

        End Set
    End Property

    Public ReadOnly Property ScheduledDays As List(Of DaySchedule)
        Get
            Return _JobsDays
        End Get
    End Property

    Public Property ScheduledTime As Date
        Get
            Return _JobsTime
        End Get
        Set(ByVal value As Date)
            _JobsTime = value
            _hasChanges = True
        End Set
    End Property

    Public ReadOnly Property HasChanges As Boolean
        Get
            Return _hasChanges
        End Get
    End Property

    Public Property MonthlySchedule As Boolean
        Get
            Return _JobsMonthlySched

        End Get
        Set(ByVal value As Boolean)
            ' set the value of the monthly schedule to the value submitted
            _JobsMonthlySched = value

            ' when the value submitted is true, loop through the job days and set the schedule value for each to true
            If value = True Then
                For Each ds As DaySchedule In _JobsDays
                    ds.Scheduled = True
                Next
            End If

            ' set the value of has changes
            _hasChanges = True
        End Set
    End Property

    Public Property DayOfMonth As Integer
        Get
            Return _JobsDayOfMonth

        End Get
        Set(ByVal value As Integer)
            ' validate the value submitted
            If value < 1 Then Throw New ApplicationException("Day of Month value has to be between 1 and 31")
            If value > 31 Then Throw New ApplicationException("Day of Month value has to be between 1 and 31")

            ' set the value
            _JobsDayOfMonth = value

            ' set the has changes flag
            _hasChanges = True
        End Set
    End Property

    Public Property Enabled As Boolean
        Get
            Return _JobsEnabled
        End Get
        Set(ByVal value As Boolean)
            _JobsEnabled = value
            _hasChanges = True
        End Set
    End Property

    Public Sub New(ByVal JobID As Integer, ByVal LineItem As Integer)

        _JobId = JobID
        _JobsId = LineItem
        _JobsEnabled = True
        _JobsEnd = #12:00:00 AM#
        _JobsStart = Today
        _JobsTime = Now
        _hasChanges = False
        _JobsDayOfMonth = 1
        _JobsMonthlySched = False

        ' set the default list of days
        _JobsDays = New List(Of DaySchedule)
        _JobsDays.Add(New DaySchedule(DayOfWeek.Sunday, False))
        _JobsDays.Add(New DaySchedule(DayOfWeek.Monday, False))
        _JobsDays.Add(New DaySchedule(DayOfWeek.Tuesday, False))
        _JobsDays.Add(New DaySchedule(DayOfWeek.Wednesday, False))
        _JobsDays.Add(New DaySchedule(DayOfWeek.Thursday, False))
        _JobsDays.Add(New DaySchedule(DayOfWeek.Friday, False))
        _JobsDays.Add(New DaySchedule(DayOfWeek.Saturday, False))

        For Each ds As DaySchedule In _JobsDays
            AddHandler ds.DaySchedChanged, AddressOf SchedChanged
        Next

    End Sub

    Public Function ScheduledDaysShortHand() As String

        Dim rValue As New StringBuilder
        For Each ds As DaySchedule In _JobsDays
            rValue.Append(ds.ToString)
            If ds.DayScheduled <> DayOfWeek.Saturday Then
                rValue.Append("|")
            End If
        Next

        Return rValue.ToString

    End Function

    Public Sub CheckJobId(ByVal newJobId As Integer)

        If (newJobId <> _JobId) Then

            If _JobId <= 0 Then
                _JobId = newJobId
            Else
                Throw New ApplicationException("Error Confirming Job Schedule")
            End If

        ElseIf newJobId < 0 Then
            Throw New ApplicationException("Invalid Job Id for Job Schedule")

        End If

    End Sub

    Public Sub DBConfirm()

        _hasChanges = False

    End Sub

    Public Overrides Function ToString() As String

        Return String.Format("Job Id: {0} Schedule: {1}", _JobId, _JobsId)

    End Function

    Private Sub SchedChanged()

        ' set the has changes flag
        _hasChanges = True

    End Sub

End Class
