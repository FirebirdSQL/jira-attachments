﻿Option Strict On
Option Explicit On

Imports FirebirdSql.Data.FirebirdClient
Imports System.Text
Imports System.Text.RegularExpressions

Public Class DbStore

    Private _CSB As FbConnectionStringBuilder

    Public ReadOnly Property DatabaseName As String
        Get
            Return _CSB.Database
        End Get
    End Property

    Public ReadOnly Property DatabaseUser As String
        Get
            Return _CSB.UserID
        End Get
    End Property

    Public ReadOnly Property DatabasePassword As String
        Get
            Return _CSB.Password
        End Get
    End Property

    Public Sub New(ByVal CSB As String)

        ' set the value of the connection string builder
        _CSB = New FbConnectionStringBuilder(CSB)

        ' test the connection
        Using cn As New FbConnection(_CSB.ToString)
            cn.Open()

            Using cm As FbCommand = cn.CreateCommand
                cm.CommandText = "select current_date from rdb$database"
                Dim o As Object = cm.ExecuteScalar

            End Using
        End Using

    End Sub

    Public Sub DeleteJob(ByVal JobId As Integer)

        Dim cn As FbConnection = Nothing
        Dim tx As FbTransaction = Nothing

        Try
            ' connect to the database
            cn = New FbConnection(_CSB.ToString)
            cn.Open()
            tx = cn.BeginTransaction

            Using cm As FbCommand = cn.CreateCommand
                cm.Transaction = tx
                cm.CommandType = CommandType.StoredProcedure
                cm.CommandText = "SP_JOB_DELETE"
                FbCommandBuilder.DeriveParameters(cm)

                ' set value of parameters
                cm.Parameters.Item("@I_JOB_ID").Value = JobId

                ' execute the procedure
                cm.ExecuteNonQuery()

                ' commit the trx
                tx.Commit()
                tx.Dispose()
                cn.Close()

            End Using

        Finally
            ' catch errors in db transaction and roll them back
            If tx IsNot Nothing Then
                If tx.Connection IsNot Nothing Then
                    tx.Rollback()
                    tx.Dispose()
                End If
            End If

            ' clean up the connection to the db
            If cn IsNot Nothing Then cn.Dispose()

        End Try

    End Sub

    Public Function LoadJob(ByVal ID As Integer) As Job

        Dim rv As Job = Nothing
        Dim dr As FbDataReader = Nothing
        Dim dt As DataTable = Nothing

        Try
            ' connect to database
            Using cn As New FbConnection(_CSB.ToString)
                cn.Open()

                Using cm As FbCommand = cn.CreateCommand
                    cm.CommandText = "select * from job where job_id = ?"
                    cm.Parameters.Add( _
                        New FbParameter("@I_JOB_ID", FbDbType.Integer)).Value = ID

                    dr = cm.ExecuteReader
                    If dr.HasRows Then

                        If dr.Read Then
                            rv = New Job(CType(dr.Item("JOB_ID"), Integer), dr.Item("JOB_DESC").ToString, dr.Item("JOB_APP_PATH").ToString, _
                                         dr.Item("JOB_APP_PARM").ToString, CType(dr.Item("JOB_NEXT_SCHED_ID"), Integer), _
                                         CType(dr.Item("JOB_IS_ENABLED"), Boolean))


                            ' change the sql statement to get the list of jobschedules for the job
                            cm.CommandText = "select job_id, jobs_id from jobsched where job_id = ? order by jobs_id asc"
                            Using da As New FbDataAdapter(cm)
                                dt = New DataTable
                                da.Fill(dt)

                                For Each jobsRow As DataRow In dt.Rows
                                    rv.Schedules.Add(LoadJobSchedule(rv.ID, CType(jobsRow.Item("JOBS_ID"), Integer)))
                                Next

                            End Using

                        End If

                    End If

                End Using
            End Using

            If rv IsNot Nothing Then rv.DbConfirm()

        Finally
            If dr IsNot Nothing Then
                If Not dr.IsClosed Then dr.Close()
                dr = Nothing
            End If

            If dt IsNot Nothing Then dt.Dispose()

        End Try


        Return rv

    End Function

    Public Sub SaveJob(ByVal J As Job, ByVal UserName As String)

        Dim tx As FbTransaction = Nothing
        Dim cn As FbConnection = Nothing

        Try
            ' connect to database
            cn = New FbConnection(_CSB.ToString)
            cn.Open()
            tx = cn.BeginTransaction

            ' create a command to save the job
            Using cm As FbCommand = cn.CreateCommand
                cm.Transaction = tx
                cm.CommandType = CommandType.StoredProcedure
                cm.CommandText = "SP_JOB_SAVE"
                FbCommandBuilder.DeriveParameters(cm)

                With cm.Parameters
                    .Item("@I_JOB_ID").Value = J.ID
                    .Item("@I_JOB_DESC").Value = J.Description
                    .Item("@I_JOB_PATH").Value = J.ApplicationPath
                    .Item("@I_JOB_PARM").Value = J.ApplicationParameters
                    .Item("@I_JOB_NEXT_SCHED_ID").Value = J.NextScheduleId
                    .Item("@I_JOB_MODIFY_BY").Value = UserName
                    .Item("@I_JOB_IS_ENABLED").Value = CType(J.Enabled, Integer)
                End With

                ' save the job
                cm.ExecuteNonQuery()
                J.JobSavedToDB(CType(cm.Parameters.Item("@O_JOB_ID").Value, Integer))

                ' now change the command text to save the job schedules for the job
                cm.CommandText = "SP_JOBSCHED_SAVE"
                cm.Parameters.Clear()
                FbCommandBuilder.DeriveParameters(cm)

                ' loop thru the job schedules and save them
                For Each js As JobSchedule In J.Schedules

                    ' set the parameter values
                    With cm.Parameters
                        .Item("@I_JOB_ID").Value = J.ID
                        .Item("@I_JOBS_ID").Value = js.ItemNumber
                        .Item("@I_JOBS_START").Value = js.StartDate
                        .Item("@I_JOBS_END").Value = js.EndDate
                        .Item("@I_JOBS_TIME").Value = js.ScheduledTime
                        .Item("@I_JOBS_DAYS").Value = js.ScheduledDaysShortHand
                        .Item("@I_JOBS_DAY_OF_MONTH").Value = js.DayOfMonth
                        .Item("@I_JOBS_IS_MONTHLY_SCHEDULE").Value = CType(js.MonthlySchedule, Integer)
                        .Item("@I_JOBS_IS_ENABLED").Value = CType(js.Enabled, Integer)
                    End With

                    ' execute the command
                    cm.ExecuteNonQuery()

                Next

                ' all saving has been completed
                tx.Commit()
                tx.Dispose()
                cn.Close()
                tx = Nothing

                ' confirm save to database
                J.DbConfirm()

            End Using


        Finally

            If tx IsNot Nothing Then
                If tx.Connection IsNot Nothing Then
                    tx.Rollback()
                    tx.Dispose()
                End If
            End If

            If cn IsNot Nothing Then cn.Dispose()

        End Try
    End Sub

    Public Function JobList() As List(Of Job)

        Dim rv As New List(Of Job)
        Dim dr As FbDataReader = Nothing

        Try
            ' connect to database
            Using cn As New FbConnection(_CSB.ToString)
                cn.Open()

                Using cm As FbCommand = cn.CreateCommand
                    cm.CommandText = "select job_id from job"
                    dr = cm.ExecuteReader

                    Do Until Not dr.Read
                        rv.Add(LoadJob(CType(dr.Item("JOB_ID"), Integer)))
                    Loop

                    dr.Close()

                End Using
            End Using

        Finally
            If dr IsNot Nothing Then
                If Not dr.IsClosed Then dr.Close()
                dr = Nothing
            End If

        End Try

        Return rv

    End Function

    Public Function JobQueueSchedule(Optional ByVal ShowProcessed As Boolean = False, Optional ByVal SchedAfter As Date = #12:00:00 AM#) As JobQueueDS

        Dim ds As JobQueueDS = New JobQueueDS

        Using cn As New FbConnection(_CSB.ToString)
            cn.Open()

            Using cm As FbCommand = cn.CreateCommand

                ' determine what sql to execute
                'Dim sqlStmt As String = "select * from jobq "
                Dim sqlStmt As New StringBuilder(84)
                With sqlStmt
                    .Append("select ")
                    .Append("jobq.jobq_id, jobq.jobq_cmd, jobq.jobq_exec_date, ")
                    .Append("cast (jobq.jobq_exec_time as varchar(25)) jobq_exec_time, ")
                    .Append("jobq.jobq_req_date, jobq.jobq_req_user, jobq.jobq_processed, ")
                    .Append("jobq.jobq_ran, jobq.job_id, jobq.jobs_id, ")
                    .Append("job.job_desc ")
                    .Append("from jobq ")
                    .Append("left outer join job on job.job_id = jobq.job_id ")
                End With

                If Not ShowProcessed Then
                    sqlStmt.Append("where jobq_processed = 0 ")

                Else

                    ' determine if the user wants to filter based on processed date
                    ' if the processed date submitted is null (#1/1/1#) then no filter added to sql
                    If Not SchedAfter.Equals(#12:00:00 AM#) Then
                        ' add the filter to the sql statement
                        sqlStmt.Append("where jobq_req_date >= @I_JOBQ_REQ_DATE ")
                    End If

                End If
                sqlStmt.Append("order by jobq.jobq_exec_date, jobq.jobq_exec_time ")

                cm.CommandText = sqlStmt.ToString
                If Regex.IsMatch(cm.CommandText, "\@I_JOBQ_REQ_DATE") Then
                    cm.Parameters.Add( _
                        New FbParameter("@I_JOBQ_REQ_DATE", FbDbType.Date)).Value = SchedAfter
                End If

                Using da As New FbDataAdapter(cm)
                    da.Fill(ds, "JOBQ")
                End Using
            End Using
        End Using


        Return ds

    End Function

    Public Function JobQueueCurrent() As JobQueueDS

        Dim ds As JobQueueDS = New JobQueueDS
        Dim dbSql As New StringBuilder
        With dbSql
            .Append("select cj.jobq_id, cj.jobq_cmd, ")
            .Append("cj.jobq_exec_date, cast(cj.jobq_exec_time as varchar(25)) jobq_exec_time, ")
            .Append("cj.jobq_req_date, cj.jobq_req_user, cj.jobq_processed, ")
            .Append("cj.jobq_ran, cj.job_id, cj.jobs_id ")
            .Append("from vu_current_jobs cj")
        End With

        Using cn As New FbConnection(_CSB.ToString)
            cn.Open()

            Using cm As FbCommand = cn.CreateCommand
                'cm.CommandText = "select * from VU_CURRENT_JOBS"
                cm.CommandText = dbSql.ToString
                Using da As New FbDataAdapter(cm)
                    da.Fill(ds.JOBQ)
                End Using
            End Using
        End Using

        Return ds

    End Function

    Public Function AddJobToQueue(ByVal cmd As String, ByVal execDate As Date, ByVal execTime As Date, ByVal theUser As String, Optional ByVal JobId As Integer = -1, Optional ByVal JobsId As Integer = -1) As Guid

        Dim rv As Guid = Nothing
        Dim cn As FbConnection = Nothing
        Dim tx As FbTransaction = Nothing


        Try
            ' connect to the database
            cn = New FbConnection(_CSB.ToString)
            cn.Open()
            tx = cn.BeginTransaction

            ' set up the command
            Using cm As FbCommand = cn.CreateCommand
                cm.Transaction = tx
                cm.CommandType = CommandType.Text
                cm.CommandText = "execute procedure SP_JOBQ_ADD(?,?,?,?,?,?)"

                'FbCommandBuilder.DeriveParameters(cm)

                With cm.Parameters
                    .Add(New FbParameter("@I_JOBQ_CMD", FbDbType.VarChar, 1024)).Value = cmd
                    .Add(New FbParameter("@I_JOBQ_EXEC_DATE", FbDbType.Date)).Value = execDate
                    .Add(New FbParameter("@I_JOBQ_EXEC_TIME", FbDbType.Time)).Value = execTime
                    .Add(New FbParameter("@I_JOBQ_REQ_USER", FbDbType.VarChar, 128)).Value = theUser
                    .Add(New FbParameter("@I_JOBQ_JOB_ID", FbDbType.Integer)).Value = JobId
                    .Add(New FbParameter("@I_JOBQ_JOBS_ID", FbDbType.Integer)).Value = JobsId
                End With

                'With cm.Parameters
                '    .Item("@I_JOBQ_CMD").Value = cmd
                '    .Item("@I_JOBQ_EXEC_DATE").Value = execDate
                '    .Item("@I_JOBQ_EXEC_TIME").Value = execTime
                '    .Item("@I_JOBQ_REQ_USER").Value = theUser
                '    .Item("@I_JOB_ID").Value = JobId
                '    .Item("@I_JOBS_ID").Value = JobsId
                'End With

                cm.ExecuteNonQuery()
                rv = CType(cm.Parameters.Item("@O_JOBQ_ID").Value, Guid)

                tx.Commit()
                tx.Dispose()
                cn.Close()

            End Using

        Finally
            If tx IsNot Nothing Then
                If tx.Connection IsNot Nothing Then
                    tx.Rollback()
                    tx.Dispose()
                    tx = Nothing
                End If
            End If

            If cn IsNot Nothing Then cn.Dispose()

        End Try

        Return rv

    End Function

    Public Function DeleteFromJobQueue(ByVal JobQId As Guid) As Boolean

        Dim rv As Boolean = False
        Dim cn As FbConnection = Nothing
        Dim tx As FbTransaction = Nothing

        Try
            cn = New FbConnection(_CSB.ToString)
            cn.Open()
            tx = cn.BeginTransaction

            Using cm As FbCommand = cn.CreateCommand
                cm.Transaction = tx
                cm.CommandText = "SP_JOBQ_DELETE"
                cm.CommandType = CommandType.StoredProcedure
                FbCommandBuilder.DeriveParameters(cm)
                cm.Parameters.Item("@I_JOBQ_ID").Value = JobQId.ToByteArray
                cm.ExecuteNonQuery()
                tx.Commit()
                tx.Dispose()
                cn.Close()
                rv = True
            End Using
        Finally
            If tx IsNot Nothing Then
                If tx.Connection IsNot Nothing Then
                    tx.Rollback()
                    tx.Dispose()
                    rv = False
                End If
            End If

            If cn IsNot Nothing Then cn.Dispose()

        End Try


        Return rv

    End Function

    Public Function ProcessJobQueueItem(ByVal JobQId As Guid, ByVal JobRan As Boolean) As Boolean

        Dim rv As Boolean = False
        Dim cn As FbConnection = Nothing
        Dim tx As FbTransaction = Nothing

        Try
            ' connect to the database
            cn = New FbConnection(_CSB.ToString)
            cn.Open()
            tx = cn.BeginTransaction

            ' create the command and set the transaction
            Using cm As FbCommand = cn.CreateCommand
                cm.Transaction = tx

                ' set the command type and get the parameters
                cm.CommandType = CommandType.StoredProcedure
                cm.CommandText = "SP_JOBQ_PROCESS_COMPLETE"
                FbCommandBuilder.DeriveParameters(cm)

                ' set the value of the parameters
                With cm.Parameters
                    .Item("@I_JOBQ_ID").Value = JobQId.ToByteArray
                    .Item("@I_JOBQ_RAN").Value = CType(JobRan, Integer)
                End With

                ' execute the command
                cm.ExecuteNonQuery()

               
            End Using

            ' commit the transaction
            tx.Commit()
            tx.Dispose()
            cn.Close()
            rv = True

        Finally
            ' roll back the transaction if there was a failure and set the return value to false
            If tx IsNot Nothing Then
                If tx.Connection IsNot Nothing Then
                    tx.Rollback()
                    tx.Dispose()
                    rv = False
                End If
            End If
        End Try

        ' send back the result
        Return rv

    End Function

    ''' <summary>
    ''' Reset the JOBQ_PROCESSED and JOBQ_RAN flags for submitted queue id to false
    ''' </summary>
    ''' <param name="JobQId">JOB QUEUE ID</param>
    ''' <returns></returns>
    ''' <remarks>Causes a job queue entry that is flagged as complete to run again at the next opportunity</remarks>
    Public Function ReProcessJobQItem(ByVal JobQId As Guid) As Boolean

        Dim rv As Boolean = False
        Dim cn As FbConnection = Nothing
        Dim tx As FbTransaction = Nothing

        Try
            ' connect to the database
            cn = New FbConnection(_CSB.ToString)
            cn.Open()
            tx = cn.BeginTransaction

            ' create the command and set the transaction
            Using cm As FbCommand = cn.CreateCommand
                cm.Transaction = tx

                ' set the command type and get the parameters
                cm.CommandType = CommandType.Text
                cm.CommandText = "update jobq set jobq_processed = 0, jobq_ran = 0 where jobq_id = @I_JOBQ_ID"
                Dim pr As New FbParameter("@I_JOBQ_ID", FbDbType.Char, 16)
                pr.Charset = FbCharset.Octets
                pr.Direction = ParameterDirection.Input
                pr.Value = JobQId.ToByteArray
                cm.Parameters.Add(pr)

                ' execute the command
                cm.ExecuteNonQuery()


            End Using

            ' commit the transaction
            tx.Commit()
            tx.Dispose()
            cn.Close()
            rv = True

        Finally
            ' roll back the transaction if there was a failure and set the return value to false
            If tx IsNot Nothing Then
                If tx.Connection IsNot Nothing Then
                    tx.Rollback()
                    tx.Dispose()
                    rv = False
                End If
            End If
        End Try

        ' send back the result
        Return rv

    End Function

    Public Sub RecreateJobQueue(ByVal j As Job)

        Dim cn As FbConnection = Nothing
        Dim tx As FbTransaction = Nothing

        Try
            ' connect to the datastore
            cn = New FbConnection(_CSB.ToString)
            cn.Open()
            tx = cn.BeginTransaction

            ' set up the command to re-create entries in the jobq for the submitted job
            Using cm As FbCommand = cn.CreateCommand
                cm.Transaction = tx
                cm.CommandType = CommandType.StoredProcedure
                cm.CommandText = "SP_JOB_RECREATE_QUEUE"
                FbCommandBuilder.DeriveParameters(cm)

                ' set the value of the parameters
                cm.Parameters.Item("@I_JOB_ID").Value = j.ID

                ' execute the command 
                cm.ExecuteNonQuery()

            End Using

            ' commit the transaction and close the connection
            tx.Commit()
            tx.Dispose()
            cn.Close()

        Finally
            ' roll back the transaction if there was a error
            If tx IsNot Nothing Then
                If tx.Connection IsNot Nothing Then
                    tx.Rollback()
                    tx.Dispose()
                End If
            End If

            If cn IsNot Nothing Then cn.Dispose()

        End Try

    End Sub

    Private Function LoadJobSchedule(ByVal jobId As Integer, ByVal SchedItmNo As Integer) As JobSchedule

        Dim rv As JobSchedule = Nothing
        Dim dr As FbDataReader = Nothing

        Try
            ' connect to the database
            Using cn As FbConnection = New FbConnection(_CSB.ToString)
                cn.Open()

                Using cm As FbCommand = cn.CreateCommand
                    cm.CommandText = "select * from jobsched where job_id = ? and jobs_id = ?"
                    cm.Parameters.Add( _
                        New FbParameter("@I_JOB_ID", FbDbType.Integer)).Value = jobId
                    cm.Parameters.Add( _
                        New FbParameter("@I_JOBS_ID", FbDbType.Integer)).Value = SchedItmNo

                    dr = cm.ExecuteReader

                    If dr.HasRows Then
                        If dr.Read Then
                            rv = New JobSchedule(jobId, SchedItmNo)
                            rv.StartDate = CType(dr.Item("JOBS_START"), Date)
                            rv.EndDate = CType(dr.Item("JOBS_END"), Date)
                            rv.Enabled = CType(dr.Item("JOBS_IS_ENABLED"), Boolean)
                            rv.ScheduledTime = CType(dr.Item("JOBS_TIME").ToString, Date)

                            ' set the daily schedule
                            Dim daySchedules() As String = Regex.Split(dr.Item("JOBS_DAYS").ToString, "\|")
                            Dim theDay() As String = Nothing
                            For Each daySched As String In daySchedules
                                theDay = Regex.Split(daySched, "\:")

                                For Each ds As JobSchedule.DaySchedule In rv.ScheduledDays
                                    If CType(theDay(0), DayOfWeek) = ds.DayScheduled Then
                                        ds.Scheduled = CType(theDay(1), Boolean)
                                    End If
                                Next

                            Next

                            rv.MonthlySchedule = CType(dr.Item("JOBS_IS_MONTHLY_SCHEDULE"), Boolean)
                            rv.DayOfMonth = CType(dr.Item("JOBS_DAY_OF_MONTH"), Integer)

                        End If

                    End If

                End Using

            End Using

            If rv IsNot Nothing Then rv.DBConfirm()

        Finally
            If dr IsNot Nothing Then
                If Not dr.IsClosed Then
                    dr.Close()
                    dr = Nothing
                End If
            End If

        End Try


        Return rv

    End Function

End Class
