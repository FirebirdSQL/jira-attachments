using System;
using FirebirdSql.Data.FirebirdClient;
using FirebirdSql.Data.Services;

namespace ServicesTest
{
    class Program
    {
        static void Main(string[] args)
        {            
            FbConnectionStringBuilder csb = new FbConnectionStringBuilder();
            csb.UserID = "SYSDBA";
            csb.Password = "masterkey";
            csb.DataSource = "firebird15";

            FbSecurity fbSecurity = new FbSecurity();
            fbSecurity.ConnectionString = csb.ToString();
            FbUserData[] fud = fbSecurity.DisplayUsers();
            Console.WriteLine("{0} users", fud.Length);
        }
    }
}
