﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbPerfTest2
{

    public class PerfTest : DbContext
    {
        public DbSet<kunde> Kunden { get; set; }

        public PerfTest()
          : base()
        {

        }

        public PerfTest(DbConnection existingConnection, bool contextOwnsConnection)
          : base(existingConnection, contextOwnsConnection)
        {
            this.Configuration.LazyLoadingEnabled = true;
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<kunde>().ToTable("kunde");
        }
    }

    public class kunde
    {
        public int id { get; set; }
        public String name { get; set; }
        public String plz { get; set; }
        public String ort { get; set; }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            // DbConfiguration.SetConfiguration(new FbEFConfiguration());

            // Problem:
            bool pooling = true;
            int connections = 100;
            int selects = 1000;
            

            // Problem:
            /*
            bool pooling = false;
            int connections = 1;
            int selects = 100000;
            */

            // NO Problem:
            /*
            bool pooling = false;
            int connections = 100;
            int selects = 1000;
            */

            String constr = $@"User=SYSDBA;Password=masterkey;Database=L:\Datenbank\FB300\perftest\perftest.fdb;DataSource=localhost;Port=3050;Dialect=3;Charset=UTF8;Pooling={pooling};ServerType=0";

            
            DateTime start = DateTime.Now;

            // Parallel.For(0, 1000, new ParallelOptions { MaxDegreeOfParallelism = 4 }, (j) =>
            for (int j = 0; j < connections; j++)
            {

                using (FbConnection con = new FbConnection())
                {
                    con.ConnectionString = constr;
                    con.Open();

                    // using (DbTransaction trans = con.BeginTransaction())
                    using (PerfTest ctx = new PerfTest(con, false))
                    {
                        // ctx.Database.UseTransaction(trans);

                        for (int i = 0; i < selects; i++)
                        {
                            var test =
                                from k in ctx.Kunden
                                where k.id == 1000
                                select k;

                            var k1 = test.Single();

                        }
                    }
                }

                Console.WriteLine($"j={j}");
            };

            DateTime end = DateTime.Now;

            double s = (end - start).TotalSeconds;

            Console.WriteLine($"Selecting: {s} s");


            Console.WriteLine("Press any key to continue");
            Console.Read();
        }
    }
}
