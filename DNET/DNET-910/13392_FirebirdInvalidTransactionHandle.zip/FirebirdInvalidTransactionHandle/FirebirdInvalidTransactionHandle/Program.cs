﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FirebirdInvalidTransactionHandle
{
    class Program
    {
        static void Main(string[] args)
        {
            string sConnectionString = @"initial catalog=C:\Program Files\Firebird\Firebird_2_5\examples\empbuild\EMPLOYEE.FDB;character set=NONE;server type=Default;user id=SYSDBA;password=masterkey;data source=localhost;port number=3050";
            Random rnd = new Random();
            
            Thread th = null;
            StartMultiThreaded(() => {
                for(int i = 0; i < 10; i++)
                {
                    th?.Abort();
                        
                    try
                    {
                        th = new Thread(() => {
                            try
                            {
                                using(IDbConnection con = new FirebirdSql.Data.FirebirdClient.FbConnection(sConnectionString))
                                {
                                    con.Open();
                                    while(true)
                                    {
                                        IDbCommand cmd = con.CreateCommand();
                                        cmd.CommandText = "SELECT COUNT(*) FROM CUSTOMER";
                                        cmd.ExecuteScalar();
                                    }
                                }
                            }
                            catch(Exception ex)
                            {
                                System.Diagnostics.Debug.Assert(!ex.Message.Contains("invalid transaction handle"), ex.Message);
                            }
                        });
                            
                        th.Start();
                    }
                    catch(Exception ex)
                    {
                        System.Diagnostics.Debug.Assert(!ex.Message.Contains("invalid transaction handle"), ex.Message);
                    }

                    Thread.Sleep(rnd.Next(300, 500));
                }
            }, 10);
            
        }
        
        private static void StartMultiThreaded(Action x_Method, int x_ThreadCount)
        {
            for (int i = 0; i < x_ThreadCount; i++)
            {
                Thread th = new Thread(new ThreadStart(x_Method));
                th.Start();
            }
        }
    }
}
