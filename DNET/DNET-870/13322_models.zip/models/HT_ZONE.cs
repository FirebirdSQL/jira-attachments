namespace Rezervari.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class HT_ZONE
    {
        public int ID { get; set; }
        public string DENUMIRE { get; set; }
        public virtual ICollection<HT_CAMERE> HT_CAMERE { get; set; }
    }
}
