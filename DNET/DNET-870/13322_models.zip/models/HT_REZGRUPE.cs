
namespace Rezervari.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class HT_REZGRUPE
    {
        public HT_REZGRUPE()
        {
            this.HT_REZERVARI = new HashSet<HT_REZERVARI>();
        }
    
        public long ID { get; set; }
        public long IDCF { get; set; }
        public string DENUMIRE { get; set; }
        public System.DateTime DATA { get; set; }
    
        public virtual CF CF { get; set; }
        public virtual ICollection<HT_REZERVARI> HT_REZERVARI { get; set; }
    }
}
