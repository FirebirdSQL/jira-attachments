namespace Rezervari.Models
{
    public partial class HT_PLATI
    {
        public long ID { get; set; }
        public long IDCAZARE { get; set; }
        public decimal? VALOARE { get; set; }
        public short? TIP { get; set; }
        public decimal? CANTITATE { get; set; }
        public short? TIPFC { get; set; }
    
        public virtual HT_REZERVARI HT_REZERVARI { get; set; }
    }
}
