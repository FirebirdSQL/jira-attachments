namespace Rezervari.Models
{
    using System;
    
    public partial class HT_INFEXPED
    {
        public long ID { get; set; }
        public long ID_EXPED { get; set; }
        public Nullable<System.DateTime> DATA_E { get; set; }
        public Nullable<decimal> NR_CHIT { get; set; }
        public Nullable<System.DateTime> DATA_CHIT { get; set; }
        public Nullable<System.TimeSpan> ORA_E { get; set; }
        public Nullable<short> CU_CHITANTA { get; set; }
        public Nullable<decimal> CURS { get; set; }
        public long ID_INTOCMITOR { get; set; }
        public Nullable<decimal> SUMA_CHIT { get; set; }
        public long NRFACT { get; set; }
        public Nullable<short> TIP { get; set; }
        public Nullable<System.DateTime> DATAF { get; set; }
        public string SERIE { get; set; }
        public Nullable<long> NRFACTANTER { get; set; }
        public Nullable<short> INENG { get; set; }
        public long ID_REZERVARE { get; set; }
        public virtual HT_REZERVARI HT_REZERVARI { get; set; }
        public virtual GS_EXPED GS_EXPED { get; set; }
        public virtual HT_INTOCM_FACTURI HT_INTOCM_FACTURI {get;set;}
    }
}
