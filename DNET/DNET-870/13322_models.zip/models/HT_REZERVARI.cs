namespace Rezervari.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class HT_REZERVARI
    {
        public HT_REZERVARI()
        {
            HT_TAXE = new HashSet<HT_TAXE>();
            HT_INFEXPED = new HashSet<HT_INFEXPED>();
        }

        public long ID { get; set; }
        public long ID_CAMERA { get; set; }
        public long ID_CF { get; set; }
        public System.DateTime DATAI { get; set; }
        public Nullable<int> NRZILE { get; set; }
        public Nullable<short> STARE { get; set; }
        public Nullable<short> NR_ADULTI { get; set; }
        public Nullable<System.DateTime> ORA_SOSIRE { get; set; }
        public Nullable<long> NR_FACT { get; set; }
        public Nullable<long> NR_CHIT { get; set; }
        public Nullable<short> NR_CAMERE { get; set; }
        public Nullable<short> FACTURAT { get; set; }
        public Nullable<System.DateTime> DATAREZERV { get; set; }
        public Nullable<short> TIPREZERVAT { get; set; }
        public Nullable<short> ANULAT { get; set; }
        public Nullable<short> REZERVAT { get; set; }
        public Nullable<short> LISCASA { get; set; }
        public long IDTIPTARIF { get; set; }
        public string MENTIUNI { get; set; }
        public Nullable<System.DateTime> DATAF { get; set; }
        public Nullable<long> NR_FACTP { get; set; }
        public Nullable<System.DateTime> DATAFP { get; set; }
     //   public Nullable<decimal> BACSIS { get; set; }
    //    public Nullable<System.DateTime> DATABACS { get; set; }
        public Nullable<decimal> AVANS { get; set; }
        public long IDOPERATOR { get; set; }
        public Nullable<long> IDFACT { get; set; }
        public Nullable<long> IDFACTA { get; set; }
        public Nullable<long> IDFACTP { get; set; }
        public Nullable<short> AVANSCUFC { get; set; }
        public long IDGRUP { get; set; }
        public Nullable<System.DateTime> DATAPLATA { get; set; }
        public Nullable<long> IDFACT3 { get; set; }
        public Nullable<short> TIPFCCUR { get; set; }
        public Nullable<short> FACTURAT3 { get; set; }
        public Nullable<long> NR_FACT3 { get; set; }
        public Nullable<short> LISCASA3 { get; set; }
        public Nullable<short> LISCASA2 { get; set; }
    
        public virtual CF CF { get; set; }
        public virtual HT_CAMERE HT_CAMERE { get; set; }
        public virtual HT_OPERATORI HT_OPERATORI { get; set; }

        //public virtual HT_TARIFARI HT_TARIFARI { get; set; }
        public virtual ICollection<HT_TAXE> HT_TAXE { get; set; }
        public virtual ICollection<HT_INFEXPED> HT_INFEXPED { get; set; }
        public virtual ICollection<HT_FACTPOZ> HT_FACTPOZ { get; set; }
        public virtual ICollection<HT_PLATI> HT_PLATI { get; set; }
        public virtual HT_REZGRUPE HT_REZGRUPE { get; set; }
    }
}
