
namespace Rezervari.Models
{
    using System;
    
    public partial class HT_TAXE
    {
        public long ID { get; set; }
        public long ID_REZERVARE { get; set; }
        public string DENUMIRE { get; set; }
        public Nullable<decimal> PR_TVA { get; set; }
        public Nullable<decimal> CANTITATE { get; set; }
        public Nullable<decimal> PRET { get; set; }
        public string UM { get; set; }
        public string CONT { get; set; }
        public Nullable<decimal> SALV_PRET { get; set; }
        public short TIP { get; set; }
        public Nullable<short> ERRLCAS { get; set; }
        public long IDTAXA { get; set; }
    
        public virtual HT_REZERVARI HT_REZERVARI { get; set; }
    }
}
