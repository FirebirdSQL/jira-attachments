namespace Rezervari.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class CF
    {
        public CF()
        {
            this.HT_REZERVARI = new HashSet<HT_REZERVARI>();
            this.HT_REZGRUPE = new HashSet<HT_REZGRUPE>();
        }
    
        public long ID { get; set; }
        public string DENUMIRE { get; set; }
        public string CIF { get; set; }
        public string NR_REGCM { get; set; }
        public string ADRESA { get; set; }
        public string LOCALITATE { get; set; }
        public string JUDET { get; set; }
        public string BANCA { get; set; }
        public string CONT { get; set; }
    //    public Nullable<decimal> CAPITAL_SOC { get; set; }
   //     public string ALTE_INFORMATII { get; set; }
        public short ACTIV { get; set; }
        public Nullable<short> TIP { get; set; }
        public string TELEFON { get; set; }
 //       public string PERS_CONTACT { get; set; }
 //       public Nullable<decimal> ID_EXPED { get; set; }
        public string EMAIL { get; set; }
 //       public string FAX { get; set; }
 //       public string TEL_PERSCONTACT { get; set; }
        //public string ADRESA2 { get; set; }
        //public string TELEFON2 { get; set; }
        //public Nullable<short> TIP_VALUTA { get; set; }
        public string TARA { get; set; }
        public string BI_SERIA { get; set; }
        public string BI_NR { get; set; }
        public string BI_ELIBERAT { get; set; }
        public string REMARCANEGATIVA { get; set; }
        public Nullable<System.DateTime> DATA_NASTERII { get; set; }
//        public string CONT_A { get; set; }
  //      public Nullable<short> TI { get; set; }
  //      public Nullable<System.DateTime> DATAITI { get; set; }
  //      public Nullable<System.DateTime> DATAFTI { get; set; }
  //      public string FUNCTIA { get; set; }
   //     public Nullable<short> TIP394 { get; set; }
        public string NRSTR { get; set; }
        public string BLOC { get; set; }
        public string AP { get; set; }
        public string ET { get; set; }
        public string SCARA { get; set; }
        public string TIPACTI { get; set; }

   
        public virtual ICollection<HT_REZERVARI> HT_REZERVARI { get; set; }
        public virtual ICollection<HT_REZGRUPE> HT_REZGRUPE { get; set; }
    }
}
