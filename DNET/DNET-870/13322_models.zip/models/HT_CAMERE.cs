namespace Rezervari.Models
{
    using System.Collections.Generic;

    public partial class HT_CAMERE
    {
        public HT_CAMERE()
        {
            HT_REZERVARI = new HashSet<HT_REZERVARI>();
        }
    
        public long ID { get; set; }
        public int ID_TIP { get; set; }
        public int ID_ZONA { get; set; }
        public string OBS { get; set; }
        public short? MAX_ADULTI { get; set; }
        public short? MAX_COPII { get; set; }
        public short? ACTIV { get; set; }
        public string DEN { get; set; }
    
        public virtual HT_TIPCAMERE HT_TIPCAMERE { get; set; }
        public virtual HT_ZONE HT_ZONE { get; set; }
        public virtual ICollection<HT_REZERVARI> HT_REZERVARI { get; set; }
    }
}
