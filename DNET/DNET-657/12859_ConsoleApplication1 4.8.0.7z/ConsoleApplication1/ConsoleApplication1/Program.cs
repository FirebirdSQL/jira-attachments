﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static string ConnectionString()
        {
            var sb = new FbConnectionStringBuilder();
            sb.Charset = "utf8";
            sb.Database = @"c:\development\fast.fdb";
            sb.DataSource = "Localhost";
            sb.Password = "masterkey";
            sb.UserID = "SYSDBA";
            return sb.ToString();
        }

        static void Main(string[] args)
        {
            using (var con = new FbConnection(ConnectionString()))
            {
                con.Open();
                for (int i = 0; i < 1000; i++)
                {
                    using(var tr = con.BeginTransaction())
                    {
                        using(var cmd = con.CreateCommand())
                        {
                            cmd.Transaction = tr;
                            cmd.CommandText = "select * from rdb$database";
                            cmd.ExecuteScalar();
                        }
                        tr.Commit();
                    }
                    GC.Collect();
                }
            }
            Console.ReadLine();
        }
    }
}
