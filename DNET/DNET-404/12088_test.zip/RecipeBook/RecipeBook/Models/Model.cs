﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace RecipeBook.Models
{



    [Table("RECIPE")]
    public class Recipe
    {

        [Key, Column("ID"), DatabaseGenerated(DatabaseGeneratedOption.None), Required]
        public int ID { get; set; }

        [Column("NAME")]
        public string Name { get; set; }


        public virtual ICollection<Ingredient> Ingredients { get; set; }

    }

    [Table("INGREDIENTS")]
    public class Ingredient
    {

        [Key, Column("ID"), DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        [Column("RECIPE"), Required]
        public int RecipeID { get; set; }

        [ForeignKey("RecipeID")]
        public virtual Recipe Recipe { get; set; }

        [Column("NAME")]
        public string Name { get; set; }

    }


    public class RecipeCtx : DbContext
    {

        public DbSet<Recipe> Recipes { get; set; }
        public DbSet<Ingredient> Ingredients { get; set; }


    }


}