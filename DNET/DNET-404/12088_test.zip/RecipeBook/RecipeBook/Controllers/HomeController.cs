﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RecipeBook.Models;

namespace RecipeBook.Controllers
{ 
    public class HomeController : Controller
    {
        private RecipeCtx db = new RecipeCtx();

        //
        // GET: /Home/

        public ViewResult Index()
        {

            var ingredients = (from ing in db.Ingredients.Include(c => c.Recipe) orderby ing.ID select ing)
                .Skip(20)
                .Take(20)
                .ToList();

            return View(ingredients);

        }

        //
        // GET: /Home/Details/5

        public ViewResult Details(int id)
        {
            Ingredient ingredient = db.Ingredients.Find(id);
            return View(ingredient);
        }

        //
        // GET: /Home/Create

        public ActionResult Create()
        {
            ViewBag.RecipeID = new SelectList(db.Recipes, "ID", "Name");
            return View();
        } 

        //
        // POST: /Home/Create

        [HttpPost]
        public ActionResult Create(Ingredient ingredient)
        {
            if (ModelState.IsValid)
            {
                db.Ingredients.Add(ingredient);
                db.SaveChanges();
                return RedirectToAction("Index");  
            }

            ViewBag.RecipeID = new SelectList(db.Recipes, "ID", "Name", ingredient.RecipeID);
            return View(ingredient);
        }
        
        //
        // GET: /Home/Edit/5
 
        public ActionResult Edit(int id)
        {
            Ingredient ingredient = db.Ingredients.Find(id);
            ViewBag.RecipeID = new SelectList(db.Recipes, "ID", "Name", ingredient.RecipeID);
            return View(ingredient);
        }

        //
        // POST: /Home/Edit/5

        [HttpPost]
        public ActionResult Edit(Ingredient ingredient)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ingredient).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.RecipeID = new SelectList(db.Recipes, "ID", "Name", ingredient.RecipeID);
            return View(ingredient);
        }

        //
        // GET: /Home/Delete/5
 
        public ActionResult Delete(int id)
        {
            Ingredient ingredient = db.Ingredients.Find(id);
            return View(ingredient);
        }

        //
        // POST: /Home/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {            
            Ingredient ingredient = db.Ingredients.Find(id);
            db.Ingredients.Remove(ingredient);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}