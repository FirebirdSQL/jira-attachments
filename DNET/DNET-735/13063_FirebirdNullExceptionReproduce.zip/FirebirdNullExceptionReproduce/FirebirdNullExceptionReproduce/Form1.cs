﻿/*************************************************************************************
 * System.NullReferenceException AND System.AccessViolationException TEST CASE
 * ***********************************************************************************
 * AUTHOR: YIANNIS BOURKELIS
 * DATE: 2014-01-04
 * ***********************************************************************************
 * Steps to reproduce System.NullReferenceException:
 * Set updateTimer.Interval = 1500 or higher. Run the app. Click on start button. Wait
 * ***********************************************************************************
 * Steps to reproduce System.AccessViolationException:
 * Set updateTimer.Interval = 500 or lower. Run the app. Click on start button. Wait
 * ***********************************************************************************
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;

namespace FirebirdNullExceptionReproduce
{
    public partial class Form1 : Form
    {
        delegate void method();
        string ConnectrionString = "";
        Timer updateTimer = new Timer();

        public Form1()
        {
            InitializeComponent();

            ConnectrionString = string.Format("User=SYSDBA;Password=masterkey;DataSource=localhost;Database={0};Dialect=3;Charset=UTF8;ServerType=1;pooling=false;", System.IO.Path.Combine(Application.StartupPath, "Database.fdb"));

            updateTimer.Tick += new EventHandler(updateTimer_Tick);
            updateTimer.Interval = 1500;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            updateTimer.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            updateTimer.Enabled = false;
        } 

        void updateTimer_Tick(object sender, EventArgs e)
        {
            var dlg = new method(ExecuteUpdateAsthenwn);
            dlg.BeginInvoke(null, null);
        }

        private void ExecuteUpdateAsthenwn()
        {
            //select first
            var conn1 = new FbConnection(ConnectrionString);
            conn1.Open();
            var cmd1 = conn1.CreateCommand();
            cmd1.CommandText = "SELECT * FROM ASTHENWNRANDEVOU";
            var dr = cmd1.ExecuteReader();

            int i = 0;
            while (dr.Read())
            {
                i++;
            }
            Console.WriteLine("{0} -> DR READ 1: SELECT * FROM ASTHENWNRANDEVOU RECORDS: {1}", DateTime.Now.TimeOfDay.ToString(), i.ToString());

            var conn2 = new FbConnection(ConnectrionString);
            conn2.Open();
            var cmd2 = conn2.CreateCommand();
            cmd2.CommandText = "UPDATE ASTHENWNRANDEVOU SET LASTMODIFICATIONTIME = @DATEPARAM";

            cmd2.Parameters.Add("@DATEPARAM", DateTime.Now);

            var res = cmd2.ExecuteNonQuery();
            Console.WriteLine("{0} -> UPDATE ASTHENWNRANDEVOU: RECORDS: {1}", DateTime.Now.TimeOfDay.ToString(), res.ToString());
        } //ExecuteUpdateAsthenwn

    }
}
