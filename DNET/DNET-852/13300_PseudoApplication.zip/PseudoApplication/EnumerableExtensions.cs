﻿using System;
using System.Collections.Generic;

namespace PseudoApplication
{
    public static class EnumerableExtensions
    {
        public static IEnumerable<List<T>> InBatchesOf<T>(this IEnumerable<T> items, int batchSize)
        {
            if (items == null)
            {
                throw new ArgumentNullException(nameof(items));
            }

            if (batchSize < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(batchSize));
            }

            List<T> nextBatch = null;
            foreach (var item in items)
            {
                if (nextBatch == null)
                {
                    nextBatch = new List<T>();
                }

                nextBatch.Add(item);

                if (nextBatch.Count > batchSize)
                {
                    yield return nextBatch;
                    nextBatch = null;
                }
            }

            if (nextBatch != null)
            {
                yield return nextBatch;
            }
        }
    }
}
