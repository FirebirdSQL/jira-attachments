CREATE TABLE ITEM (
    ID BIGINT NOT NULL,
    MEASUREMENT DOUBLE PRECISION NOT NULL,
    UNIT VARCHAR(10) NOT NULL);

ALTER TABLE ITEM ADD CONSTRAINT PK_ITEM PRIMARY KEY (ID);
CREATE UNIQUE DESCENDING INDEX PK_ITEM_DESC ON ITEM (ID);

CREATE SEQUENCE GEN_ITEM_ID;

SET TERM ^ ;

create trigger item_bi for item
active before insert position 0
as
begin
  if (new.id is null) then
    new.id = gen_id(gen_item_id,1);
end
^

SET TERM ; ^

