﻿namespace PseudoApplication.Database
{
    public class Item
    {
        public long Id { get; set; }

        public double Measurement { get; set; }

        public string Unit { get; set; }
    }
}
