﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace PseudoApplication.Database.Configurations
{
    internal class ItemConfiguration : EntityTypeConfiguration<Item>
    {
        public ItemConfiguration()
        {
            ToTable("ITEM");
            HasKey(t => t.Id);
            Property(t => t.Id)
                .IsRequired()
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
                .HasColumnName("ID");
            Property(t => t.Measurement)
                .IsRequired()
                .HasColumnName("MEASUREMENT");
            Property(t => t.Unit)
                .IsRequired()
                .HasColumnName("UNIT");
        }
    }
}