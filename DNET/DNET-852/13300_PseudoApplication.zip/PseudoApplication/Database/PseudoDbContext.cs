﻿using System;
using System.Data;
using System.Data.Entity;
using FirebirdSql.Data.FirebirdClient;
using PseudoApplication.Database.Configurations;

namespace PseudoApplication.Database
{
    public class PseudoDbContext : DbContext
    {
        public virtual DbSet<Item> Items { get; set; }

        public event EventHandler<string> OnDatabaseLog;

        public PseudoDbContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {
            Configuration.LazyLoadingEnabled = false;
            Database.Log = DatabaseLogHandler;
            System.Data.Entity.Database.SetInitializer<PseudoDbContext>(null);
        }

        /// <summary>
        /// Begins a transaction on the underlying store connection that can be used to read and write records.
        /// </summary>
        /// <returns></returns>
        public DbContextTransaction BeginReadWriteTransaction()
        {
            return BeginTransaction(false);
        }

        /// <summary>
        /// Begins a read only transaction on the underlying store connection.
        /// </summary>
        /// <returns></returns>
        public DbContextTransaction BeginReadOnlyTransaction()
        {
            return BeginTransaction(true);
        }

        /// <summary>
        /// Begins a transaction on the underlying store with the given <see cref="FbTransactionBehavior"/>.
        /// </summary>
        /// <param name="transactionBehavior"></param>
        /// <returns></returns>
        protected DbContextTransaction BeginTransaction(bool readOnly)
        {
            switch (Database.Connection)
            {
                case FbConnection connection:
                    return BeginTransaction(connection, readOnly);
                default:
                    throw new NotSupportedException("This context only supports connections to a firebird database!");
            }
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Configurations.Add(new ItemConfiguration());
        }

        private void DatabaseLogHandler(string message)
        {
            OnDatabaseLog?.Invoke(this, message.Trim());
        }

        private DbContextTransaction BeginTransaction(FbConnection connection, bool readOnly)
        {
            switch (connection.State)
            {
                case ConnectionState.Broken:
                case ConnectionState.Closed:
                    // force open the connection
                    // according to https://docs.microsoft.com/en-us/ef/ef6/fundamentals/connection-management
                    // this is a safe operation because the underlying store connection is closed when this
                    // dbconext is disposed
                    connection.Open();
                    break;
            }

            var transactionBehavior = GetFbConnectionTransactionBehavior(readOnly);

            // then create the connection
            FbTransaction fbTransaction = connection.BeginTransaction(new FbTransactionOptions()
            {
                TransactionBehavior = transactionBehavior,
            });
            Database.UseTransaction(fbTransaction);
            return Database.CurrentTransaction;
        }

        private FbTransactionBehavior GetFbConnectionTransactionBehavior(bool readOnly)
        {
            if (readOnly)
            {
                return FbTransactionBehavior.Read | FbTransactionBehavior.ReadCommitted | FbTransactionBehavior.RecVersion | FbTransactionBehavior.NoWait;
            }
            else
            {
                return FbTransactionBehavior.Write | FbTransactionBehavior.ReadCommitted | FbTransactionBehavior.RecVersion | FbTransactionBehavior.NoWait;
            }
        }
    }
}
