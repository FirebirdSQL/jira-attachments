﻿using System.Collections.Generic;
using PseudoApplication.Database;

namespace PseudoApplication
{
    public interface IItemDataProvider
    {
        IEnumerable<Item> GetItems();
    }
}
