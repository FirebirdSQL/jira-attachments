﻿using System;
using System.Collections.Generic;
using PseudoApplication.Database;

namespace PseudoApplication
{
    public class DefaultItemGenerator : IItemDataProvider
    {
        protected Random Random { get; }

        public DefaultItemGenerator()
        {
            Random = new Random();
        }

        public IEnumerable<Item> GetItems()
        {
            for (int i = 0; i < 100; i++)
            {
                yield return new Item()
                {
                    Measurement = Random.NextDouble() * 100 + 1,
                    Unit = "°C",
                };
            }
        }
    }
}
