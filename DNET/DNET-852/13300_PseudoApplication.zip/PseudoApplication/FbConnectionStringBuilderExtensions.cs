﻿using FirebirdSql.Data.FirebirdClient;

namespace PseudoApplication
{
    public static class FbConnectionStringBuilderExtensions
    {
        public static FbConnectionStringBuilder WithDefaultOptions(this FbConnectionStringBuilder builder)
        {
            builder.DataSource = "localhost";
            builder.Database = "PSEUDO_DATABASE";
            builder.Dialect = 3;
            builder.Charset = "UTF8";
            builder.Port = 3050;
            return builder;
        }

        public static FbConnectionStringBuilder WithCredentials(this FbConnectionStringBuilder builder, string user, string password)
        {
            builder.UserID = user;
            builder.Password = password;
            builder.Role = "";
            return builder;
        }

        public static FbConnectionStringBuilder WithConnectionPoolEnabled(this FbConnectionStringBuilder builder)
        {
            builder.Pooling = true;
            builder.ConnectionLifeTime = 30;
            builder.MinPoolSize = 0;
            return builder;
        }
    }
}
