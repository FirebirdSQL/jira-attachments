﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FirebirdSql.Data.FirebirdClient;
using PseudoApplication.Database;

namespace PseudoApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var cancellationToken = GetCancellationTokenForConsoleCtrlC();
            var connectionString = new FbConnectionStringBuilder()
                    .WithDefaultOptions()
                    .WithConnectionPoolEnabled()
                    .WithCredentials("SYSDBA", "masterke")
                    .ToString();

            var saveItemsLoop = Task.Run(() => SaveItemsLoop(connectionString, cancellationToken));
            var readItemsLoop = Task.Run(() => ReadItemsLoop(connectionString, cancellationToken));
            Task.WhenAll(saveItemsLoop, readItemsLoop).Wait();
        }

        private static void ReadItemsLoop(string connectionString, CancellationToken cancellationToken)
        {
            var random = new Random();
            while (!cancellationToken.IsCancellationRequested)
            {
                // re-evaluate if this should be a burst read in one transaction
                bool isBurst = random.NextDouble() > 0.9;

                using (var dbContext = new PseudoDbContext(connectionString))
                using (var transaction = dbContext.BeginReadOnlyTransaction())
                {
                    int itemsToRead = 1;
                    if (isBurst)
                    {
                        itemsToRead = 100;
                    }

                    for (int i = 0; i < itemsToRead; i++)
                    {
                        ReadItem(random, dbContext);
                    }
                }

                SleepFor(cancellationToken, TimeSpan.FromMilliseconds(5));
            }
        }

        private static void SaveItemsLoop(string connectionString, CancellationToken cancellationToken)
        {
            return;

            while (!cancellationToken.IsCancellationRequested)
            {
                using (var dbContext = new PseudoDbContext(connectionString))
                using (var transaction = dbContext.BeginReadWriteTransaction())
                {
                    WriteItems(dbContext);
                }

                SleepFor(cancellationToken, TimeSpan.FromSeconds(1));
            }
        }

        private static void SleepFor(CancellationToken cancellationToken, TimeSpan sleep)
        {
            var stopwatch = Stopwatch.StartNew();
            while (stopwatch.Elapsed < sleep)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }

                var minSleep = TimeSpan.FromMilliseconds(1);
                var maxSleep = TimeSpan.FromMilliseconds(250);
                var sleepLeft = sleep - stopwatch.Elapsed;
                if (sleepLeft < TimeSpan.Zero)
                {
                    return;
                }

                if (sleepLeft > maxSleep)
                {
                    Thread.Sleep(maxSleep);
                }
                else
                {
                    Thread.Sleep(sleepLeft);
                }
            }
        }

        private static void ReadItem(Random random, PseudoDbContext dbContext)
        {
            var maxId = dbContext.Items.Select(t => t.Id).Max();
            int itemId = random.Next(1, (int)Math.Min(int.MaxValue, maxId));
            var item = dbContext.Items.Where(t => t.Id == itemId).FirstOrDefault();
            Console.WriteLine($"Read item with id {itemId}: {item.Measurement}{item.Unit}");
        }

        private static void WriteItems(PseudoDbContext dbContext)
        {
            var itemDataProvider = new DefaultItemGenerator();
            var items = itemDataProvider.GetItems().ToList();

            var stopwatch = Stopwatch.StartNew();
            foreach (var batch in items.InBatchesOf(10))
            {
                dbContext.Items.AddRange(batch);
                dbContext.SaveChanges();
            }

            Console.WriteLine($"Saved items into the database in {stopwatch.ElapsedMilliseconds}ms");
        }

        private static void DbContext_OnDatabaseLog(object sender, string e)
        {
            Console.WriteLine(e);
        }

        private static CancellationToken GetCancellationTokenForConsoleCtrlC()
        {
            var cancellationTokenSource = new CancellationTokenSource();
            Console.CancelKeyPress += (sender, e) =>
            {
                Console.WriteLine("Intercepted CTRL+C, signalling the application to terminate");
                e.Cancel = true;
                cancellationTokenSource.Cancel();
            };
            return cancellationTokenSource.Token;
        }
    }
}
