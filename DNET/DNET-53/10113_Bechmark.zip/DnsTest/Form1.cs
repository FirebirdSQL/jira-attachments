using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;

namespace DnsTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            StatusLabel.Text = "Benchmark is running...";
            bgw_testthread.RunWorkerAsync();
        }

        private void bgw_testthread_DoWork(object sender, DoWorkEventArgs e)
        {
            DateTime StartTime;
            TimeSpan TookTime;
            IPAddress myIP;
            IPHostEntry ihe;

            string resultStr="";

            // Benchmark Dns.GetHostEntry()
            StartTime = DateTime.Now;
            try
            {
                ihe = Dns.GetHostEntry(text_hostorip.Text);
                TookTime = DateTime.Now - StartTime;

                myIP = ihe.AddressList[0];
                resultStr = "Dns.GetHostEntry() succeeded after: " + TookTime.TotalMilliseconds + " ms (IP: " + myIP.ToString() + ", Hostname: '" + ihe.HostName + "')";
            }
            catch
            {
                // Fails for hostnames ;D
                TookTime = DateTime.Now - StartTime;
                resultStr = "Dns.GetHostEntry() failed after: " + TookTime.TotalMilliseconds + " ms";
            }



            // Benchmark IPAddress.Parse():
            StartTime = DateTime.Now;
            try
            {
                myIP = IPAddress.Parse(text_hostorip.Text);

                TookTime = DateTime.Now - StartTime;
                resultStr += "\nIPAddress.Resolve() succeeded after: " + TookTime.TotalMilliseconds + " ms (IP: " + myIP.ToString() + ")";
            }
            catch
            {
                // Fails for hostnames ;D
                TookTime = DateTime.Now - StartTime;
                resultStr += "\nIPAddress.Resolve() failed after: " + TookTime.TotalMilliseconds + " ms";
            }

            e.Result = resultStr;           
        }

        private void bgw_testthread_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            StatusLabel.Text = (string)e.Result;

            button1.Enabled = true;
        }
    }
}