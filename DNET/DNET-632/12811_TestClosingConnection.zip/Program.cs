﻿using System;
using System.IO;
using System.Net;

using FirebirdSql.Data.FirebirdClient;

namespace TestClosingConnection
{
    class Program
    {
        static void Main()
        {
            //  Path to the database
            var dbFileName = @"D:\DATALINE\Dataline.Office.Mfc\build\Debug\Data\MUSTER.FDB";

            // Path to the client library and all other necessary DLLs
            var toolDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "Visual Studio 2015", "Projects", "TestDbMigration", "TestDbMigration", "Tools", "3.0");

            var clientLibFileName = Path.Combine(toolDir, "fbclient.dll");
            //var clientLibFileName = "gds32.dll";

            // Add the path to the client library to the PATH environment variable
            var pathVar = Environment.GetEnvironmentVariable("PATH");
            if (!string.IsNullOrEmpty(pathVar))
                pathVar += ";";
            pathVar += toolDir;
            Environment.SetEnvironmentVariable("PATH", pathVar);

            // Test
            using (var conn = new FbConnection(CreateConnectionString(dbFileName, new NetworkCredential("SYSDBA", "masterkey"), clientLibFileName)))
            {
                conn.Open();
                //var info = new FbDatabaseInfo(conn);
                //Console.WriteLine(new Version(info.OdsVersion, info.OdsMinorVersion));
                conn.Close();
            }
            //Console.ReadLine();
        }

        private static string CreateConnectionString(string dbFileName, NetworkCredential credential, string clientLibFileName)
        {
            var csb = new FbConnectionStringBuilder()
            {
                UserID = credential.UserName,
                Password = credential.Password,
                Charset = "UTF8",
                BrowsableConnectionString = true,
                Database = dbFileName,
                ServerType = FbServerType.Embedded,
            };
            if (!string.IsNullOrEmpty(clientLibFileName))
                csb.ClientLibrary = clientLibFileName;
            return csb.ConnectionString;
        }
    }
}
