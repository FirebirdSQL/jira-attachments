﻿using System;
using System.IO;
using System.Net;

using FirebirdSql.Data.FirebirdClient;

namespace TestClosingConnection
{
    class Program
    {
        static void Main()
        {
            var exePath = AppDomain.CurrentDomain.BaseDirectory;

            //  Path to the database
            var dbFileName = Path.Combine(exePath, @"empty.fdb");

            // Path to the client library and all other necessary DLLs
            var toolDir = Path.Combine(exePath, "Tools", Environment.Is64BitProcess ? "x64" : "Win32");

            var clientLibFileName = Path.Combine(toolDir, "fbclient.dll");
            //var clientLibFileName = "gds32.dll";

            // Add the path to the client library to the PATH environment variable
            var pathVar = Environment.GetEnvironmentVariable("PATH");
            if (!string.IsNullOrEmpty(pathVar))
                pathVar += ";";
            pathVar += toolDir;
            Environment.SetEnvironmentVariable("PATH", pathVar);

            // Test
            using (var conn = new FbConnection(CreateConnectionString(dbFileName, new NetworkCredential("SYSDBA", "masterkey"), clientLibFileName)))
            {
                conn.Open();
                conn.Close();
            }
        }

        private static string CreateConnectionString(string dbFileName, NetworkCredential credential, string clientLibFileName)
        {
            var csb = new FbConnectionStringBuilder()
            {
                UserID = credential.UserName,
                Password = credential.Password,
                Charset = "UTF8",
                BrowsableConnectionString = true,
                Database = dbFileName,
                ServerType = FbServerType.Embedded,
                //Pooling = false,
            };
            if (!string.IsNullOrEmpty(clientLibFileName))
                csb.ClientLibrary = clientLibFileName;
            return csb.ConnectionString;
        }
    }
}
