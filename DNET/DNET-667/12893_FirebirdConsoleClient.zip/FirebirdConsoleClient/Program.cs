﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ConsoleClient
{
    class Program
    {
        private static System.Timers.Timer timer;

        static void Main(string[] args)
        {
            timer = new System.Timers.Timer(5000);
            timer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
            timer.Enabled = true;

            Console.ReadLine();
        }

        private static void OnTimedEvent(object sender, ElapsedEventArgs e)
        {
            timer.Enabled = false;
            try
            {
                using (var connection = new FbConnection("Server=test;User=test;Password=test;Database=test;Charset=utf8"))
                {
                    connection.Open();
                    using (var command = new FbCommand("select 1 from rdb$database", connection))
                    {
                        var result = command.ExecuteScalar();
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                timer.Enabled = true;
            }
        }
    }
}