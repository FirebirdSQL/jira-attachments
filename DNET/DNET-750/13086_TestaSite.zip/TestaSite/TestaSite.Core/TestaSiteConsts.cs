﻿namespace TestaSite
{
    public class TestaSiteConsts
    {
        public const string LocalizationSourceName = "TestaSite";

        public const bool MultiTenancyEnabled = true;
    }
}