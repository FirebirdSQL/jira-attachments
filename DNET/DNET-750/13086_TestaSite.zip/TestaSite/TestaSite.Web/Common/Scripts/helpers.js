﻿var App = App || {};
(function () {

    var appLocalizationSource = abp.localization.getSource('TestaSite');
    App.localize = function () {
        return appLocalizationSource.apply(this, arguments);
    };

})(App);