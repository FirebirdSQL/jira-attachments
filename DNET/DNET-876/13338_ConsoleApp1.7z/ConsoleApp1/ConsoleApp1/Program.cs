﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using Microsoft.EntityFrameworkCore;
using FirebirdSql.Data.FirebirdClient;
using System.Text;
using System.Linq;

namespace ConsoleApp1
{

    [Table("TEST1")]
    public class Test1
    {
        public long ID { get; set; }
        public byte[] RAW_DATA { get; set; }
    }

    public class FBConnection: DbContext
    {

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            FbConnectionStringBuilder cs = new FbConnectionStringBuilder();
            cs.DataSource = "127.0.0.1";
            cs.Database = "127.0.0.1:" + @"C:\temp\1.fdb";
            cs.Port = 3050;
            cs.UserID = "SYSDBA";
            cs.Password = "masterkey";
            cs.Dialect = 3;
            cs.ConnectionLifeTime = 15;
            cs.Pooling = true;
            cs.MaxPoolSize = 75;
            cs.IsolationLevel = IsolationLevel.ReadCommitted;
            cs.MinPoolSize = 0;
            cs.Charset = FbCharset.Utf8.ToString();           
            optionsBuilder.UseFirebird(cs.ToString());
        }

        public DbSet<Test1> Test1 { get; set; }

    }

    class Program
    {
        static void Main(string[] args)
        {

            using (var db = new FBConnection())
            {
                System.Console.WriteLine("INSERT, UPDATE are fine");
                var t = new Test1 { ID = 1, RAW_DATA = Encoding.UTF8.GetBytes("test1") };
                db.Add(t);
                db.SaveChanges();
                t.RAW_DATA = Encoding.UTF8.GetBytes("test2");
                db.Update(t);
                db.SaveChanges();
            }

            System.Console.WriteLine("SELECT with CAST is fine");
            using (var db = new FBConnection())
            {
                var t = db.Test1.FromSql("select ID, cast(raw_data as blob sub_type 0) as RAW_DATA from test1 where id={0}", 1).First();                
                t.RAW_DATA = Encoding.UTF8.GetBytes("test3");
                db.SaveChanges();
            }

            System.Console.WriteLine("Simple SELECT is wrong");
            using (var db = new FBConnection())
            {
                var t = db.Test1.Find((long)1);                
                db.SaveChanges();
            }

        }
    }
}
