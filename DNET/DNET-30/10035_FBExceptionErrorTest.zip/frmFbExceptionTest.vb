Imports FirebirdSql.Data.Firebird

Public Class frmFbExceptionTest
   Inherits System.Windows.Forms.Form

   Dim m_DBConnection As FbConnection

   Private Shared ReadOnly SERVER_COMP As String = "localhost"
   Private Shared ReadOnly DEFAULT_PASSWORD As String = "masterkey"
   Private Shared ReadOnly USERNAME As String = "SYSDBA"
   Private Shared ReadOnly ROLENAME As String = ""

#Region " CCustomer - Private Inner Class "
   Private Class CCustomerInfo
      Private m_sFirstName As String
      Private m_sLastName As String

      Public Sub New(ByVal psFirstName As String, ByVal psLastName As String)
         m_sFirstName = psFirstName
         m_sLastName = psLastName
      End Sub

      Public ReadOnly Property FirstName() As String
         Get
            Return m_sFirstName
         End Get
      End Property

      Public ReadOnly Property LastName() As String
         Get
            Return m_sLastName
         End Get
      End Property

      Public Overrides Function ToString() As String
         Return m_sFirstName & " " & m_sLastName
      End Function
   End Class

#End Region

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      txtDBFilename.Text = System.IO.Path.GetFullPath(System.AppDomain.CurrentDomain.BaseDirectory & "\..\Database\FBEXCEPTIONDB.FDB")
      txtPassword.Text = DEFAULT_PASSWORD
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents btnExecute As System.Windows.Forms.Button
   Friend WithEvents txtPassword As System.Windows.Forms.TextBox
   Friend WithEvents lblPassword As System.Windows.Forms.Label
   Friend WithEvents lblDBFile As System.Windows.Forms.Label
   Friend WithEvents txtDBFilename As System.Windows.Forms.TextBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnExecute = New System.Windows.Forms.Button
      Me.txtPassword = New System.Windows.Forms.TextBox
      Me.lblPassword = New System.Windows.Forms.Label
      Me.lblDBFile = New System.Windows.Forms.Label
      Me.txtDBFilename = New System.Windows.Forms.TextBox
      Me.SuspendLayout()
      '
      'btnExecute
      '
      Me.btnExecute.Location = New System.Drawing.Point(32, 128)
      Me.btnExecute.Name = "btnExecute"
      Me.btnExecute.Size = New System.Drawing.Size(376, 64)
      Me.btnExecute.TabIndex = 0
      Me.btnExecute.Text = "Execute Offending Code"
      '
      'txtPassword
      '
      Me.txtPassword.Location = New System.Drawing.Point(152, 80)
      Me.txtPassword.Name = "txtPassword"
      Me.txtPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
      Me.txtPassword.Size = New System.Drawing.Size(144, 20)
      Me.txtPassword.TabIndex = 1
      Me.txtPassword.Text = ""
      '
      'lblPassword
      '
      Me.lblPassword.Location = New System.Drawing.Point(40, 80)
      Me.lblPassword.Name = "lblPassword"
      Me.lblPassword.Size = New System.Drawing.Size(104, 24)
      Me.lblPassword.TabIndex = 2
      Me.lblPassword.Text = "SYSDBA Password"
      Me.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight
      '
      'lblDBFile
      '
      Me.lblDBFile.Location = New System.Drawing.Point(32, 24)
      Me.lblDBFile.Name = "lblDBFile"
      Me.lblDBFile.Size = New System.Drawing.Size(104, 24)
      Me.lblDBFile.TabIndex = 4
      Me.lblDBFile.Text = "Database Filename"
      Me.lblDBFile.TextAlign = System.Drawing.ContentAlignment.MiddleRight
      '
      'txtDBFilename
      '
      Me.txtDBFilename.Location = New System.Drawing.Point(40, 48)
      Me.txtDBFilename.Name = "txtDBFilename"
      Me.txtDBFilename.Size = New System.Drawing.Size(368, 20)
      Me.txtDBFilename.TabIndex = 3
      Me.txtDBFilename.Text = ""
      '
      'frmFbExceptionTest
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(456, 222)
      Me.Controls.Add(Me.lblDBFile)
      Me.Controls.Add(Me.txtDBFilename)
      Me.Controls.Add(Me.lblPassword)
      Me.Controls.Add(Me.txtPassword)
      Me.Controls.Add(Me.btnExecute)
      Me.Name = "frmFbExceptionTest"
      Me.Text = "FBException Bug Test Form"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnExecute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecute.Click
      Try
         ' Attempt to load the customer information from the database and display each customer
         For Each Customer As CCustomerInfo In GetCustomerInfo()
            MsgBox(Customer.ToString)
         Next
      Catch ex As Exception
         ' Display the exception
         MsgBox("The following exception has occured: " & vbCrLf & ex.ToString)
         ' The exception should now fall out of scope, and the exception object and its
         ' inner exception (FBException) should now become eligible for garbage collection.
      End Try

      ' Force garbage collection to occur
      ' At this point, the FBException object will be disposed of, and an error occurs in what
      ' appears to be the FBException's finalize method.
      GC.Collect()
   End Sub

   Private Sub ConnectToDatabase()
      Dim CnStrBuilder As New FbConnectionStringBuilder
      With CnStrBuilder
         .DataSource = SERVER_COMP
         .Database = txtDBFilename.Text
         .UserID = USERNAME
         .Password = txtPassword.Text
         .Role = ROLENAME
         .Dialect = 3
         .ConnectionLifeTime = 0
         .Charset = "NONE"
         .ConnectionTimeout = 30
         .PacketSize = 8192
         .Pooling = False
         .FetchSize = 20
      End With

      m_DBConnection = New FbConnection(CnStrBuilder.ToString)
   End Sub

   Private Sub DisconnectFromDatabase()
      m_DBConnection.Close()
      m_DBConnection = Nothing
   End Sub

   Private Function GetCustomerInfo() As Collection
      Dim RetCollection As New Collection
      Dim daDataAdapter As IDbDataAdapter
      Dim dtCustomerTable As DataTable
      Dim dtCustomerDataset As New DataSet

      ' Instantiate a firebird connection object (FBConnection), and open a connection to the database
      ConnectToDatabase()

      Try
         ' Create a new firebird data adapter object, which contains an erroneous query.
         ' More specifically, the query attempts to procure a field which does not exist.

         daDataAdapter = New FbDataAdapter( _
               "SELECT       SFIRSTNAME," & vbCrLf & _
               "                 SLASTNAME," & vbCrLf & _
               "                 SFIELD_THAT_DOES_NOT_EXIST" & vbCrLf & _
               "FROM          CUSTOMERS", m_DBConnection)

         ' Attempt to fill the dataset with the customer data
         ' An exception should be raised at this point
         daDataAdapter.Fill(dtCustomerDataset)

         ' Create a reference to the customer data table object
         dtCustomerTable = dtCustomerDataset.Tables(0)

         ' Add an instance of the CCustomerInfo class for each customer row
         For Each CustomerRow As DataRow In dtCustomerTable.Rows
            RetCollection.Add(New CCustomerInfo(CStr(CustomerRow("SFIRSTNAME")), CStr(CustomerRow("SLASTNAME"))))
         Next
      Catch ex As Exception
         Throw New Exception("An exception occured while attempting to retrieve customer information.", ex)
      Finally
         ' Close the database connection and set the firebird connection object (FBConnection) reference to nothing.
         ' This should occur even when an exception has been raised.
         DisconnectFromDatabase()
      End Try

      Return RetCollection
   End Function
End Class
