﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using FirebirdSql.Data.FirebirdClient;

namespace TestEvents
{
    public partial class MainForm : Form
    {
        FbConnection fb;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            FbConnectionStringBuilder builder = new FbConnectionStringBuilder();
            builder.DataSource = "LIKORIS-SERVER";
            builder.Port = 3050;
            builder.ServerType = FbServerType.Default;
            builder.UserID = "SYSDBA";
            builder.Password = "masterkey";
            builder.Database = @"C:\Default.fdb";
            builder.Charset = "WIN1251";
            fb = new FbConnection(builder.ConnectionString);
            fb.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateTabPage("EVENT1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CreateTabPage("EVENT2");
        }

        private void CreateTabPage(string name)
        {
            TabPage page = new TabPage() { Text = name };
            tabControl1.TabPages.Add(page);
            tabControl1.SelectedTab = page;

            ListBox listBox = new ListBox();
            listBox.Dock = DockStyle.Fill;
            listBox.Parent = page;

            FbRemoteEvent revent = new FbRemoteEvent(fb, name);
            revent.RemoteEventCounts += delegate
            {
                listBox.Items.Add(name);
            };
            revent.QueueEvents();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            fb.Close();
        }

    }
}
