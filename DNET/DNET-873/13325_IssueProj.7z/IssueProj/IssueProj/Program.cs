﻿using Microsoft.EntityFrameworkCore;
using System;

namespace IssueProj
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Test App for Issue");
            Console.WriteLine();

            using (var daten = new IssueProjDaten())
            {
                try
                {
                    daten.Database.Migrate();

                    Console.WriteLine("Migration success");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Migration failure: " + ex.Message);
                }
                
            }

            Console.ReadLine();
        }
    }
}
