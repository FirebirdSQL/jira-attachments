﻿using FirebirdSql.EntityFrameworkCore.Firebird.Extensions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace IssueProj
{
    public class IssueProjDaten : DbContext
    {
        public DbSet<Rating> Ratings { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string path = Assembly.GetAssembly(typeof(IssueProjDaten)).Location;

            optionsBuilder.UseFirebird(@"User=SYSDBA;Password=masterkey;Database="+path+"IssueProj.fdb");

            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Rating>().Property("Value").HasDefaultValue(0);
        }
    }
}
