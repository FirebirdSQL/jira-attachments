﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IssueProj
{
    public class Rating
    {
        public long ID { get; set; }

        public uint Value { get; set; }
    }
}
