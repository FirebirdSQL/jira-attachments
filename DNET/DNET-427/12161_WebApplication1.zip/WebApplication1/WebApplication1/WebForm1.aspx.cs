﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SelectAllPED();
        }

        public IQueryable SelectAllPED()
        {
            Entities entities = new Entities();
            var result = (from t in entities.PED
                          select new
                          {
                              PED_ID = t.PED_ID,
                              PED_DATA = t.PED_DATA,
                              PED_HORA = t.PED_HORA,
                              PED_CLI_CPFCNPJ = t.PED_CLI_CPFCNPJ,
                              PED_CLI_NOME = t.PED_CLI_NOME,
                              PEDPOS_POSICAO = (from pp in t.PEDPOS
                                                select new
                                                {
                                                    pp.PEDPOS_ID,
                                                    pp.PEDPOS_POSICAO
                                                }).OrderByDescending(o => o.PEDPOS_ID).FirstOrDefault().PEDPOS_POSICAO,


                          });
            return result;
        }
    }
}