namespace FBEncodingTest
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.InsertAndReadButton = new System.Windows.Forms.Button();
			this.ConnStrTextBox = new System.Windows.Forms.TextBox();
			this.InputTextBox = new System.Windows.Forms.TextBox();
			this.OutputTextBox = new System.Windows.Forms.TextBox();
			this.ResultLabel = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// InsertAndReadButton
			// 
			this.InsertAndReadButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.InsertAndReadButton.AutoSize = true;
			this.InsertAndReadButton.Location = new System.Drawing.Point(12, 148);
			this.InsertAndReadButton.Name = "InsertAndReadButton";
			this.InsertAndReadButton.Size = new System.Drawing.Size(100, 23);
			this.InsertAndReadButton.TabIndex = 0;
			this.InsertAndReadButton.Text = "Insert and read";
			this.InsertAndReadButton.UseVisualStyleBackColor = true;
			this.InsertAndReadButton.Click += new System.EventHandler(this.InsertAndReadButton_Click);
			// 
			// ConnStrTextBox
			// 
			this.ConnStrTextBox.Location = new System.Drawing.Point(12, 12);
			this.ConnStrTextBox.Name = "ConnStrTextBox";
			this.ConnStrTextBox.Size = new System.Drawing.Size(798, 20);
			this.ConnStrTextBox.TabIndex = 1;
			this.ConnStrTextBox.Text = "Data Source=localhost;Port=3050;Database=test;User Id=test;Password=test;Dialect=" +
				"3;Max Pool Size=10;Charset=NONE;";
			// 
			// InputTextBox
			// 
			this.InputTextBox.Location = new System.Drawing.Point(12, 38);
			this.InputTextBox.Multiline = true;
			this.InputTextBox.Name = "InputTextBox";
			this.InputTextBox.Size = new System.Drawing.Size(798, 104);
			this.InputTextBox.TabIndex = 2;
			// 
			// OutputTextBox
			// 
			this.OutputTextBox.Location = new System.Drawing.Point(12, 177);
			this.OutputTextBox.Multiline = true;
			this.OutputTextBox.Name = "OutputTextBox";
			this.OutputTextBox.Size = new System.Drawing.Size(798, 108);
			this.OutputTextBox.TabIndex = 3;
			// 
			// ResultLabel
			// 
			this.ResultLabel.AutoSize = true;
			this.ResultLabel.Location = new System.Drawing.Point(151, 158);
			this.ResultLabel.Name = "ResultLabel";
			this.ResultLabel.Size = new System.Drawing.Size(0, 13);
			this.ResultLabel.TabIndex = 4;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(822, 297);
			this.Controls.Add(this.ResultLabel);
			this.Controls.Add(this.OutputTextBox);
			this.Controls.Add(this.InputTextBox);
			this.Controls.Add(this.ConnStrTextBox);
			this.Controls.Add(this.InsertAndReadButton);
			this.Name = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button InsertAndReadButton;
        private System.Windows.Forms.TextBox ConnStrTextBox;
        private System.Windows.Forms.TextBox InputTextBox;
        private System.Windows.Forms.TextBox OutputTextBox;
        private System.Windows.Forms.Label ResultLabel;

	}
}

