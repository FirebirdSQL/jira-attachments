using System;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;

namespace FBEncodingTest
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void InsertAndReadButton_Click(object sender, EventArgs e)
		{
			using (FbConnection connection = new FbConnection(ConnStrTextBox.Text))
			{
				try
				{
					string sql =
						@"EXECUTE BLOCK (
                                      ""Input"" VARCHAR(1000) = @Input )
                                    RETURNS (
                                      ""Output"" VARCHAR(1000))
                                    AS
                                    BEGIN
                                      ""Output"" = ""Input"";
                                      SUSPEND;
                                    END";
					FbCommand selectCommand = new FbCommand(sql, connection);
					selectCommand.Parameters.Add(new FbParameter("@Input", InputTextBox.Text));

					connection.Open();

					FbDataReader reader = selectCommand.ExecuteReader();

					while (reader.Read())
						OutputTextBox.Text = Convert.ToString(reader[0]);

					reader.Close();
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
				finally
				{
					connection.Close();
				}

				ResultLabel.Text = (InputTextBox.Text == OutputTextBox.Text) ? "equal" : "not equal";
			}
		}
	}
}