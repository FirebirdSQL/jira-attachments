﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Data;
using FirebirdSql.EntityFrameworkCore.Firebird.Extensions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Api
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		public void ConfigureServices(IServiceCollection services)
		{
			services.AddDbContextPool<Context>(options =>
				options.UseFirebird(
					@"User=SYSDBA;" +
					@"Password=masterkey;" +
					@"Database=/tmp/test.fdb;" +
					@"DataSource=localhost;" +
					@"Port=3050;" +
					@"Dialect=3;" +
					@"Charset=UTF8;" +
					@"Role=;" +
					@"Connection lifetime=15;" +
					@"Pooling=true;" +
					@"MinPoolSize=0;" +
					@"MaxPoolSize=50;" +
					@"Packet Size=8192;" +
					@"ServerType=0;")
			);

			services
				.AddIdentity<AppUser, IdentityRole>(options =>
				{
					options.SignIn.RequireConfirmedEmail = true;

					options.Password.RequireDigit = false;
					options.Password.RequireLowercase = false;
					options.Password.RequireUppercase = false;
					options.Password.RequireNonAlphanumeric = false;
					options.Password.RequiredUniqueChars = 1;
					options.Password.RequiredLength = 6;
				})
				.AddEntityFrameworkStores<Context>()
				.AddDefaultTokenProviders();

			services.AddMvc();
		}

		public void Configure(IApplicationBuilder app, IHostingEnvironment env)
		{
			if (env.IsDevelopment())
				app.UseDeveloperExceptionPage();

			app.UseMvc();
		}
	}

	public static class AppExtension
	{
		public static IWebHost TestDatabase(this IWebHost webHost)
		{
			var serviceScopeFactory = (IServiceScopeFactory) webHost.Services.GetService(typeof(IServiceScopeFactory));

			using (var scope = serviceScopeFactory.CreateScope())
			{
				Task.Run(async () => {
					try
					{
						var services = scope.ServiceProvider;
						var userManager = services.GetRequiredService<UserManager<AppUser>>();

						var user = new AppUser { UserName = "test", Email = "test@test.com" };
						var result = await userManager.CreateAsync(user, "testpass");

						if (result.Succeeded)
							System.Console.WriteLine("Succeeded");
						else
						{
							System.Console.WriteLine(result.ToString());
							return;
						}

						var code = await userManager.GenerateEmailConfirmationTokenAsync(user);

						// Error here!
						result = await userManager.ConfirmEmailAsync(user, code);

						if (result.Succeeded)
							System.Console.WriteLine("Succeeded");
						else
						{
							System.Console.WriteLine(result.ToString());
							return;
						}
					}
					catch (Exception e)
					{
						System.Console.WriteLine("{0}", e.ToString());
					}
				});
			}

			return webHost;
		}
	}
}
