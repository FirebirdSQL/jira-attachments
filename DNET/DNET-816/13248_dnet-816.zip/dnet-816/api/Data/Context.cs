using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Api.Data
{
	public class AppUser : IdentityUser
	{
	}

	public class Context : IdentityDbContext<AppUser>
	{
		public Context(DbContextOptions dbContextOptions)
			: base(dbContextOptions)
		{
		}

		protected override void OnModelCreating(ModelBuilder builder)
		{
			base.OnModelCreating(builder);

			OnIdentityModelCreating(builder);
		}

		private void OnIdentityModelCreating(ModelBuilder builder)
		{
			// IdentityUser

			builder.Entity<IdentityUser>().ToTable("IDENTITY_USER")
				.Ignore(u => u.LockoutEnd);

			builder.Entity<IdentityUser>()
				.Property(p => p.Id).HasColumnName("ID");

			builder.Entity<IdentityUser>()
				.Property(p => p.AccessFailedCount).HasColumnName("ACCESS_FAILED_COUNT");

			builder.Entity<IdentityUser>()
				.Property(p => p.ConcurrencyStamp).HasColumnName("CONCURRENCY_STAMP");

			builder.Entity<IdentityUser>()
				.Property("Discriminator").HasColumnName("DISCRIMINATOR");

			builder.Entity<IdentityUser>()
				.Property(p => p.Email).HasColumnName("EMAIL");

			builder.Entity<IdentityUser>()
				.Property(p => p.EmailConfirmed).HasColumnName("EMAIL_CONFIRMED");

			builder.Entity<IdentityUser>()
				.Property(p => p.LockoutEnabled).HasColumnName("LOCKOUT_ENABLED");

			builder.Entity<IdentityUser>()
				.Property(p => p.NormalizedEmail).HasColumnName("NORMALIZED_EMAIL");

			builder.Entity<IdentityUser>()
				.Property(p => p.NormalizedUserName).HasColumnName("NORMALIZED_USER_NAME");

			builder.Entity<IdentityUser>()
				.Property(p => p.PasswordHash).HasColumnName("PASSWORD_HASH");

			builder.Entity<IdentityUser>()
				.Property(p => p.PhoneNumber).HasColumnName("PHONE_NUMBER");

			builder.Entity<IdentityUser>()
				.Property(p => p.PhoneNumberConfirmed).HasColumnName("PHONE_NUMBER_CONFIRMED");

			builder.Entity<IdentityUser>()
				.Property(p => p.SecurityStamp).HasColumnName("SECURITY_STAMP");

			builder.Entity<IdentityUser>()
				.Property(p => p.TwoFactorEnabled).HasColumnName("TWO_FACTOR_ENABLED");

			builder.Entity<IdentityUser>()
				.Property(p => p.UserName).HasColumnName("USER_NAME");

			/*
			builder.Entity<IdentityUser>()
				.Property(p => p.ConcurrencyStamp).HasMaxLength(40);

			builder.Entity<IdentityUser>()
				.Property(p => p.PasswordHash).HasMaxLength(1024);

			builder.Entity<IdentityUser>()
				.Property(p => p.SecurityStamp).HasMaxLength(256);

			builder.Entity<IdentityUser>()
				.Property(p => p.PhoneNumber).HasMaxLength(40);
			*/

			// IdentityRole

			builder.Entity<IdentityRole>().ToTable("IDENTITY_ROLE");

			builder.Entity<IdentityRole>()
				.Property(p => p.Id).HasColumnName("ID");

			builder.Entity<IdentityRole>()
				.Property(p => p.ConcurrencyStamp).HasColumnName("CONCURRENCY_STAMP");

			builder.Entity<IdentityRole>()
				.Property(p => p.Name).HasColumnName("NAME");

			builder.Entity<IdentityRole>()
				.Property(p => p.NormalizedName).HasColumnName("NORMALIZED_NAME");

			// IdentityRoleClaim

			builder.Entity<IdentityRoleClaim<string>>().ToTable("IDENTITY_ROLE_CLAIM");

			builder.Entity<IdentityRoleClaim<string>>()
				.Property(p => p.Id).HasColumnName("ID");

			builder.Entity<IdentityRoleClaim<string>>()
				.Property(p => p.ClaimType).HasColumnName("CLAIM_TYPE");

			builder.Entity<IdentityRoleClaim<string>>()
				.Property(p => p.ClaimValue).HasColumnName("CLAIM_VALUE");

			builder.Entity<IdentityRoleClaim<string>>()
				.Property(p => p.RoleId).HasColumnName("ROLE_ID");

			// IdentityUserClaim

			builder.Entity<IdentityUserClaim<string>>().ToTable("IDENTITY_USER_CLAIM");

			builder.Entity<IdentityUserClaim<string>>()
				.Property(p => p.Id).HasColumnName("ID");

			builder.Entity<IdentityUserClaim<string>>()
				.Property(p => p.ClaimType).HasColumnName("CLAIM_TYPE");

			builder.Entity<IdentityUserClaim<string>>()
				.Property(p => p.ClaimValue).HasColumnName("CLAIM_VALUE");

			builder.Entity<IdentityUserClaim<string>>()
				.Property(p => p.UserId).HasColumnName("USER_ID");

			// IdentityUserLogin

			builder.Entity<IdentityUserLogin<string>>().ToTable("IDENTITY_USER_LOGIN");

			builder.Entity<IdentityUserLogin<string>>()
				.Property(p => p.LoginProvider).HasColumnName("LOGIN_PROVIDER");

			builder.Entity<IdentityUserLogin<string>>()
				.Property(p => p.ProviderKey).HasColumnName("PROVIDER_KEY");

			builder.Entity<IdentityUserLogin<string>>()
				.Property(p => p.ProviderDisplayName).HasColumnName("PROVIDER_DISPLAY_NAME");

			builder.Entity<IdentityUserLogin<string>>()
				.Property(p => p.UserId).HasColumnName("USER_ID");

			// IdentityUserRole

			builder.Entity<IdentityUserRole<string>>().ToTable("IDENTITY_USER_ROLE");

			builder.Entity<IdentityUserRole<string>>()
				.Property(p => p.UserId).HasColumnName("USER_ID");

			builder.Entity<IdentityUserRole<string>>()
				.Property(p => p.RoleId).HasColumnName("ROLE_ID");

			// IdentityUserToken

			builder.Entity<IdentityUserToken<string>>().ToTable("IDENTITY_USER_TOKEN");

			builder.Entity<IdentityUserToken<string>>()
				.Property(p => p.UserId).HasColumnName("USER_ID");

			builder.Entity<IdentityUserToken<string>>()
				.Property(p => p.LoginProvider).HasColumnName("LOGIN_PROVIDER");

			builder.Entity<IdentityUserToken<string>>()
				.Property(p => p.Name).HasColumnName("NAME");

			builder.Entity<IdentityUserToken<string>>()
				.Property(p => p.Value).HasColumnName("TOKEN_VALUE");
		}
	}
}
