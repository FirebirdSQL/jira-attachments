﻿Public Class Form1

    'change the path to database.fdb (initial catalog)
    Dim strConnectionString As String = "character set=UTF8;data source=localhost;initial catalog=I:\DATABASE.FDB;user id=SYSDBA;password=masterkey"

    Private Sub btnInsert1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert1.Click
        Cursor.Current = Cursors.WaitCursor
        Me.Insert()
        MsgBox("1 record inserted")
        Cursor.Current = Cursors.Default
    End Sub

    Public Sub Insert()
        Dim Conn As New FirebirdSql.Data.FirebirdClient.FbConnection(strConnectionString)
        Dim strSQL As String = "SELECT * FROM Astheneis WHERE ID=-1"
        Dim myDataAdapter As New FirebirdSql.Data.FirebirdClient.FbDataAdapter(strSQL, Conn)

        Dim custDS As New DataSet
        myDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey
        myDataAdapter.Fill(custDS)

        Dim myRow As DataRow
        myRow = custDS.Tables(0).NewRow

        myRow("ID") = -1
        myRow("Onoma") = "blabl"
        myRow("Eponimo") = "blabl"
        myRow("Patronimo") = "blabl"
        myRow("Dieftinsi") = "blabl"
        myRow("NomosPerioxi") = "blabl"
        myRow("Poli") = "blabl"
        myRow("TK") = "blabl"
        myRow("Fylo") = 0
        myRow("Epagelma") = "blabl"
        myRow("Taftotita") = "blabl"
        myRow("Genisi") = Now
        myRow("PerTil1") = "blabl"
        myRow("PerTil2") = "blabl"
        myRow("PerTil3") = "blabl"
        myRow("PerTil4") = "blabl"
        myRow("Til1") = "blabl"
        myRow("Til2") = "blabl"
        myRow("Til3") = "blabl"
        myRow("Til4") = "blabl"
        myRow("Email") = "blabl"
        myRow("Istoselida") = "blabl"
        myRow("AsfalistikoTameioID") = 0
        myRow("Sistisas") = "blabl"
        myRow("ImerominiaKataxorisis") = Now
        myRow("Simioseis") = "blabl"
        myRow("Remind") = 0
        myRow("RemindDays") = 0
        myRow("Reminded") = 0
        myRow("AFM") = "blabl"
        myRow("LastReminded") = Now
        myRow("Photo") = DBNull.Value
        myRow("ShowTreatmentWorks") = 0
        myRow("ShowPerio") = 0
        myRow("EpilegmenosFragmos") = 0

     
        myRow("blnYpertasi") = False
        myRow("blnKardiakes") = False
        myRow("blnPiksis") = False
        myRow("blnLoimodeis") = False
        myRow("blnAlergy") = False
        myRow("blnAsthma") = False
        myRow("blnDiavitis") = False
        myRow("blnThiroidis") = False
        myRow("blnNefra") = False
        myRow("blnEgymosini") = False
        myRow("blnMetamosx") = False
        myRow("blnParakolouth") = False
        myRow("blnFarmaka") = False
        myRow("blnXeirourg") = False
        myRow("blnDiafora") = False

        myRow("blnVlenog") = False
        myRow("blnKFGD") = False
        myRow("blnAdenes") = False
        myRow("blnOulitida") = False
        myRow("blnPeriodont") = False
        myRow("blnAnapnoi") = False
        myRow("blnSyglisi") = False
        myRow("blnOrthodont") = False
        myRow("blnExeis") = False
        myRow("blnStomatiki") = False
        myRow("blnDiafora2") = False
        '==========================================

        custDS.Tables(0).Rows.Add(myRow)

        Dim custCB As New FirebirdSql.Data.FirebirdClient.FbCommandBuilder(myDataAdapter) 'VistaDB.Provider.VistaDBCommandBuilder(myDataAdapter)
        myDataAdapter.Update(custDS)
    End Sub

    Private Sub btnInsert10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert10.Click
        Cursor.Current = Cursors.WaitCursor

        For i As Integer = 1 To 10
            Me.Insert()
        Next

        MsgBox("10 records inserted")
        Cursor.Current = Cursors.Default
    End Sub
End Class
