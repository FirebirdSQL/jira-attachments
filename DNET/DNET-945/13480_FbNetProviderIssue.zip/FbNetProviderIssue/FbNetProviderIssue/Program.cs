﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace FbNetProviderIssue
{
	class Program
	{
		const string seed = "0123456789";

		public static string binDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
		static string connectionString = $"database=localhost:{binDir}\\demo.fdb;user=sysdba;password=masterkey";
		static Random random = new Random();
		static int id = 0;

		static int NextId => Interlocked.Increment(ref id);
		static int ExistingId => random.Next(0, id);
		static string RandomSeedBeginning => seed.Substring(0, random.Next(10));
		static string RandomSeedEnding => seed.Substring(random.Next(10));
		static string NewFooBar => RandomSeedEnding + "_foobar_" + RandomSeedBeginning;

		static void Main(string[] args)
		{
			FileLogger.Activate();

			Initialize();

			Loop(Add);
			Loop(AddRange);
			//Loop(Modify);
			Loop(Remove);
			//Loop(Count);
			Loop(Query, 10);

			Console.ReadKey(true);
		}

		static void Initialize()
		{
			using (MyContext context = new MyContext(connectionString))
			{
				context.Database.EnsureCreated();
				Debug.WriteLine($"Get-Count-Before-Init: {context.Demos.LongCount()}");
				context.Database.ExecuteSqlRaw("DELETE FROM DEMO");
				Debug.WriteLine($"Get-Count-After-Init: {context.Demos.LongCount()}");
			}
		}

		static void Loop(Action action, int parallel = 1)
		{
			for (int i = 0; i < parallel; i++)
			{
				Task.Run(() =>
					{
						while (true)
						{
							try
							{
								action();
							}
							catch (Exception ex)
							{
								FileLogger.AddError(ex.ToString());
								Debug.WriteLine($"Error: {ex.GetType().Name}: {ex.Message}");
							}
						}
					});
			}
		}

		static void Add()
		{
			using (MyContext context = new MyContext(connectionString))
			{
				context.Demos.Add(new Demo { Id = NextId, FooBar = NewFooBar });
				context.SaveChanges();
			}
		}

		static void AddRange()
		{
			using (MyContext context = new MyContext(connectionString))
			{
				context.Demos.AddRange(
					new Demo { Id = NextId, FooBar = NewFooBar },
					new Demo { Id = NextId, FooBar = NewFooBar },
					new Demo { Id = NextId, FooBar = NewFooBar },
					new Demo { Id = NextId, FooBar = NewFooBar });
				context.SaveChanges();
			}
		}

		static void Modify()
		{
			using (MyContext context = new MyContext(connectionString))
			{
				Demo demo = Find(context);
				demo.FooBar = NewFooBar;
				context.SaveChanges();
			}
		}

		static void Remove()
		{
			using (MyContext context = new MyContext(connectionString))
			{
				context.Demos.Remove(Find(context));
				context.SaveChanges();
			}
			Thread.Sleep(200);
		}

		static void Count()
		{
			using (MyContext context = new MyContext(connectionString))
			{
				var demoCount = context.Demos
					.LongCount(demo => demo.FooBar.EndsWith(RandomSeedBeginning));

				Debug.WriteLine($"Count: {demoCount}");
			}
		}

		static void Query()
		{
			using (MyContext context = new MyContext(connectionString))
			{
				var demos = context.Demos
					.Where(demo => demo.FooBar.StartsWith(RandomSeedEnding))
					.Skip(random.Next(10))
					.Take(random.Next(10))
					.OrderByDescending(demo => demo.FooBar)
					.ToList();

				Debug.WriteLine($"Get-Count: {demos.Count}");
			}
		}

		static Demo Find(MyContext context)
		{
			Demo demo = null;
			while (demo == null)
			{
				demo = context.Demos.Find(ExistingId);
			}

			return demo;
		}
	}

	class MyContext : DbContext
	{
		static readonly ILoggerFactory MyLoggerFactory = LoggerFactory.Create(builder => builder.AddProvider(new MyLoggerProvider()));

		readonly string _connectionString;

		public MyContext(string connectionString)
		{
			_connectionString = connectionString;
		}

		public DbSet<Demo> Demos { get; set; }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);

			optionsBuilder
				.UseLoggerFactory(MyLoggerFactory)
				.UseFirebird(_connectionString);
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			var demoConf = modelBuilder.Entity<Demo>();
			demoConf.Property(x => x.Id).HasColumnName("ID");
			demoConf.Property(x => x.FooBar).HasColumnName("FOOBAR");
			demoConf.ToTable("DEMO");
		}
	}

	class MyLoggerProvider : ILoggerProvider
	{
		public void Dispose()
		{
		}

		public ILogger CreateLogger(string categoryName)
		{
			return new MyLogger(categoryName);
		}
	}

	class MyLogger : ILogger
	{
		private readonly string _categoryName;

		public MyLogger(string categoryName)
		{
			_categoryName = categoryName;
		}

		public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
		{
			FileLogger.AddInfo($"{logLevel.ToString().ToUpper()}: {_categoryName}: {formatter(state, exception)}");
		}

		public bool IsEnabled(LogLevel logLevel)
		{
			return true;
		}

		public IDisposable BeginScope<TState>(TState state)
		{
			return null;
		}
	}

	static class FileLogger
	{
		static BlockingCollection<string> infoEntries = new BlockingCollection<string>();
		static BlockingCollection<string> errorEntries = new BlockingCollection<string>();

		public static void AddInfo(string entry) => infoEntries.Add(entry);
		public static void AddError(string entry) => errorEntries.Add(entry);

		public static void Activate()
		{
			new Thread(() =>
				{
					while (true)
					{
						string entry = infoEntries.Take();
						File.AppendAllText(Path.Combine(Program.binDir, "info.log"), entry + Environment.NewLine, Encoding.UTF8);
					}
				}) { IsBackground = true }.Start();

			new Thread(() =>
				{
					while (true)
					{
						string entry = errorEntries.Take();
						File.AppendAllText(Path.Combine(Program.binDir, "error.log"), entry + Environment.NewLine + Environment.NewLine, Encoding.UTF8);
					}
				}) { IsBackground = true }.Start();
		}
	}

	class Demo
	{
		public int Id { get; set; }
		public string FooBar { get; set; }
	}
}
