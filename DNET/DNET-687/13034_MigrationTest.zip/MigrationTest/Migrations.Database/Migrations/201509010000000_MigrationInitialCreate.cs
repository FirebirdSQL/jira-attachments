//-----------------------------------------------------------------------
// <copyright file="201509010000000_MigrationInitialCreate.cs" company="IOLAN b.v.">
//     IOLAN b.v.
//     Mon Plaisir 26
//     4879AN Etten-Leur
//     Copyright � 2016 IOLAN b.v. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Data.Entity.Migrations;

namespace IOLAN.Context.Management.Migrations
{
    /// <summary>
    /// Class describing the initial creation migration.
    /// </summary>
    public partial class MigrationInitialCreate : DbMigration
    {
        /// <summary>
        /// Operations to be performed during the upgrade process.
        /// </summary>
        public override void Up()
        {
        }

        /// <summary>
        /// Operations to be performed during the downgrade process.
        /// </summary>
        public override void Down()
        {
        }
    }
}
