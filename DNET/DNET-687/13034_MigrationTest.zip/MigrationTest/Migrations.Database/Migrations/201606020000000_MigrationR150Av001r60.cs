//-----------------------------------------------------------------------
// <copyright file="201606020000000_MigrationR150Av001r60.cs" company="IOLAN b.v.">
//     IOLAN b.v.
//     Mon Plaisir 26
//     4879AN Etten-Leur
//     Copyright � 2016 IOLAN b.v. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Data.Entity.Migrations;

namespace IOLAN.Context.Management.Migrations
{
    /// <summary>
    /// Class describing the migration to release R150Av001r60.
    /// </summary>
    public partial class MigrationR150Av001r60 : DbMigration
    {
        /// <summary>
        /// Operations to be performed during the upgrade process.
        /// </summary>
        public override void Up()
        {
            DropTable("Posts");
        }

        /// <summary>
        /// Operations to be performed during the downgrade process.
        /// </summary>
        public override void Down()
        {
            CreateTable(
                "Posts",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        Content = c.String(),
                    })
                .PrimaryKey(t => t.Id);
        }
    }
}
