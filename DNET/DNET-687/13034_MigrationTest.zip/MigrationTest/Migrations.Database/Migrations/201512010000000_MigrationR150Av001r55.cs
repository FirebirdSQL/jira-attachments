//-----------------------------------------------------------------------
// <copyright file="201512010000000_MigrationR150Av001r55.cs" company="IOLAN b.v.">
//     IOLAN b.v.
//     Mon Plaisir 26
//     4879AN Etten-Leur
//     Copyright � 2016 IOLAN b.v. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Data.Entity.Migrations;

namespace IOLAN.Context.Management.Migrations
{
    /// <summary>
    /// Class describing the migration to release R150Av001r55.
    /// </summary>
    public partial class MigrationR150Av001r55 : DbMigration
    {
        /// <summary>
        /// Operations to be performed during the upgrade process.
        /// </summary>
        public override void Up()
        {
            CreateTable(
                "Customers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Firstname = c.String(),
                        Lastname = c.String(),
                        Inserted = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);

            CreateTable(
                "Products",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Price = c.Double(nullable: false),
                        Description = c.String(),
                    })
                .PrimaryKey(t => t.Id);

            CreateTable(
                "Categories",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.Id);

            CreateTable(
                "CategoryProducts",
                c => new
                    {
                        Category_Id = c.Int(nullable: false),
                        Product_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Category_Id, t.Product_Id })
                .ForeignKey("Categories", t => t.Category_Id, /*cascadeDelete:*/ true, /*name =*/ "FK_A")
                .ForeignKey("Products", t => t.Product_Id, /*cascadeDelete:*/ true, "FK_B")
                .Index(t => t.Category_Id)
                .Index(t => t.Product_Id);

            CreateTable(
                "Orders",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        OrderDate = c.DateTime(nullable: false),
                        Customer_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("Customers", t => t.Customer_Id)
                .Index(t => t.Customer_Id);

            CreateTable(
                "OrderLines",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Quantity = c.Int(nullable: false),
                        Price = c.Double(nullable: false),
                        Order_Id = c.Int(),
                        Product_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("Orders", t => t.Order_Id, false, "FK_C")
                .ForeignKey("Products", t => t.Product_Id, false, "FK_D")
                .Index(t => t.Order_Id)
                .Index(t => t.Product_Id);
        }

        /// <summary>
        /// Operations to be performed during the downgrade process.
        /// </summary>
        public override void Down()
        {
            // DropForeignKey("OrderLines", "Product_Id", "Products");
            DropForeignKey("OrderLines", "FK_C");

            // DropForeignKey("CategoryProducts", "Product_Id", "Products");
            DropForeignKey("CategoryProducts", "FK_B");

            // DropForeignKey("CategoryProducts", "Category_Id", "Categories");
            DropForeignKey("CategoryProducts", "FK_A");

            // DropForeignKey("OrderLines", "Order_Id", "Orders");
            DropForeignKey("OrderLines", "FK_D");
            DropForeignKey("Orders", "Customer_Id", "Customers");

            DropIndex("CategoryProducts", new[] { "Product_Id" });
            DropIndex("CategoryProducts", new[] { "Category_Id" });
            DropIndex("Orders", new[] { "Customer_Id" });
            DropIndex("OrderLines", new[] { "Product_Id" });
            DropIndex("OrderLines", new[] { "Order_Id" });
            DropTable("CategoryProducts");
            DropTable("Categories");
            DropTable("Products");
            DropTable("Customers");
            DropTable("Orders");
            DropTable("OrderLines");
        }
    }
}
