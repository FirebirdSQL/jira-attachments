﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="IOLAN b.v.">
//     IOLAN b.v.
//     Mon Plaisir 26
//     4879AN Etten-Leur
//     Copyright © 2011 IOLAN b.v. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("IOLAN - Migrations.Database.UnitTests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("IOLAN B.V.")]
[assembly: AssemblyProduct("IOLAN® Sphere")]
[assembly: AssemblyCopyright("© IOLAN B.V.. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("ed6dc662-5b27-43c5-8fb6-eaa65f535fae")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.1.1")]
[assembly: AssemblyFileVersion("1.0.1.1")]

[assembly: NeutralResourcesLanguageAttribute("en-US")]
[assembly: CLSCompliant(true)]
