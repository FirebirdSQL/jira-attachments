﻿//-----------------------------------------------------------------------
// <copyright file="BlankContext.cs" company="IOLAN b.v.">
//     IOLAN b.v.
//     Mon Plaisir 26
//     4879AN Etten-Leur
//     Copyright © 2016 IOLAN b.v. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Data.Entity;

namespace MigrationTest
{
    /// <summary>
    /// The context that is used for migrating databases.
    /// </summary>
    public class BlankContext : DbContext
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BlankContext"/> class.
        /// </summary>
        public BlankContext()
            : base()
        {
        }
    }
}
