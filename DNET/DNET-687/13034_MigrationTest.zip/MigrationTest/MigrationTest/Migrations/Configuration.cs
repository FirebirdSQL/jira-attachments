//-----------------------------------------------------------------------
// <copyright file="Configuration.cs" company="IOLAN b.v.">
//     IOLAN b.v.
//     Mon Plaisir 26
//     4879AN Etten-Leur
//     Copyright � 2016 IOLAN b.v. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Data.Entity.Migrations;

namespace MigrationTest
{
    /// <summary>
    /// The configuration on how to perform the the migrations.
    /// </summary>
    public sealed class Configuration : DbMigrationsConfiguration<BlankContext>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Configuration"/> class.
        /// </summary>
        public Configuration()
        {
        }

        /// <summary>
        /// Runs after upgrading to the latest migration to allow seed data to be updated.
        /// </summary>
        /// <param name="context">The context on which the seeding is performed.</param>
        protected override void Seed(BlankContext context)
        {
        }
    }
}
