﻿using System.Data.Entity.Infrastructure;
using System.Data.Entity.Migrations;
using System.Data.Entity.Migrations.Infrastructure;
using System.IO;
using System.Linq;
using System.Reflection;

namespace MigrationTest
{
    class Program
    {
        private static string mDataProvider = "FirebirdSql.Data.FirebirdClient";
        private static string mConnectionString = @"Password=masterkey;User Id=SYSDBA;Data Source=localhost;Initial Catalog={0}Migration.FDB;Pooling=false";

        static void Main(string[] args)
        {
            var executePath = string.Format(
                "{0}{1}",
                Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location).Trim(Path.DirectorySeparatorChar),
                System.IO.Path.DirectorySeparatorChar);

            mConnectionString = string.Format(mConnectionString, executePath);

            var migrationConfiguration = new Configuration();
            migrationConfiguration.TargetDatabase = new DbConnectionInfo(mConnectionString, mDataProvider);


            migrationConfiguration.MigrationsAssembly = Assembly.LoadFile(Path.Combine(executePath, "Migrations.Database.dll"));
            var namespaceFound = migrationConfiguration
                .MigrationsAssembly
                .GetTypes()
                .Where(t => typeof(IMigrationMetadata).IsAssignableFrom(t))
                .Select(t => t.Namespace)
                .Distinct()
                .FirstOrDefault();
            migrationConfiguration.MigrationsNamespace = namespaceFound;

            var migrator = new DbMigrator(migrationConfiguration);

            migrator.Update("201606020000000_MigrationR150Av001r60");


            migrator.Update("0");

        }
    }
}
