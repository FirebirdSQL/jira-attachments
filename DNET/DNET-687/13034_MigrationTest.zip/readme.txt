The solutions contains 2 projects. One with the migrations and a console appl. to run the test.
There is also a database in the root to test against.

The migration is somehow different then you normally see, but this will give is more freedom and
also works except the update("0")

I hope that you will succeed.