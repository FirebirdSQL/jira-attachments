﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;

namespace ExemploTabela
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fc = new FbConnectionStringBuilder();
            fc.DataSource = txt_ServerName.Text;
            fc.Database = txt_Database.Text;
            fc.UserID = txt_UserName.Text;
            fc.Password = txt_Password.Text;
            var conn = new FbConnection(fc.ConnectionString);
            conn.Open();
            var ParamTableName = txt_TableName.Text;
            DataTable dtb = conn.GetSchema("COLUMNS", new string[] { null, null, ParamTableName });
            dataGridView1.DataSource = dtb;
            conn.Close();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
