﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shea.DataAccess.EFDataAccess.SheaDBModels
{
    public class Initial
    {
        public int Id { get; set; }
        public string Initials { get; set; }
        public string SocialSecurityNbr { get; set; }
        public string AgentId { get; set; }
        public string LetterSigner { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public string Email { get; set; }
        public string ActiveUser { get; set; }
        public int SignatureId { get; set; }
        public string OldInitials { get; set; }
        public string Phone { get; set; }
    }
}
