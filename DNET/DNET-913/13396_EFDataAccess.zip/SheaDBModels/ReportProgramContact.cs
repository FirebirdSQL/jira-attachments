namespace Shea.DataAccess.EFDataAccess.SheaDBModels
{
    public partial class ReportProgramContact
    {
        public int ContactId { get; set; }

        public int ProgramId { get; set; }

        public string FullName { get; set; }

        public string Salutation { get; set; }

        public string EMail { get; set; }

        public string ContactType { get; set; }
    }
}
