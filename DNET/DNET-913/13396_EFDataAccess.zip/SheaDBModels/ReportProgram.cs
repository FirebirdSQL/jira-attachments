using System;
using System.Collections.Generic;

namespace Shea.DataAccess.EFDataAccess.SheaDBModels
{
    public partial class ReportProgram
    {
        public ReportProgram()
        {
            ProgramContacts = new HashSet<ReportProgramContact>();
            ProgramDetails = new HashSet<ReportProgramDetail>();
            ProgramReports = new HashSet<ReportProgramReports>();
        }

        public int ProgramId { get; set; }

        public string Title { get; set; }

        public string ShortName { get; set; }

        public string Frequency { get; set; }

        public string RunDay { get; set; }

        public string DateRange { get; set; }

        public string MergeSingle { get; set; }
        
        public string ProgramActive { get; set; }

        public string ReqCustomsDisclaimer { get; set; }

        public string EmailFrom { get; set; }

        public string SheaInternal { get; set; }

        public DateTime? LastRun { get; set; }

        public virtual ICollection<ReportProgramContact> ProgramContacts { get; set; }

        public virtual ICollection<ReportProgramDetail> ProgramDetails { get; set; }
        
        public virtual ICollection<ReportProgramReports> ProgramReports { get; set; }
        
    }
}
