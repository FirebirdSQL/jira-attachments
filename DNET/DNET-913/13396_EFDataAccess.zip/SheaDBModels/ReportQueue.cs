using System;
using System.Collections.Generic;

namespace Shea.DataAccess.EFDataAccess.SheaDBModels
{
    public class ReportQueue
    {
        public ReportQueue()
        {
            ReportGroup = new HashSet<ReportGroup>();
        }

        public int QueueId { get; set; }

        public int? ProgramId { get; set; }
        
        public int? GroupSessionId { get; set; }
        
        public int? ReportId { get; set; }
        
        public string Param1 { get; set; }

        public string Param2 { get; set; }

        public DateTime? ParamStartDate { get; set; }

        public DateTime? ParamEndDate { get; set; }

        public string Initials { get; set; }

        public virtual Initial User { get; set; }

        public string Status { get; set; }

        public DateTime? DateRequested { get; set; }

        public virtual ICollection<ReportGroup> ReportGroup { get; set; }
        
        public virtual ReportProgram ReportProgram { get; set; }
        
        public virtual Report Report { get; set; }
    }
}
