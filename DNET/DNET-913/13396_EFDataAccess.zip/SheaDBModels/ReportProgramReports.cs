﻿using System.Collections.Generic;

namespace Shea.DataAccess.EFDataAccess.SheaDBModels
{
    public class ReportProgramReports
    {
        public ReportProgramReports()
        {
            Reports = new HashSet<Report>();
        }

        public int ProgramId { get; set; }

        public int ReportId { get; set; }

        public virtual ICollection<Report> Reports { get; set; }
    }
}
