using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shea.DataAccess.EFDataAccess.SheaDBModels
{
    [Table("REPORTPROGRAMSDETAIL")]
    public partial class ReportProgramDetail
    {
        public int DetailId { get; set; }

        public int ProgramId { get; set; }

        public string Param1Type { get; set; }

        public string Param1 { get; set; }

        public string Param2Type { get; set; }

        public string Param2 { get; set; }
    }
}
