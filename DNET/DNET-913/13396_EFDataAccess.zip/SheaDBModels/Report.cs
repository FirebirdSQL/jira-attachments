﻿using System.Collections.Generic;

namespace Shea.DataAccess.EFDataAccess.SheaDBModels
{
    public class Report
    {
        public Report()
        {
            ReportQueues = new HashSet<ReportQueue>();
        }

        public int ReportId { get; set; }

        public string Title { get; set; }

        public string Filename { get; set; }

        public string Worksheet { get; set; }

        public string ReportType { get; set; }

        public string Param1Required { get; set; }

        public string Param1Type { get; set; }

        public string Param2Required { get; set; }

        public string Param2Type { get; set; }

        public string DateRequired { get; set; }
        
        public string TempTable { get; set; }

        public int? FirstColWidth { get; set; }

        public string ExportType { get; set; }

        public string Description { get; set; }

        public ICollection<ReportQueue> ReportQueues { get; set; }
    }
}
