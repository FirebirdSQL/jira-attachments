namespace Shea.DataAccess.EFDataAccess.SheaDBModels
{
    public partial class ReportGroup
    {
        public int GroupId { get; set; }

        public string Param1 { get; set; }

        public string Param2 { get; set; }

        public int GroupSessionId { get; set; }
    }
}
