﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Shea.DataAccess.EFDataAccess.Common;
using Shea.DataAccess.EFDataAccess.SheaDBModels;

namespace Shea.DataAccess.EFDataAccess.SheaDBRepositories
{
    public interface IReportQueueRepository : IRepository<ReportQueue>
    {
        List<ReportQueue> GetAllPendingPrograms();
        List<ReportQueue> GetAllPendingGroups();
        List<ReportQueue> GetAllPendingSingleReports();
    }
}