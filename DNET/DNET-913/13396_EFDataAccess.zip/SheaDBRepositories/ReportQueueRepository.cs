﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Shea.DataAccess.EFDataAccess.Common;
using Shea.DataAccess.EFDataAccess.SheaDBModels;

namespace Shea.DataAccess.EFDataAccess.SheaDBRepositories
{
    public class ReportQueueRepository : Repository<ReportQueue>, IReportQueueRepository
    {
        private readonly SheaDbContext _dbContext;

        public ReportQueueRepository(SheaDbContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public List<ReportQueue> GetAllPendingPrograms()
        {
            return _dbContext.ReportQueues
                .Where(x => x.Status.Equals("P") && x.ProgramId.HasValue)
                .Include(p => p.ReportProgram)
                .Include(r => r.ReportProgram.ProgramReports)
                .Include(c => c.ReportProgram.ProgramContacts)
                .Include(d => d.ReportProgram.ProgramDetails)
                .OrderByDescending(x => x.QueueId)
                .ToList();
        }

        public List<ReportQueue> GetAllPendingGroups()
        {
            return _dbContext.ReportQueues
                .Where(x => x.Status.Equals("P") && x.ReportId.HasValue && x.GroupSessionId.HasValue)
                .Include(g => g.ReportGroup)
                .Include(r => r.Report)
                .Include(i => i.User)
                .OrderByDescending(x => x.QueueId)
                .ToList();
        }

        public List<ReportQueue> GetAllPendingSingleReports()
        {
            return _dbContext.ReportQueues
                .Where(x => x.Status.Equals("P") && x.ReportId.HasValue && !x.GroupSessionId.HasValue)
                .Include(r => r.Report)
                .Include(i => i.User)
                .OrderByDescending(x => x.QueueId)
                .ToList();
        }
    }
}
