﻿using Microsoft.EntityFrameworkCore;

namespace Shea.DataAccess.EFDataAccess.Common
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly DbContext _context;

        public Repository(DbContext context)
        {
            _context = context;
        }

        public void Add(T entity)
        {
            _context.Set<T>().Add(entity);
            SaveChanges();
        }

        public void Update(T entity)
        {
            _context.Update(entity);
            SaveChanges();
        }

        public void Delete(T entity)
        {
            _context.Remove(entity);
            SaveChanges();
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }

    }
}
