﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Shea.DataAccess.EFDataAccess.SheaDBModels;

namespace Shea.DataAccess.EFDataAccess
{
    public partial class SheaDbContext : DbContext
    {
        private readonly IConfiguration _config;

        public SheaDbContext(DbContextOptions<EFDataAccess.SheaDbContext> options, IConfiguration config)
            : base(options)
        {
            _config = config;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseFirebird(ConfigurationExtensions.GetConnectionString(_config, "SheaDB"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Initial>(entity =>
            {
                entity.ToTable("INITIAL").HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("ID").IsRequired().ValueGeneratedNever();
                entity.Property(e => e.Initials).HasColumnName("INITIALS").HasMaxLength(3);
                entity.Property(e => e.SocialSecurityNbr).HasColumnName("SOCIALSECURITYNBR").HasMaxLength(11);
                entity.Property(e => e.AgentId).HasColumnName("AGENTID").HasMaxLength(11);
                entity.Property(e => e.LetterSigner).HasColumnName("LETTERSIGNER").IsFixedLength().HasMaxLength(1);
                entity.Property(e => e.Name).HasColumnName("NAME").HasMaxLength(40);
                entity.Property(e => e.Title).HasColumnName("TITLE").HasMaxLength(50);
                entity.Property(e => e.Email).HasColumnName("EMAIL").HasMaxLength(60);
                entity.Property(e => e.ActiveUser).HasColumnName("ACTIVEUSER").IsFixedLength().HasMaxLength(1);
                entity.Property(e => e.SignatureId).HasColumnName("SIGNATUREID");
                entity.Property(e => e.OldInitials).HasColumnName("OLDINITIALS").HasMaxLength(3);
                entity.Property(e => e.Phone).HasColumnName("PHONE").HasMaxLength(13);
            });

            modelBuilder.Entity<ReportProgram>(entity =>
            {
                entity.ToTable("REPORTPROGRAMS").HasKey(e => e.ProgramId);
                entity.Property(e => e.ProgramId).HasColumnName("PROGRAMID").IsRequired().ValueGeneratedNever();
                entity.Property(e => e.Title).HasColumnName("TITLE").HasMaxLength(50);
                entity.Property(e => e.ShortName).HasColumnName("SHORTNAME").HasMaxLength(20);
                entity.Property(e => e.Frequency).HasColumnName("FREQUENCY").IsFixedLength();
                entity.Property(e => e.RunDay).HasColumnName("RUNDAY").HasMaxLength(4);
                entity.Property(e => e.DateRange).HasColumnName("DATERANGE").IsFixedLength();
                entity.Property(e => e.MergeSingle).HasColumnName("MERGESINGLE").IsFixedLength();
                entity.Property(e => e.ProgramActive).HasColumnName("PROGRAMACTIVE").IsFixedLength();
                entity.Property(e => e.ReqCustomsDisclaimer).HasColumnName("REQCUSTOMSDISCLAIMER").IsFixedLength();
                entity.Property(e => e.EmailFrom).HasColumnName("EMAILFROM").IsFixedLength();
                entity.Property(e => e.SheaInternal).HasColumnName("SHEAINTERNAL").IsFixedLength();
                entity.Property(e => e.LastRun).HasColumnName("LASTRUN").HasColumnType("date");
                entity.HasMany<ReportProgramContact>(e => e.ProgramContacts)
                    .WithOne()
                    .HasForeignKey(p => p.ProgramId)
                    .HasPrincipalKey(k => k.ProgramId);
                entity.HasMany<ReportProgramReports>(p => p.ProgramReports)
                    .WithOne()
                    .HasForeignKey(o => o.ProgramId)
                    .HasPrincipalKey(p => p.ProgramId);
                entity.HasMany<ReportProgramDetail>(p => p.ProgramDetails)
                    .WithOne()
                    .HasForeignKey(o => o.ProgramId)
                    .HasPrincipalKey(p => p.ProgramId);
            });

            modelBuilder.Entity<ReportProgramContact>(entity =>
            {
                entity.ToTable("REPORTPROGRAMSCONTACTS").HasKey(e => e.ContactId);
                entity.Property(e => e.ContactId).HasColumnName("CONTACTID").IsRequired().ValueGeneratedNever();
                entity.Property(e => e.ProgramId).HasColumnName("PROGRAMID");
                entity.Property(e => e.FullName).HasColumnName("FULLNAME").HasMaxLength(50);
                entity.Property(e => e.Salutation).HasColumnName("SALUTATION").HasMaxLength(20);
                entity.Property(e => e.EMail).HasColumnName("EMAIL").HasMaxLength(100);
                entity.Property(e => e.ContactType).HasColumnName("CONTACTTYPE").IsFixedLength();
            });

            modelBuilder.Entity<ReportProgramDetail>(entity =>
            {
                entity.ToTable("REPORTPROGRAMSDETAIL").HasKey(e => e.DetailId);
                entity.Property(e => e.DetailId).HasColumnName("DETAILID").IsRequired().ValueGeneratedNever();
                entity.Property(e => e.ProgramId).HasColumnName("PROGRAMID");
                entity.Property(e => e.Param1).HasColumnName("PARAM1").HasMaxLength(20);
                entity.Property(e => e.Param1Type).HasColumnName("PARAM1TYPE").IsFixedLength();
                entity.Property(e => e.Param2).HasColumnName("PARAM2").HasMaxLength(20);
                entity.Property(e => e.Param2Type).HasColumnName("PARAM2TYPE").IsFixedLength();
            });

            modelBuilder.Entity<ReportProgramReports>(entity =>
            {
                entity.ToTable("REPORTPROGRAMSREPORTS").HasKey(e => e.ProgramId);
                entity.Property(e => e.ProgramId).HasColumnName("PROGRAMID").IsRequired().ValueGeneratedNever();
                entity.Property(e => e.ReportId).HasColumnName("REPORTID").IsRequired().ValueGeneratedNever();
                entity.HasMany<Report>(r => r.Reports)
                    .WithOne()
                    .HasForeignKey(r => r.ReportId)
                    .HasPrincipalKey(k => k.ReportId);
            });

            modelBuilder.Entity<ReportQueue>(entity =>
            {
                entity.ToTable("REPORTQUEUE").HasKey(e => e.QueueId);
                entity.Property(e => e.QueueId).HasColumnName("QUEUEID").IsRequired().ValueGeneratedNever();
                entity.Property(e => e.ProgramId).HasColumnName("PROGRAMID");
                entity.Property(e => e.GroupSessionId).HasColumnName("GROUPSESSIONID");
                entity.Property(e => e.ReportId).HasColumnName("REPORTID");
                entity.Property(e => e.Param1).HasColumnName("PARAM1").HasMaxLength(20);
                entity.Property(e => e.Param2).HasColumnName("PARAM2").HasMaxLength(20);
                entity.Property(e => e.ParamStartDate).HasColumnName("PARAMSTARTDATE").HasColumnType("date");
                entity.Property(e => e.ParamEndDate).HasColumnName("PARAMENDDATE").HasColumnType("date");
                entity.Property(e => e.Initials).HasColumnName("INITIALS").HasMaxLength(3);
                entity.Property(e => e.Status).HasColumnName("STATUS").IsFixedLength().HasMaxLength(1);
                entity.Property(e => e.DateRequested).HasColumnName("DATEREQUESTED").HasColumnType("date");
                
                entity.HasOne<ReportProgram>(p => p.ReportProgram)
                    .WithOne()
                    .HasForeignKey<ReportQueue>(k => k.ProgramId)
                    .HasPrincipalKey<ReportProgram>(p => p.ProgramId);
                /*
                entity.HasOne<Initial>(i => i.User)
                    .WithOne()
                    .HasForeignKey<ReportQueue>(q => q.Initials)
                    .HasPrincipalKey<Initial>(i => i.Initials);
                */
                entity.HasMany<ReportGroup>(g => g.ReportGroup)
                    .WithOne()
                    .HasForeignKey(k => k.GroupSessionId)
                    .HasPrincipalKey(j => j.GroupSessionId);
                
            });

            modelBuilder.Entity<ReportGroup>(entity =>
            {
                entity.ToTable("REPORTGROUP").HasKey(e => e.GroupId);
                entity.Property(e => e.GroupId).HasColumnName("GROUPID").IsRequired().ValueGeneratedNever();
                entity.Property(e => e.Param1).HasColumnName("PARAM1").HasMaxLength(20);
                entity.Property(e => e.Param2).HasColumnName("PARAM2").HasMaxLength(20);
                entity.Property(e => e.GroupSessionId).HasColumnName("GROUPSESSIONID");
            });

            
            modelBuilder.Entity<Report>(entity =>
            {
                entity.ToTable("REPORTS").HasKey(e => e.ReportId);
                entity.Property(e => e.ReportId).HasColumnName("REPORTID").IsRequired().ValueGeneratedNever();
                entity.Property(e => e.Title).HasColumnName("TITLE").HasMaxLength(50);
                entity.Property(e => e.Filename).HasColumnName("FILENAME").HasMaxLength(50);
                entity.Property(e => e.Worksheet).HasColumnName("WORKSHEET").HasMaxLength(50);
                entity.Property(e => e.ReportType).HasColumnName("REPORTTYPE").IsFixedLength();
                entity.Property(e => e.Param1Required).HasColumnName("PARAM1REQUIRED").IsFixedLength();
                entity.Property(e => e.Param1Type).HasColumnName("PARAM1TYPE").IsFixedLength();
                entity.Property(e => e.Param2Required).HasColumnName("PARAM2REQUIRED").IsFixedLength();
                entity.Property(e => e.Param2Type).HasColumnName("PARAM2TYPE").IsFixedLength();
                entity.Property(e => e.DateRequired).HasColumnName("DATEREQUIRED").IsFixedLength();
                entity.Property(e => e.TempTable).HasColumnName("TEMPTABLE").IsFixedLength();
                entity.Property(e => e.FirstColWidth).HasColumnName("FIRSTCOLWIDTH");
                entity.Property(e => e.ExportType).HasColumnName("EXPORTTYPE").IsFixedLength();
                entity.Property(e => e.Description).HasColumnName("DESCRIPTION").HasMaxLength(8000);
            });
        }

        public virtual DbSet<ReportQueue> ReportQueues { get; set; }
    }
}
