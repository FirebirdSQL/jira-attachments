﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO.Ports;
using System.Threading;
using FirebirdSql.Data.FirebirdClient;

namespace FbConnectionPoolBugTest
{
    class Program
    {
        /// <summary>
        /// Please change the connectionstring to any testdatabase
        /// </summary>
        
        private static List<Thread> _threads = new List<Thread>();

        static void Main(string[] args)
        {
            int numberOfThreads = 15;
            Console.WriteLine("Simulating alot of requests using " + numberOfThreads + " threads");
            for (int i = 0; i < numberOfThreads; i++)
            {
                var t = new Thread(delegate()
                {
                    for (int j = 0; j < 50; j++)
                    {
                        GetDbTime();
                    }
                });
                t.IsBackground = true;
                t.Start();
                _threads.Add(t);
            }
            foreach (var thread in _threads)
            {
                thread.Join();
            }
            Console.WriteLine("Thread join finished - eg. peak period is over.");
            Console.WriteLine("Number of attachments: " + GetAttachemntCount());
            Console.WriteLine("Number of attachments should be about the same as number of threads.");

            Console.WriteLine("Now sumulating fewer request with a single thread");
            Stopwatch sw = new Stopwatch();
            sw.Start();
            while (sw.Elapsed.TotalSeconds < 60)
            {
                GetDbTime();
            }
            Console.WriteLine("GetDbTime using a single thread done");
            Console.WriteLine("Number of attachments: " + GetAttachemntCount());
            Console.WriteLine("Number of attachments should have dropped to only a few");


            Console.ReadKey();
        }


        private static void GetDbTime()
        {
            using (FbConnection conn = new FbConnection(ConfigurationManager.ConnectionStrings["testdb"].ConnectionString))
            {
                conn.Open();
                using (FbCommand command = new FbCommand("select current_timestamp from mon$database", conn))
                {
                    DateTime dt = (DateTime)command.ExecuteScalar();
                }
            }
        }
        
        private static int GetAttachemntCount()
        {
            using (FbConnection conn = new FbConnection(ConfigurationManager.ConnectionStrings["testdb"].ConnectionString))
            {
                conn.Open();
                using (FbCommand command = new FbCommand("select count(*) from mon$attachments", conn))
                {
                    return (int)command.ExecuteScalar();
                }
            }
        }
    }
}
