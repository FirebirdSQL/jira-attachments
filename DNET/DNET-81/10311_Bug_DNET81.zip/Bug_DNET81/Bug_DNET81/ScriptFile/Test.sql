CREATE TABLE TEST (ID INTEGER,DES VarChar(30));
Insert into TEST (ID,DES) Values (1,'-- ERROR!'); 
