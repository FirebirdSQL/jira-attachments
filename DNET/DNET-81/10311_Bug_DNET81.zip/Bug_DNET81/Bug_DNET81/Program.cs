using System;
using System.Collections.Generic;
using System.Text;
using FirebirdSql.Data.Isql;
using FirebirdSql.Data.FirebirdClient;

namespace Bug_DNET81
{
    class Program
    {

        static void Main(string[] args)
        {

            FbConnectionStringBuilder csb = new FbConnectionStringBuilder();

            csb.ServerType = FbServerType.Default;
            csb.DataSource = "LOCALHOST";
            csb.Database = @"C:\Bug_DNET81.fdb"; // <- Warning create file!
            csb.UserID = "SYSDBA";
            csb.Password = "masterkey";

            FbConnection.CreateDatabase(csb.ToString());
            
            FbScript script = new FbScript(@"ScriptFile\Test.sql");

            // File ScriptFile\Test.sql contain: 
            // CREATE TABLE TEST (ID INTEGER,DES VarChar(30)); // OK
            // Insert into TEST (ID,DES) Values (1,'-- ERROR!'); // <-Parse ERROR!
            
            script.Parse();

            FbConnection conn = new FbConnection(csb.ToString());
            conn.Open();

            FbBatchExecution fbe = new FbBatchExecution(conn);
            foreach (string cmd in script.Results)
            {
                fbe.SqlStatements.Add(cmd);
            }

            fbe.Execute();
            conn.Close();
        }
    }
}
