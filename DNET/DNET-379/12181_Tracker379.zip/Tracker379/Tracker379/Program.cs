﻿using System;
using FirebirdSql.Data.FirebirdClient;

namespace Tracker379 {
    class Program {
        static void Main(string[] args) {

            var fb = new FbConnection(@"database=localhost:C:\\Temp\\tracker379.fdb;username=sysdba;password=masterkey;pooling=true;");

            var ctx = new TestContext(fb);
            Console.WriteLine(ctx.CreateDatabaseScript());
            Console.ReadKey(true);
        }



    }
}
