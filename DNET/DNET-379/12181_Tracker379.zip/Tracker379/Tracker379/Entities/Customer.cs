﻿using System.ComponentModel.DataAnnotations;

namespace Tracker379.Entities {


    public class Customer {

        public int ID { get; set; }

        [StringLength(30)]
        public string Name { get; set; }

        [Column("City")]
        [StringLength(20)]
        public string Town { get; set; }

    }
}
