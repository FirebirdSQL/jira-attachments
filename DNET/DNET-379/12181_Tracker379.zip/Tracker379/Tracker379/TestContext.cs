﻿using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using FirebirdSql.Data.FirebirdClient;
using Tracker379.Entities;

namespace Tracker379 {
    public class TestContext : DbContext {

        public TestContext(DbConnection connection)
            : base(connection , true) {
        }

        public IDbSet<Customer> Customers {
            get { return this.Set<Customer>(); }
        }

        public string CreateDatabaseScript() {
            var ctx = ((IObjectContextAdapter)this).ObjectContext;
            return ctx.CreateDatabaseScript();
        }



        protected override void OnModelCreating(DbModelBuilder modelBuilder) {
            base.OnModelCreating(modelBuilder);
        }

    }



}
