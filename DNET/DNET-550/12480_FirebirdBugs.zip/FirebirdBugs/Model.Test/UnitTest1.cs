﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FirebirdSql.Data.FirebirdClient;
using System.IO;
using System.Linq;
using System.Configuration;
using System.Data.Entity;

namespace Model.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            string user = "USER";
            User usr;

            var dbConnection = new FbConnection(ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString
                   .Replace("{PLACEHOLDER}", Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "UserManagement.fdb")));
            using (DatabaseContext db = new DatabaseContext(dbConnection))
            {
                if (db.Database.Exists())
                {
                    db.Database.Delete();
                }
                db.Database.Create();
            }
            using (DatabaseContext db = new DatabaseContext(dbConnection))
            {
                usr = db.Users.Include(x => x.Permissions).Include(x => x.Groups.Select(x1 => x1.Permissions)).Where(x => x.Name == user).Single();
            }
        }
    }
}
