﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class User
    {
        public User()
        {
            this.Groups = new List<UserGroup>();
            this.Permissions = new List<Permission>();
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public virtual ICollection<UserGroup> Groups { get; set; }

        public virtual ICollection<Permission> Permissions { get; set; }
    }

    public partial class UserGroup
    {
        public UserGroup()
        {
            this.Users = new List<User>();
            this.Permissions = new List<Permission>();
        }

        public int Id { get; set; }
        
        public virtual ICollection<User> Users { get; set; }

        public virtual ICollection<Permission> Permissions { get; set; }
    }

    public class Permission
    {
        public Permission()
        {
            this.Users = new List<User>();
            this.Groups = new List<UserGroup>();
        }

        public int Id { get; set; }
        
        public virtual ICollection<UserGroup> Groups { get; set; }
        public virtual ICollection<User> Users { get; set; }
    }
}
