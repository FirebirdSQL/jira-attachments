﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbConnection connection)
            : base(connection, false)
        {
        }

        public DbSet<UserGroup> UserGroups { get; set; }

        public DbSet<User> Users { get; set; }

        public DbSet<Permission> Permissions { get; set; }
    }
}
