﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;

namespace FbRemoteEventTest {
    static class Program {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try {
                FbConnection MonitorConnection = new FbConnection(@"Database=c:\program files\firebird_2_1\examples\empbuild\employee.fdb;User=SYSDBA;Password=masterkey");
                MonitorConnection.Open();
                FbRemoteEvent MonitorEvent = new FbRemoteEvent(MonitorConnection, new[] { "SomeEvent" });
                MonitorEvent.QueueEvents();
            } catch (Exception ex) {
                Console.WriteLine(ex.Message + "\r\n" + ex.StackTrace + (ex.InnerException == null ? "" : "\r\n" + ex.InnerException.Message + "\r\n" + ex.InnerException.StackTrace));
                MessageBox.Show(ex.Message + "\r\n" + ex.StackTrace + (ex.InnerException == null ? "" : "\r\n" + ex.InnerException.Message + "\r\n" + ex.InnerException.StackTrace));
            }
        }
    }
}
