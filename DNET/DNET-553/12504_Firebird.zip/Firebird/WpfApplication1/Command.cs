﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Windows.Input;
using System.Windows;
using System.Windows.Threading;

namespace Core.Common
{
    public class AsyncCommand : ICommand
    {
        public Predicate<object> OnCanExecute = null;
        public Action<object> OnExecute = null;

        public Action<object, CancelEventArgs> OnExecuting = null;
        public Action<object> OnExecuted = null;

        public Dispatcher Dispatcher
        {
            get;
            set;
        }

        public AsyncCommand()
        {
            this.Dispatcher = Dispatcher.CurrentDispatcher;
            IsExecuting = false;
        }

        bool _executing = false;
        public bool IsExecuting 
        {
            get { return _executing; }
            set 
            {
                if (_executing != value)
                {
                    _executing = value;
                    //RaiseCanExecuteChanged();
                    //this.RaiseCanExecuteChanged(() => this.CanExecute(null));
                }
            }
        }

        public event EventHandler CanExecuteChanged;

        private void RaiseCanExecuteChanged()
        {
            if (CanExecuteChanged != null)
                CanExecuteChanged(this, new EventArgs());

            //CommandManager.InvalidateRequerySuggested();
        }

        public bool CanExecute(object parameter)
        {
            if (OnExecute == null)
                return false;

            if (OnCanExecute != null)
                return !IsExecuting && OnCanExecute(parameter);

            return !IsExecuting;
        }

        public void Execute(object parameter)
        {
            if (OnExecute != null)
            {
                CancelEventArgs e = DoExecuting(this, parameter);
                if (!e.Cancel)
                {
                    var state = 0;
                    //ThreadPool.QueueUserWorkItem(state =>
                    {
                        Action<object> action_execute = (p) =>
                        {
                            DoExecute(p);
                        };

                        InvokeAction(Dispatcher.CurrentDispatcher, DispatcherPriority.Send, action_execute, state);

                        Action<object> action_executed = (p) =>
                        {
                            DoExecuted(this, p);
                        };

                        InvokeAction(this.Dispatcher, DispatcherPriority.Send, action_executed, state);

                    };
                    //, parameter);
                }
            }
        }

        private object InvokeAction(Dispatcher dispatcher, DispatcherPriority priority, Delegate action, object parameter)
        {
            DispatcherOperation refresh = dispatcher.BeginInvoke(priority, action, parameter);
            DispatcherOperationStatus status = refresh.Wait();
            if (refresh.Status == DispatcherOperationStatus.Completed)
                return refresh.Result;

            return null;
        }
        
        public void DoExecute(object parameter)
        {
            if (OnExecute != null)
                OnExecute(parameter);
        }
        
        CancelEventArgs DoExecuting(object sender, object parameter)
        {
            IsExecuting = true;
            
            CancelEventArgs e = new CancelEventArgs();
            if (OnExecuting != null)
                OnExecuting(parameter, e);

            if (e.Cancel)
                IsExecuting = false;

            return e;
        }

        void DoExecuted(object sender, object parameter)
        {
            if (OnExecuted != null)
                OnExecuted(parameter);

            IsExecuting = false;
        }
    }
}
