﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Collections.Specialized;
using System.Windows.Threading;
using System.Threading;

using Core;
using Core.Common;
using Core.Model;

using System.IO;
using System.Security.Cryptography;
using AppNamespace;
using Microsoft.Win32;
using System.Collections;
using DataAccessLayer.Model;
using DataAccessLayer.Common;


namespace MyApplication.ViewModels
{
    public class MasterResourceViewModel : ViewModel
    {
        CollectionViewSource _resources = new CollectionViewSource();
        Boolean _canpopulate = false;

        public CollectionViewSource Resources
        {
            get
            {
                return _resources;
            }
            internal set
            {
                _resources = value;
            }
        }

        public AsyncCommand PolulateCommand { get; set; }

        public Boolean CanPopulate
        {
            get
            {
                return _canpopulate;
            }
            set
            {
                if (_canpopulate != value)
                {
                    _canpopulate = value;
                    //this.RaisePropertyChanged(() => this.CanPopulate);
                }
            }
        }

        public MasterResourceViewModel()
            : base()
        {
            ObservableCollection<Temp> collection = new ObservableCollection<Temp>();
            Resources.Source = new ObservableCollection<Temp>();

            PolulateCommand = new AsyncCommand()
                              {
                                  Dispatcher = this.Dispatcher,
                                  OnCanExecute = (p) => CanPopulate,
                                  OnExecute = (p) =>
                                  {
                                      using (Context ctx = new Context())
                                      {
                                          var items = ctx.Collection.ToList();

                                          var first = items.FirstOrDefault();
                                          if (first != null)
                                              first.Name = first.Name.Replace(" ", "") + " ";

                                          if (items.Count < 2)
                                          {
                                              Temp current = new Temp();
                                              //current.Id = items.Count() + 1;
                                              current.Name = "éléphant";

                                              ctx.SaveOrUpdate(current);

                                              items.Add(current);
                                          }

                                          ctx.SaveChanges();


                                          collection.Clear();
                                          foreach (var item in items)
                                              collection.Add(item);
                                      }
                                  },
                                  OnExecuting = (p, e) =>
                                  {
                                      e.Cancel = false;
                                  },
                                  OnExecuted = (p) =>
                                  {
                                      this.Populate(this, collection);
                                  }
                              };

            CanPopulate = true;
        }


        public void Populate(object sender, ObservableCollection<Temp> response)
        {
            try
            {
                Console.WriteLine("Executing");
                IDisposable disposer = Resources.DeferRefresh();

                CanPopulate = false;
                //throw new Exception("err");

                (Resources.Source as ObservableCollection<Temp>).Clear();
                foreach (var item in response)
                    (Resources.Source as ObservableCollection<Temp>).Add(item);

                disposer.Dispose();

                CanPopulate = true;

                Console.WriteLine("Executed");
            }
            catch (Exception)
            {
                // Todo : ...
                //parameter.HasErrors = true;
                //throw;
            }
            finally
            {
                CanPopulate = true;
            }
        }
    }
}
