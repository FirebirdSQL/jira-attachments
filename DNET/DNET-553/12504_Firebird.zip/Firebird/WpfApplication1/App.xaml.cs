﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using System.Threading;
using System.Globalization;
using System.Windows.Markup;
using System.Text;
using System.IO;
using System.Collections.Specialized;
using System.Windows.Threading;
using System.Windows.Input;
using System.Data.Common;

using Core;

using System.Reflection;
using System.Management;

namespace AppNamespace
{
    /// <summary>
    /// Logique d'interaction pour App.xaml
    /// </summary>
    public partial class App : Application
    {
        App()
        {
            FrameworkElement.LanguageProperty.OverrideMetadata(
            typeof(FrameworkElement),
            new FrameworkPropertyMetadata(
            XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));

        }
    }
}

