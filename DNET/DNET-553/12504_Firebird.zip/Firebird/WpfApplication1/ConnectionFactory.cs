﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using FirebirdSql.Data.FirebirdClient;
using System.Data.Entity.Infrastructure;
using System.IO;
using FirebirdSql.Data.Services;

namespace DataAccessLayer.Common
{
    public class ConnectionFactory : IDbConnectionFactory
    {
        static string server_path = "server x86";

        static ConnectionFactory()
        {
            //server_path = "x86";
            if (Environment.Is64BitOperatingSystem == true)
                server_path = "server x64";
        }

        public static FbConnection GenerateConnection()
        {
            FbConnectionStringBuilder csb = new FbConnectionStringBuilder()
            {
                ServerType = FbServerType.Embedded,
                Database = "data.db",
                Dialect = 3,
                UserID = "SYSDBA",
                Password = "masterkey",
                ClientLibrary = server_path + @"\fbembed.dll",
                Charset = "ISO8859_1",
                PacketSize = 4096
            };
            return new FbConnection(csb.ToString());
        }

        DbConnection IDbConnectionFactory.CreateConnection(string nameOrConnectionString)
        {
            switch (nameOrConnectionString)
            {
                case "Default":
                    {
                        return GenerateConnection();
                    }
            }
            return null;
        }
    }
}
