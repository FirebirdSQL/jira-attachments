﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations;

using DataAccessLayer.Model;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccessLayer.Configuration
{
    class TempConfiguration : EntityTypeConfiguration<Temp>
    {
        public TempConfiguration()
        {
            HasKey(x => x.Id);

            Property(x => x.Id)
                .HasColumnName("ID")
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
                .IsRequired();
            Property(x => x.Name)
                .HasColumnName("NAME");
            
            Ignore(x => x.IsNew);
            Ignore(x => x.IsOriginal);
            Ignore(x => x.IsLazy);

            ToTable("TEMP");
        }
    }
}
