﻿using System.ComponentModel;
using System.Windows;
using System.Text;

using MyApplication.ViewModels;
using System.Windows.Controls;
using System.Collections.Generic;
using System.IO;
using System;
using AppNamespace;


namespace MyApplication
{
    /// <summary>
    /// Logique d'interaction pour Window1.xaml
    /// </summary>
    public partial class MasterView : Window
    {
        public MasterView()
        {
            InitializeComponent();

            this.DataContext = new MasterResourceViewModel();
        }
    }
}
