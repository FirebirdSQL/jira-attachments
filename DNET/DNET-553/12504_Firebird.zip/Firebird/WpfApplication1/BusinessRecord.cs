﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;


namespace Core.Model
{
    public abstract class BusinessRecord : INotifyPropertyChanging, INotifyPropertyChanged
    {
        public event PropertyChangingEventHandler PropertyChanging;
        public event PropertyChangedEventHandler PropertyChanged;

        //[NotMapped]
        public bool IsNew { get; protected set; }

        public bool IsOriginal { get; protected set; }

        public bool IsLazy { get; protected set; }

        public BusinessRecord(bool lazy= false)
        {
            IsNew = true;
            IsOriginal = true;
            IsLazy = lazy;
        }
    }
}