﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Windows;
using System.Windows.Threading;


namespace Core.Common
{
    public interface IViewModel
    {
        Dispatcher Dispatcher { get; }
    }

    public class ViewModel : INotifyPropertyChanged, IViewModel
    {
        public Dispatcher Dispatcher
        {
            get { return Dispatcher.CurrentDispatcher; }
        }

        public Boolean IsExecuting { get; set; }

        public ViewModel()
        {            
        }

        #region INotifyPropertyChanged Membres

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }

}
