﻿using System;
using System.Collections.Generic;

using Core.Model;



namespace DataAccessLayer.Model
{
    public class Temp : BusinessRecord
    {
        #region IRepository Members

        public int Id { get; set; }
        public string Name { get; set; }

        #endregion

    }
}