﻿using FirebirdSql.Data.FirebirdClient;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace AppNamespace
{
    public class ExportToExcel : IDisposable
    {
        //string strCon = ConfigurationManager.ConnectionStrings["SafewayGVDemoDBContext"].ConnectionString;
        //string strCon = @"Excel 8.0;Database=C:\testing.xls;Extended Properties=EXCEL 12.0;HDR=YES"; // 
        string strCon = @"server type=Embedded;initial catalog=test.fdb;dialect=3;user id=SYSDBA;password=masterkey;client library=""server x64\fbembed.dll""";

        //'SELECT ID FROM [Sheet1$]'

        private Application app;
        private Workbook workbook;
        private Worksheet previousWorksheet;
        private Range workSheet_range;
        private string folder;

        public ExportToExcel(string folder, bool visible = false)
        {

            this.folder = folder;
            this.app = null;
            this.workbook = null;
            this.previousWorksheet = null;
            this.workSheet_range = null;

            create(visible);
        }

        private void create(bool visible)
        {
            try
            {
                app = new Application();
                app.Visible = visible;
                workbook = app.Workbooks.Add(1);
            }
            catch (Exception excThrown)
            {
                throw new Exception(excThrown.Message);
            }
            finally
            {
            }
        }

        public void Dispose()
        {
            try
            {
                workbook.Close(false, Type.Missing, Type.Missing);

                //workbook.Close();
                workbook = null;
                app.Quit();
                app = null;
            }
            catch (Exception excThrown)
            {
                throw new Exception(excThrown.Message);
            }
            finally
            {
            }
        }

        public void ExportTable(string query, string sheetName, bool header = true)
        {
            FbDataReader myReader = null;
            try
            {
                FirebirdClientFactory factory = DbProviderFactories.GetFactory("FirebirdSql.Data.FirebirdClient") as FirebirdClientFactory;
                FbConnection connection = factory.CreateConnection() as FbConnection;

                Worksheet worksheet = (workbook.Sheets.Add(Missing.Value, Missing.Value, 1, XlSheetType.xlWorksheet) as Worksheet);
                using (FbConnection Sqlcon = new FbConnection(strCon))
                {
                    FbCommand cmd = new FbCommand();
                    Sqlcon.Open();
                    cmd.Connection = Sqlcon;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;
                    //cmd.Parameters.Add(new FbParameter("@pvchAction", FbDbType.VarChar, 50));
                    //cmd.Parameters.Add("@pIntErrDescOut", FbDbType.Int).Direction = ParameterDirection.Output;
                    //cmd.Parameters["@pvchAction"].Value = "select";
                    worksheet.Name = sheetName;
                    previousWorksheet = worksheet;

                    myReader = cmd.ExecuteReader();

                    int columnCount = myReader.FieldCount;
                    int rowIndex = 1;

                    if (header)
                    {
                        for (int n = 0; n < columnCount; n++)
                        {
                            //Console.Write(myReader.GetName(n) + "\t");
                            createHeaders(worksheet, rowIndex, n + 1, myReader.GetName(n));
                        }

                        rowIndex++;
                    }

                    while (myReader.Read())
                    {
                        for (int n = 0; n < columnCount; n++)
                        {
                            //addData(worksheet, rowIndex, n + 1, myReader[myReader.GetName(n)].ToString());
                            addData(worksheet, rowIndex, n + 1, myReader[n].ToString());
                        }
                        rowIndex++;
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                if (myReader != null && !myReader.IsClosed)
                {
                    myReader.Close();
                    myReader.Dispose();
                }
                myReader = null;
            }

        }

        public void createHeaders(Worksheet worksheet, int row, int col, string htext)
        {
            worksheet.Cells[row, col] = htext;
        }

        public void addData(Worksheet worksheet, int row, int col, string data)
        {
            worksheet.Cells[row, col] = data;
        }

        public void SaveWorkbook(string name)
        {

            String folderPath = this.folder;

            if (!System.IO.Directory.Exists(folderPath))
            {
                System.IO.Directory.CreateDirectory(folderPath);
            }

            string ext = ".xlsx";

            string filePath = Path.Combine(folder, name + ext);
            while (System.IO.File.Exists(filePath))
            {
                //fileName = fileNameBase + counter;
                //counter++;
            }


            try
            {
                workbook.SaveAs(filePath, XlFileFormat.xlWorkbookDefault, Missing.Value, Missing.Value, Missing.Value, Missing.Value, XlSaveAsAccessMode.xlNoChange, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());

            }
        }

    }
}
