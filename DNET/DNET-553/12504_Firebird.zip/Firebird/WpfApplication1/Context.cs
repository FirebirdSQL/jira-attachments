﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using System.Data.Common;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.ComponentModel.DataAnnotations;

using FirebirdSql.Data.FirebirdClient;

using DataAccessLayer;
using DataAccessLayer.Model;
using DataAccessLayer.Configuration;
using System.Data;


namespace DataAccessLayer.Common
{
    public class Context : DbContext
    {

        public IDbSet<Temp> Collection
        {
            get { return this.Set<Temp>(); }
        }
        
        public Context()
            : base("Default")
        {
            this.Configuration.AutoDetectChangesEnabled = true;
            this.Configuration.LazyLoadingEnabled = true;
            this.Configuration.ProxyCreationEnabled = true;
            this.Configuration.ValidateOnSaveEnabled = true;

            Database.SetInitializer<Context>(new ContextInitializer());
            Database.DefaultConnectionFactory = new ConnectionFactory();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new TempConfiguration());

            base.OnModelCreating(modelBuilder);
        }


        public virtual void SaveOrUpdate<TEntity>(TEntity entity)
    where TEntity : class
        {
            var objContext = ((IObjectContextAdapter)this).ObjectContext;
            var objSet = objContext.CreateObjectSet<TEntity>();
            var entityKey = objContext.CreateEntityKey(objSet.EntitySet.Name, entity);

            object original = null;
            bool exists = objContext.TryGetObjectByKey(entityKey, out original);

            if (exists)
            {
                this.Entry<TEntity>(original as TEntity).CurrentValues.SetValues(entity);
            }
            else
            {
                this.Entry<TEntity>(entity).State = EntityState.Added;
            }
        }
    }
}
